from board.board import Board


class Game:
    def __init__(self, dim, apple_count):
        self._board = Board(dim, apple_count)

    @property
    def board(self):
        return self._board

    def move(self, number):
        if number == '':
            number = 1
        row_mod, col_mod = self._board.get_direction()
        for i in range(int(number)):
            is_end = self._board.move_snake(row_mod, col_mod)
            if is_end == 'end':
                return 'end'

    def left(self, val):
        if self._board.get_direction() == [0, 1]:
            raise ValueError("Can't turn 180 degrees")
        if self._board.get_direction() == [0, -1]:
            return
        self._board.dir_set('left')
        row_mod, col_mod = self._board.get_direction()
        is_end = self._board.move_snake(row_mod, col_mod)
        if is_end == 'end':
            return 'end'

    def right(self, val):
        if self._board.get_direction() == [0, -1]:
            raise ValueError("Can't turn 180 degrees")
        if self._board.get_direction() == [0, 1]:
            return
        self._board.dir_set('right')
        row_mod, col_mod = self._board.get_direction()
        is_end = self._board.move_snake(row_mod, col_mod)
        if is_end == 'end':
            return 'end'

    def up(self, val):
        if self._board.get_direction() == [1, 0]:
            raise ValueError("Can't turn 180 degrees")
        if self._board.get_direction() == [-1, 0]:
            return
        self._board.dir_set('up')
        row_mod, col_mod = self._board.get_direction()
        is_end = self._board.move_snake(row_mod, col_mod)
        if is_end == 'end':
            return 'end'

    def down(self, val):
        if self._board.get_direction() == [-1, 0]:
            raise ValueError("Can't turn 180 degrees")
        if self._board.get_direction() == [1, 0]:
            return
        self._board.dir_set('down')
        row_mod, col_mod = self._board.get_direction()
        is_end = self._board.move_snake(row_mod, col_mod)
        if is_end == 'end':
            return 'end'
