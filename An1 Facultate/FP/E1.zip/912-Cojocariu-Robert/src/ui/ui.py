from game.game import Game


class UI:
    def __init__(self, dim, apple_count):
        self._game = Game(dim, apple_count)

    def split_command(self, command):
        command = command.strip()
        tokens = command.split(' ', 1)
        command_word = tokens[0].strip().lower()
        if len(tokens) == 2:
            command_params = tokens[1].strip()
        else:
            command_params = ''
        return command_word, command_params

    def start(self):
        command_dict = {"move": self._game.move, "left": self._game.left, "right": self._game.right, "up": self._game.up,
                        "down": self._game.down}
        while True:
            try:
                print(self._game.board)
                command = input("command>")
                command_word, command_params = self.split_command(command)
                if command_word in command_dict:
                    is_end = command_dict[command_word](command_params)
                    if is_end == 'end':
                        print(self._game.board)
                        print("Game over")
                        return
                else:
                    raise ValueError("Invalid command")
            except Exception as err:
                print("ERROR! " + str(type(err).__name__) + ': ' + str(err) + '\n')
                input("Press any key to continue...\n")
