from texttable import Texttable
import random


class Board:
    def __init__(self, dim, apple_count):
        self._dim = dim
        self._apple_count = apple_count
        self._data = [[None for j in range(self._dim+2)] for i in range(self._dim+2)]
        self._nr_cells = self._dim * self._dim
        self._direction = 'up'
        self._snake_poz = []
        self.add_initial_apples()
        self.place_snake()

    @property
    def nr_rows(self):
        return self._dim

    @property
    def nr_cols(self):
        return self._dim

    @property
    def get_board(self):
        return self._data

    @property
    def get_snake_poz(self):
        return self._snake_poz

    def dir_set(self, val):
        self._direction = val

    def get_direction(self):
        if self._direction == 'up':
            return [-1, 0]
        elif self._direction == 'down':
            return [1, 0]
        elif self._direction == 'left':
            return [0, -1]
        return [0, 1]

    def add_initial_apples(self):
        for i in range(self._apple_count):
            placed = False
            count = 0
            while not placed:
                row, col = random.randint(1, self._dim), random.randint(1, self._dim)
                count += 1
                if self._data[row][col] is None and self.adjacent_good(row, col, '.'):
                    self._data[row][col] = '.'
                    placed = True
                if count == 500:
                    continue

    def adjacent_good(self, row, col, symb):
        if self._data[row - 1][col] == symb or self._data[row + 1][col] == symb or self._data[row][col - 1] == symb or \
                self._data[row][col + 1] == symb:
            return False
        return True

    def place_snake(self):
        half = self._dim//2
        self._data[half][half] = '*'
        self._snake_poz.append([half, half, -1, 0])
        self._data[half+1][half] = '+'
        self._snake_poz.append([half+1, half, -1, 0])
        self._data[half+2][half] = '+'
        self._snake_poz.append([half+2, half, -1, 0])

    def move_snake(self, row_mod, col_mod):
        index = len(self._snake_poz)-1
        apple = 0
        while index > 0:
            self._snake_poz[index][2] = self._snake_poz[index-1][2]
            self._snake_poz[index][3] = self._snake_poz[index-1][3]
            index -= 1
        temp_row = self._snake_poz[0][0]
        temp_col = self._snake_poz[0][1]
        temp_row += row_mod
        temp_col += col_mod
        if self._data[temp_row][temp_col] == '+':
            return 'end'
        for body in self._snake_poz:
            self._data[body[0]][body[1]] = None
        self._snake_poz[0][2] = row_mod
        self._snake_poz[0][3] = col_mod
        for index in range(len(self._snake_poz)):
            self._snake_poz[index][0] += self._snake_poz[index][2]
            self._snake_poz[index][1] += self._snake_poz[index][3]
            if index == 0:
                if self._data[self._snake_poz[index][0]][self._snake_poz[index][1]] == '.':
                    apple += 1
                elif self._data[self._snake_poz[index][0]][self._snake_poz[index][1]] == '+':
                    return 'end'
                self._data[self._snake_poz[index][0]][self._snake_poz[index][1]] = '*'
            else:
                self._data[self._snake_poz[index][0]][self._snake_poz[index][1]] = '+'
        row = self._snake_poz[0][0]
        col = self._snake_poz[0][1]
        if row == 0 or row == self._dim+1 or col == 0 or col == self._dim+1:
            return 'end'
        if apple:
            self.add_snake_bodies(apple)

    def add_snake_bodies(self, apple):
        for i in range(apple):
            row, col = self._snake_poz[-1][0], self._snake_poz[-1][1]
            dir_row, dir_col = self._snake_poz[-1][2], self._snake_poz[-1][3]
            dir_row_cop, dir_col_cop = dir_row, dir_col
            if dir_row == -1:
                dir_row += 2
            elif dir_row == 1:
                dir_row -= 2
            if dir_col == -1:
                dir_col += 2
            elif dir_col == 1:
                dir_col -= 2
            row += dir_row
            col += dir_col
            self._data[row][col] = '+'
            self._snake_poz.append([row, col, dir_row_cop, dir_col_cop])
            self.add_random_apple()

    def add_random_apple(self):
        placed = False
        count = 0
        while not placed:
            row, col = random.randint(1, self._dim), random.randint(1, self._dim)
            count += 1
            if self._data[row][col] is None and self.adjacent_good(row, col, '.'):
                self._data[row][col] = '.'
                placed = True
            if count == 1000:
                return

    def __str__(self):
        t = Texttable()
        for row in range(1, self._dim+1):
            row_data = []
            for col in range(1, self._dim+1):
                if self._data[row][col] is None:
                    row_data.append(' ')
                elif self._data[row][col] == '.':
                    row_data.append('.')
                elif self._data[row][col] == '*':
                    row_data.append('*')
                elif self._data[row][col] == '+':
                    row_data.append('+')
            t.add_row(row_data)
        return t.draw()
