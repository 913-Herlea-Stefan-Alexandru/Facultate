import configparser


class SettingsException(Exception):
    def __init__(self, msg):
        self._msg = msg

    def __str__(self):
        return self._msg


class Settings:
    def __init__(self, name):
        self._config = configparser.RawConfigParser()
        self._settings_name = name
        self._settings_data = []

    def get_settings(self):
        self._config.read(self._settings_name)
        for (key, value) in self._config.items('Default'):
            self._settings_data.append(value)

    def get_board_settings(self):
        return int(self._settings_data[0]), int(self._settings_data[1])

    @property
    def settings_data(self):
        return self._settings_data
