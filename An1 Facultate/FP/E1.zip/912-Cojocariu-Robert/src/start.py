from src.settings.settings import Settings
from ui.ui import UI

done = False
while not done:
    try:
        settings = Settings('settings/settings.properties')
        settings.get_settings()
        DIM, apple_count = settings.get_board_settings()
        ui = UI(DIM, apple_count)
        ui.start()
        done = True
    except Exception as err:
        print("ERROR! " + str(type(err).__name__) + ": " + str(err) + '\n')
        input("Press any key to try again...")
