from Board import *
from jproperties import Properties
from os import path
from Service import *
from UI import *
from Snake import *

if __name__ == '__main__':
    configs = Properties()
    with open('settings.properties', 'rb') as config_file:
        configs.load(config_file)
    DIM = int(configs.get("dim").data)
    apples = int(configs.get("apple_count").data)
    board = Board(DIM, apples)
    snake = Snake(board)
    service = Service(snake,board)
    ui = UI(service,board)
    ui.run()
