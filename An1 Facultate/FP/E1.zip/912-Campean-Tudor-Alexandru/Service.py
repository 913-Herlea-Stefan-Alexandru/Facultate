class GameOver(Exception):
    pass
from collections import deque
class Service:
    def __init__(self,snake,board):
        self._board = board
        self._snake = snake

    def move(self):
        list = self._snake.get_list()
        head = list[0]
        print(head)
        if head[0] == list[1][0]-1 and head[1] == list[1][1]:
            self.up()
        if head[0] == list[1][0]+1 and head[1] == list[1][1]:
            self.down()
        if head[0] == list[1][0] and head[1] == list[1][1]-1:
            self.left()
        if head[0] == list[1][0] and head[1] == list[1][1]+1:
            self.right()

    def up(self):
        list = self._snake.get_list()
        for i in range(0,len(list)-1):
            list[i+1] = list[i]
        if list[0][0] - 1 < 0:
            raise GameOver("Game over!")
        list[0][0] -= 1
        self._snake.set_list(list)
        self._board.put_snake(self._snake._poz_list)

    def down(self):
        list = self._snake.get_list()
        for i in range(0,len(list)-1):
            list[i+1] = list[i]
        if list[0][0] + 1 >= self._board.get_dim():
            raise GameOver("Game over!")
        list[0][0] += 1
        self._snake.set_list(list)
        print(self._snake.get_list())
        self._board.put_snake(self._snake._poz_list)

    def right(self):
        list = self._snake.get_list()
        for i in range(0,len(list)-1):
            list[i+1] = list[i]
        if list[0][1] + 1 not in range(0,self._board.get_dim()):
            raise GameOver("Game over!")
        list[0][1] += 1
        self._snake.set_list(list)
        self._board.put_snake(self._snake._poz_list)

    def left(self):
        list = self._snake.get_list()
        print(list)
        for i in range(0,len(list)-1):
            list[i+1] = list[i]
        if list[0][1] -1 not in range(0, self._board.get_dim()):
            raise GameOver("Game over!")
        list[0][1] -= 1
        self._snake.set_list(list)
        print(self._snake._poz_list)
        self._board.put_snake(self._snake._poz_list)

    def put_snake(self):
        self._board.put_snake(self._snake._poz_list)











