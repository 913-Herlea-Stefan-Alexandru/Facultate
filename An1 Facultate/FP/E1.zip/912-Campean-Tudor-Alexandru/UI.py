from Service import *

class UI:
    def __init__(self,service,board):
        self._service = service
        self._board = board


    def split_command(self,command):
        """""
        Splits command string into command word and parameters
        :return: (command_word,command_params)
        """
        command = command.strip()
        tokens = command.split(' ', 1)
        command_word = tokens[0].strip().lower()
        command_params = tokens[1].strip() if len(tokens) == 2 else ''
        return command_word, command_params

    def move_ui(self):
        self._service.move()

    def left_ui(self):
        self._service.left()

    def right_ui(self):
        self._service.right()

    def up_ui(self):
        self._service.up()

    def down_ui(self):
        self._service.down()



    def run(self):
        done = False
        command_dict = {'move': self.move_ui, 'left': self.left_ui,
                        'up': self.up_ui, 'down': self.down_ui, 'right': self.right_ui}
        self._service.put_snake()
        while not done:
            while not self._board.check_apples():
                self._board.put_apples()
            print(self._board)
            command = input("Type a command> ")
            try:
                cmd_word, cmd_params = self.split_command(command)
                if cmd_word in command_dict:
                    command_dict[cmd_word]()

                elif cmd_word == 'exit':
                    done = True
                else:
                    print('Unknown command')
            except ValueError as ve:
                print(str(ve))
            except GameOver as go:
                print(str(go))
                break