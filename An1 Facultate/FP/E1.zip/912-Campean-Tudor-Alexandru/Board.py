from texttable import Texttable
import numpy as np
from random import randint


class InvalidMove(Exception):
    pass


class Board:
    def __init__(self,dim,apples):
        self._dim = dim
        self._apples = apples
        self._data = np.zeros((dim, dim))
        self._data = np.flip(self._data)

    def check_apples(self):
        c = 0
        for i in range(self._dim):
            for j in range(self._dim):
                if self._data[i][j] == 1:
                    c +=1
        if c!= self._apples:
            return False
        else:
            return True

    def get_dim(self):
        return self._dim

    def put_apples(self):
        if not self.check_apples():
            done = False
            while not done:
                i = randint(0,self._dim-1)
                j = randint(0,self._dim-1)
                if self._data[i][j] == 0:
                    self._data[i][j] = 1
                    done = True
                    if i+1 <= self._dim-1:
                        if self._data[i+1][j] == 1:
                            done = False
                            self._data[i][j] = 0
                    if i-1>=0:
                        if self._data[i + -1][j] == 1:
                            done = False
                            self._data[i][j] = 0
                    if j+1 <= self._dim-1:
                        if self._data[i][j+1] == 1:
                            done = False
                            self._data[i][j] = 0
                    if j-1 >= 0:
                        if self._data[i][j-1] == 1:
                            done = False
                            self._data[i][j] = 0

    def put_snake(self,list):
        for i in range(self.get_dim()):
            for j in range(self.get_dim()):
                if self._data[i][j] !=0 and self._data[i][j] !=1:
                    self._data[i][j] = 0
        print(list)
        self._data[list[0][0]][list[0][1]] = 3
        for i in range(1,len(list)):
            self._data[list[i][0]][list[i][1]] = 2


    def __str__(self):
        t = Texttable()
        for row in range(self._dim):
            row_data = []
            for index in self._data[row]:
                if index == 0:
                    row_data.append(' ')
                elif index == 1:
                    row_data.append('.')
                elif index == 2:
                    row_data.append('+')
                elif index == 3:
                    row_data.append('*')
            t.add_row(row_data)
        return t.draw()
