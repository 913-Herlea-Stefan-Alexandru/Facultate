class Snake:
    def __init__(self,board):
        self._board = board
        self._poz_list = []
        self._poz_list.append([self._board.get_dim() // 2 - 1,self._board.get_dim() // 2])
        self._poz_list.append([self._board.get_dim() // 2 ,self._board.get_dim() // 2])
        self._poz_list.append([self._board.get_dim() // 2 + 1,self._board.get_dim() // 2])

    def get_list(self):
        return self._poz_list

    def set_list(self,list):
        self._poz_list = list

