from entity.board import Board
from service.gameplat import Services


class Settings:
    def __init__(self, file_name):
        super().__init__()
        self._file_name = file_name
        self._load()

    def _load(self):
        f = open(self._file_name, 'rt')  # read text
        lines = f.readlines()
        f.close()

    def _read_dim(self):
        f = open(self._file_name, 'rt')
        lines = f.readlines()
        dim = lines[0]
        return dim

    def _read_app_count(self):
        f = open(self._file_name, 'rt')
        lines = f.readlines()
        apple_count = lines[1]
        return apple_count

class Console:
    def __init__(self, service, settings):
        self._service = service
        self._settings = settings

    def start(self):
        try:
            x = int(self._settings._read_dim())
            if x < 1:
                raise ValueError
            self._service.set_row(x)
            self._service.set_column(x)
            self._service.create_board()
            self._service.at_the_start_of_the_game()
            apple_count = int(self._settings._read_app_count())
            self._service.place_apples(apple_count)
            print(str(self._service.get_board()))
        except IndexError:
            pass
        continue_game = True
        direction = 'up'
        #implicit direction is up

        while continue_game:
            command = input()
            command = command.strip()
            tokens = command.split(' ', 1)
            if tokens[0] == 'move':
                if len(tokens) == 2:
                    if self.move_number(tokens[1], direction) is False:
                        continue_game = False
                    #self.move_number(tokens[1], direction)
                elif len(tokens) == 1:
                    if self.move_number(1, direction) is False:
                        continue_game = False
                    #self.move_number(1, direction)
            if tokens[0] == 'up' or tokens[0] == 'right' or tokens[0] == 'down' or tokens[0] == 'left':
                direction = tokens[0]
            print(str(self._service.get_board()))
        print("YOU LOST")

    def move_number(self, number, direction):
        n = int(number)
        if direction == 'up':
            if self._service.move_up(n) == -1:
                return False
        elif direction == 'down':
            if self._service.move_down(n) == -1:
                return False
        elif direction == 'right':
            if self._service.move_right(n) == -1:
                return False
        elif direction == 'left':
            if self._service.move_left(n) == -1:
                return False




services = Services(Board())
parsing = Settings("settings.txt")
ui = Console(services, parsing)
ui.start()