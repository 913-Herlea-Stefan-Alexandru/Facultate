import random

from entity.board import ValidatePoint


class Services:
    def __init__(self, board):
        self._board = board
        self._valid = ValidatePoint()

    def get_board(self):
        """
        Returns the board
        """
        return self._board

    def set_row(self, row):
        """
        Sets the row of the board
        """
        self._board.set_row(row)

    def set_column(self, column):
        """
        Sets the column of the board
        """
        self._board.set_column(column)

    def create_board(self):
        """
        Creates the board
        """
        self._board.create_board()

    def destroy_board(self):
        """
        Function that destroys the board
        """
        self._board.destroy_board()

    def place_apples(self, apple_count):
        '''
        place an apple and also mark it's imediate neighbours with -1
        :param apple_count: given number of apples
        :return:
        '''
        for i in range(apple_count):
            point = random.choice(self._board.available_move())
            self._board.mark_apple(point.get_x(), point.get_y())
            self._board.mark_near_points(point)


    def at_the_start_of_the_game(self):
        '''
        compute the middle of the board, place the apples
        :return: place the snake accordingly
        '''
        middlerow = (self._board.get_row() // 2 )
        middlecolumn = (self._board.get_column() // 2 )
        self._board.mark_head(middlerow - 1, middlecolumn)
        self._board.mark_body(middlerow, middlecolumn)
        self._board.mark_end_body(middlerow + 1, middlecolumn)

    def move_up(self, n):
        print(n)
        for i in range(n):
            point = self._board.get_head_position()
            if point.get_x() - 1 < 0:
                return -1
            if self._board.get_point(point.get_x() - 1, point.get_y()) == 2:
                return -1
            if self._board.get_point(point.get_x() - 1, point.get_y()) == 3:
                '''in this case there is an apple'''
                self._board.mark_body(point.get_x(), point.get_y())
                self._board.mark_head(point.get_x() - 1, point.get_y())
            if self._board.get_point(point.get_x() - 1, point.get_y()) == 0:
                self._board.mark_body(point.get_x(), point.get_y())
                self._board.mark_head(point.get_x() - 1, point.get_y())
                endpoint = self._board.get_endpoint()
                self._board.mark_end_body(endpoint.get_x() - 1, endpoint.get_y())
                self._board.mark_empty(endpoint)

    def move_right(self, n):
        for i in range(n):
            point = self._board.get_head_position()
            if point.get_y() + 1 > self._board.get_column():
                return -1
            if self._board.get_point(point.get_x(), point.get_y() + 1) == 2:
                return -1
            if self._board.get_point(point.get_x(), point.get_y() + 1) == 3:
                '''in this case there is an apple'''
                self._board.mark_body(point.get_x(), point.get_y())
                self._board.mark_head(point.get_x() , point.get_y() + 1)
            elif self._board.get_point(point.get_x(), point.get_y() + 1) == 0:
                self._board.mark_body(point.get_x(), point.get_y())
                self._board.mark_head(point.get_x() , point.get_y() + 1)
                endpoint = self._board.get_endpoint()
                self._board.mark_end_body(endpoint.get_x(), endpoint.get_y() + 1)
                self._board.mark_empty(endpoint)

    def move_down(self, n):
        for i in range(n):
            point = self._board.get_head_position()
            if point.get_x() + 1 > self._board.get_row():
                return -1
            if self._board.get_point(point.get_x() + 1, point.get_y()) == 2:
                return -1
            if self._board.get_point(point.get_x() + 1, point.get_y()) == 3:
                '''in this case there is an apple'''
                self._board.mark_body(point.get_x(), point.get_y())
                self._board.mark_head(point.get_x() + 1, point.get_y())
            elif self._board.get_point(point.get_x() + 1, point.get_y()) == 0:
                self._board.mark_body(point.get_x(), point.get_y())
                self._board.mark_head(point.get_x() + 1, point.get_y())
                endpoint = self._board.get_endpoint()
                self._board.mark_end_body(endpoint.get_x() + 1, endpoint.get_y())
                self._board.mark_empty(endpoint)

    def move_left(self, n):
        for i in range(n):
            point = self._board.get_head_position()
            if point.get_y() + 1 < 0:
                return -1
            elif self._board.get_point(point.get_x(), point.get_y() - 1) == 2:
                return -1
            if self._board.get_point(point.get_x(), point.get_y() - 1) == 3:
                '''in this case there is an apple'''
                self._board.mark_body(point.get_x(), point.get_y())
                self._board.mark_head(point.get_x() , point.get_y() - 1)
            elif self._board.get_point(point.get_x(), point.get_y() - 1) == 3:
                self._board.mark_body(point.get_x(), point.get_y())
                self._board.mark_head(point.get_x() , point.get_y() - 1)
                endpoint = self._board.get_endpoint()
                self._board.mark_end_body(endpoint.get_x(), endpoint.get_y() - 1)
                self._board.mark_empty(endpoint)







