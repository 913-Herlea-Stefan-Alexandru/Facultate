from entity.point import Point


class BoardException(Exception):
    def __init__(self, msg):
        self._msg = msg

    def __str__(self):
        return self._msg

class Board:
    """
    Little legend
    0 - available point
    1 - the head of the snake
    2 - body
    3 - apple
    99 - end of the body
    -1 - position where can't be another apple
    """
    def __init__(self, row=0, column=0):
        self._row = row
        self._column = column
        self._board = []

    def get_row(self):
        """
        :return: number of rows
        """
        return self._row

    def get_column(self):
        """
        :return: number of columns
        """
        return self._column

    def set_row(self, row):
        """Setting the row"""
        self._row = row

    def set_column(self, column):
        """Setting the column"""
        self._column = column

    def create_board(self):
        """
        Creates the board

        :return:
        """
        for x in range(self._row):
            array = []
            for y in range(self._column):
                array.append(0)
            self._board.append(array)

    def available_move(self):
        """
        :return: the available moves
        """
        move = []
        for x in range(self.get_row()):
            for y in range(self.get_column()):
                if self._board[x][y] == 0:
                    move.append(Point(x, y))
        return move

    def mark_near_points(self, point):
        '''
        :param point: the apple
        :return: marks with -1 the positions adjacent to the apple on which another one
        cannot be placed
        '''
        x = point.get_x()
        y = point.get_y()
        if x >= 1 and y >= 1 and x < self.get_row() - 1 and y < self.get_column() - 1:
            if self._board[x - 1][y] == 0:
                self._board[x - 1][y] = -1
            if self._board[x + 1][y] == 0:
                self._board[x + 1][y] = -1
            if self._board[x][y + 1] == 0:
                self._board[x][y + 1] = -1
            if self._board[x][y - 1] == 0:
                self._board[x][y - 1] = -1

    def mark_head(self, i, j):
        self._board[i][j] = 1

    def mark_body(self, i, j):
        self._board[i][j] = 2

    def mark_end_body(self, i, j):
        self._board[i][j] = 99

    def mark_apple(self, i, j):
        self._board[i][j] = 3

    def get_head_position(self):
        for x in range(self.get_row()):
            for y in range(self.get_column()):
                if self._board[x][y] == 1:
                    return Point(x, y)

    def get_endpoint(self):
        for x in range(self.get_row()):
            for y in range(self.get_column()):
                if self._board[x][y] == 99:
                    return Point(x, y)

    def mark_empty(self, point):
        self._board[point.get_x()][point.get_y()] = 0

    def __len__(self):
        return len(self._board)

    def __str__(self):
        """
        :return:Overrided string function
        """
        string = "\n  "
        for x in range(self._column):
            string += str(x) + '   '
        for x in range(self._row):
            string += "\n "
            string += "-" * (4 * self._column + 1)
            string += "\n"
            string += str(x) + '|'
            for y in range(self._column):
                if self._board[x][y] == 1:  # 1 = the head
                    string +=  ' * ' + "|"
                elif self._board[x][y] == 2 or self._board[x][y] == 99:  # 2 = the body
                    string += ' + ' + "|"
                elif self._board[x][y] == 3:  # 3 = the apple
                    string += ' ' + '.' + ' ' + "|"
                else:
                    string += ' ' + ' ' + ' ' + "|"
        string += "\n "
        string += "-" * (4 * self._column + 1) + "\n"
        return string

    def get_board(self):
        """
        :return: the board
        """
        return self._board

    def get_point(self, x, y):
        return self._board[x][y]

    def destroy_board(self):
        """
        Function that sets the board to the "default" size
        """
        self._board = []
        self._row = 0
        self._column = 0

class ValidatePoint:
    @staticmethod
    def valid_point(x, y, board):
        """
        Function that validates the coordinates of a given point
        """
        try:
            x = int(x)
            y = int(y)
        except ValueError:
            raise BoardException("Please give integers!")
        if y < 0 or x < 0 or y >= board.get_column() or x >= board.get_row():
            raise BoardException("Point out of border!")
