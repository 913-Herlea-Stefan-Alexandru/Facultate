class Point:
    '''
    This is a point on the board, because the board is a matrix, a point has 2 coordinates
    '''
    def __init__(self, x, y):
        self._x = int(x)
        self._y = int(y)

    def get_x(self):
        return self._x

    def get_y(self):
        return self._y