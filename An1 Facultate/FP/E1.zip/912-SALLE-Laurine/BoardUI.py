from BoardRepo import BoardRepo
from BoardService import BoardService

class BoardUI:
    def __init__(self, boardService):
        self._boardService = boardService

    def show_board(self):
        print('\nActual board:')
        print(self._boardService.boardRepo.board)

    def move_snake_ui(self, cmd_params):
        if cmd_params == '':
            #move by 1 position
            self._boardService.move_snake_service(1)
        else:
            cmd_params = int(cmd_params)
            self._boardService.move_snake_service(cmd_params)
        if self._boardService.game_over is True:
            print('game over')
        self.show_board()

    def turn_up_ui(self, cmd_params):
        self._boardService.turn_service('up')

    def turn_right_ui(self, cmd_params):
        self._boardService.turn_service('right')

    def turn_left_ui(self, cmd_params):
        self._boardService.turn_service('left')

    def turn_down_ui(self, cmd_params):
        self._boardService.turn_service('down')

    def game_over(self):
        return self._boardService.game_over()