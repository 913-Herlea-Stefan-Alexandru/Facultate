class Snake:
    def __init__(self, board):
        self._board = board
        self._position = [[board.rows//2 -1, board.cols//2], [board.rows//2, board.cols//2], [board.rows//2 +1, board.cols//2]]
        self.direction = 'up'
        self.end = False

    @property
    def position(self):
        return self._position

    # @property
    # def direction(self):
    #     return self.direction
