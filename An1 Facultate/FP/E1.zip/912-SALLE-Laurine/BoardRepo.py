import random

from Board import Board


class BoardRepo:
    def __init__(self, board, snake):
        self._board = board
        self._snake = snake

    @property
    def board(self):
        return self._board

    @property
    def snake(self):
        return self._snake


    def move_snake_repo(self, number):

        for i in range(self.board.cols):
            for j in range(self.board.cols):
                # remove the snake
                if self.board.board[i][j] == '+' or self.board.board[i][j] == '*':
                    self.board.board[i][j] = ' '
        # draw the snake
        head_row = self.snake.position[0][0]
        head_col = self.snake.position[0][1]
        self.board.board[head_row][head_col] = '*'
        for i in range(1, len(self.snake.position)):
            body_row = self.snake.position[i][0]
            body_col = self.snake.position[i][1]
            self.board.board[body_row][body_col] = '+'

    def check_if_eat_apple(self):
        """
        add a + into the snake
        add a position in the snake
        :return:
        """
        number_apple = 0
        for i in range(len(self.snake.position)):
            pos_row = self.snake.position[i][0]
            pos_col = self.snake.position[i][1]
            check_apple = self.board.board[pos_row][pos_col]
            if check_apple == '.' : # if it is an apple:
                number_apple += 1
        return number_apple

    def add_new_apple(self, number):
        for i in range(number):
            validplace = False
            x = 1
            y = 1
            while validplace is False:
                x = random.randint(1, self.board.cols - 2)  # random number in the board
                y = random.randint(1, self.board.cols - 2)
                if self.board.board[x][y] is not ' ':
                    validplace = False
                elif self.board.board[x - 1][y] == '.' or self.board.board[x + 1][y] == '.' or self.board.board[x][y - 1] == '.' or \
                        self.board.board[x][y + 1] == '.':
                    validplace = False
                else:
                    validplace = True

            self.board.board[x][y] = '.'

    def turn_repo(self, direction):
        if self.snake.direction == 'up' and direction == 'down'\
            or self.snake.direction == 'down' and direction == 'up'\
            or self.snake.direction == 'right' and direction == 'left'\
            or self.snake.direction == 'left' and direction == 'right':
            raise ValueError('invalid turn')

        else:
            self.snake.direction = direction

    def game_over(self):
        return self.snake.end




