from Board import Board
from BoardUI import BoardUI
from BoardRepo import BoardRepo
from BoardService import BoardService
from Snake import Snake
from SnakeRepo import SnakeRepo


class Start:
    def __init__(self, board_ui):
        self._board_ui = board_ui

    def split_command(self, command):
        """
            Split command string into command word and parameters
            :return: (command_word, command_params)
        """
        command = command.strip() # remove the extra spaces
        tokens = command.split(' ', 1)
        command_word = tokens[0].strip().lower()
        command_params = tokens[1].strip() if len(tokens) == 2 else ''
        return command_word, command_params


    def start_command_ui(self):
        # display the game board
        self._board_ui.show_board()
        command_dict = {'move': self._board_ui.move_snake_ui, 'up': self._board_ui.turn_up_ui,
                        'right': self._board_ui.turn_right_ui, 'left': self._board_ui.turn_left_ui,
                        'down': self._board_ui.turn_down_ui}
        done = False
        while not done:
            command = input('command> ')
            try:
                # 1. split into command_word and command_params
                cmd_word, cmd_params = self.split_command(command)
                # 2. have separate functions for each command word
                if cmd_word in command_dict:
                    command_dict[cmd_word](cmd_params)
                elif cmd_word == 'exit':
                    done = True
                else:
                    print('bad command')
                    if self._board_ui.game_over:
                        print('Game over')
                        done = True
            except ValueError as ve:
                print(str(ve))


f = open("settings.properties", "r")
line = f.read().strip()
line = line.split('\n')
dim_line = line[0].split('=')
dim = int(dim_line[1].strip())
apple_count_line = line[1].split('=')
apple_count = int(apple_count_line[1].strip())


board = Board(dim, apple_count)
snake = Snake(board)
boardRepo = BoardRepo(board, snake)
snakeRepo = SnakeRepo(snake)
boardService = BoardService(boardRepo, snakeRepo)
boardUI = BoardUI(boardService)

game = Start(boardUI)
game.start_command_ui()