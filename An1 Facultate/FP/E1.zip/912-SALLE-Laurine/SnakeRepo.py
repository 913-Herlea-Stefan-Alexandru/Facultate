class SnakeRepo:
    def __init__(self, snake):
        self._snake = snake

    @property
    def snake(self):
        return self._snake

    def move_snake(self, number, direction):
        if (self.snake.position[0][0] - number) < 0:
            self.snake.end = True
        if direction == 'up':
            for i in range(len(self.snake.position)):
                self.snake.position[i][0] -= number

    def add_position(self, number, direction):
        if direction == 'up':
            for i in range(number):
                last_position = self.snake.position[-1]
                self.snake.position.append([last_position[0] + 1, last_position[1]])
    def game_over(self):
        return self.snake.end