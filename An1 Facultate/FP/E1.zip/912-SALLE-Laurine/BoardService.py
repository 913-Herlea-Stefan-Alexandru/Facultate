
from BoardRepo import BoardRepo
from SnakeRepo import SnakeRepo

class BoardService:
    def __init__(self, boardRepo, snakeRepo):
        self._boardRepo = boardRepo
        self._snakeRepo = snakeRepo

    @property
    def boardRepo(self):
        return self._boardRepo

    def move_snake_service(self, number):
        #change the snake position list
        direction = self._snakeRepo.snake.direction
        self._snakeRepo.move_snake(number, direction)
        # check if the snake overlaps an apple, if it is the case, add a position to the snake's tail, add apple randomly
        number_add = self._boardRepo.check_if_eat_apple()
        if number_add > 0:
            self._snakeRepo.add_position(number_add, direction)
            self._boardRepo.add_new_apple(number_add)
        # draw the snake on the board
        self._boardRepo.move_snake_repo(number)

    def turn_service(self, direction):
        self._boardRepo.turn_repo(direction)

    def game_over(self):
        return self._snakeRepo.game_over()
