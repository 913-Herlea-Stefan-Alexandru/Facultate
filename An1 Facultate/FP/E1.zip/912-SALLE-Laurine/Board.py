from texttable import Texttable
import random


class Board:
    def __init__(self, dim, apple_count):
        self._rows = dim
        self._cols = dim
        self._apple_count = apple_count
        self._board = [[' ' for i in range(self._rows)] for j in range(self._cols)]
        self.put_apples(self._apple_count)
        self.put_snake()

    @property
    def rows(self):
        return self._rows

    @property
    def cols(self):
        return self._cols

    @property
    def board(self):
        return self._board

    def put_snake(self):

        self.board[self._cols // 2 - 1][self._cols // 2] = '*'
        self.board[self._cols // 2][self._cols // 2] = '+'
        self.board[self._cols // 2 + 1][self._cols // 2] = '+'


    def put_apples(self, number):

        for i in range(number):
            validplace = False
            x = 1
            y = 1
            while validplace is False:
                x = random.randint(1, self._cols -2)  # random number in the board
                y = random.randint(1, self._cols -2)
                if self._board[x][y] is not ' ':
                    validplace = False
                elif self._board[x-1][y] == '.' or self._board[x+1][y] == '.' or self._board[x][y-1] == '.' or self._board[x][y+1] == '.':
                    validplace = False
                else:
                    validplace = True

            # x = random.randint(1, self._cols - 1)  # random number in the board
            # y = random.randint(1, self._cols - 1)

            self._board[x][y] = '.'


    def __str__(self):
        t = Texttable()
        for row in range(0, self._rows):
            board = []
            for val in self._board[row][:]:
                if val == '.':
                    board.append('.')
                elif val == '*':
                    board.append('*')
                elif val == '+':
                    board.append('+')
                else:
                    board.append(' ')
            t.add_row(board)
        return t.draw()
