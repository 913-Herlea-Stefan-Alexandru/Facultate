from Settings import Settings


class UI:
    def __init__(self, board_srv, game_srv):
        self._commands = {'move': self._move, 'right': self._go_right, 'down': self._go_down, 'left': self._go_left,
                          'up': self._go_up}
        self._board_srv = board_srv
        self._game_srv = game_srv

    def pre_start(self):
        done = False
        s = Settings()
        dim = int(s.dim)
        apple_count = int(s.apples)
        while not done:
            # print(self._board_srv.display(dim))
            self._board_srv.initialize_board(dim, apple_count)
            print(self._board_srv.display(dim))
            done = True

    def play(self):
        s = Settings()
        dim = int(s.dim)
        apple_count = int(s.apples)
        done = False
        while not done:
            try:
                command = input('command>> ')
                if command == 'exit':
                    return
                cmd_word, cmd_params = self.split_command(command)
                if command in self._commands:
                    self._commands[cmd_word](cmd_params)
                    print(self._board_srv.display(dim))
                else:
                    print('Bad command!')
            except ValueError as v:
                print(str(v))

    def split_command(self, command):
        command = command.strip()
        tokens = command.split(' ')
        cmd_word = tokens[0].strip()
        cmd_params = tokens[1].strip if len(tokens) == 2 else ''
        return cmd_word, cmd_params

    def _move(self, params):
        number = 0
        token = params.split(' ')
        for i in range(len(token)):
            token[i] = token[i].strip()
        if len(token) > 1:
            print('To many params!')
        elif params == '':
            number = 0
        else:
            number = int(token[0])
        self._game_srv.move(number)

    def _go_right(self, params):
        pass

    def _go_down(self, params):
        pass

    def _go_left(self, params):
        pass

    def _go_up(self, params):
        pass
