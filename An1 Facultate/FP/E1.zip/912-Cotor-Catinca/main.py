from Service.BoardSrv import BoardService
from Service.Game import Game
from Settings import Settings
from UI.Console import UI

if __name__ == '__main__':
    s = Settings()
    service_board = BoardService(int(s.dim))
    game = Game(int(s.dim))
    ui = UI(service_board, game)
    ui.pre_start()
    ui.play()