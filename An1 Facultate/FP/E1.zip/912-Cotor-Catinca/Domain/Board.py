from texttable import  Texttable

from Settings import Settings


class Board:
    def __init__(self, dim):
        self._rows = dim
        self.board = [[None for i in range(self._rows)] for j in range(self._rows)]

    def get_board(self, dim):
        t = Texttable()
        for row in range(dim):
            rows = []
            for index in self.board[row]:
                if index is None:
                    rows.append(' ')
                elif index == '*' or index == '.' or index == '+':
                    rows.append(index)
            t.add_row(rows)
        return t.draw()

    def __getitem__(self, item):
        return self.board[item]





