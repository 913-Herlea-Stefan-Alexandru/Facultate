from random import randint

from Domain.Board import Board
from Settings import Settings


class BoardService:
    def __init__(self, dim):
        self.board = Board(dim)
        self._di = [ -1, -1, 0, 1, 1, 1, 0, -1]
        self._dj = [ 0, 1, 1, 1, 0, -1, -1, -1]

    def display(self, dim):
        return self.board.get_board(dim)

    def initialize_board(self, dim, apple_count):
        mid = dim // 2
        self.board[mid-1][mid] = '*'
        self.board[mid][mid] = '+'
        self.board[mid+1][mid] = '+'

        while apple_count > 0:
            x = randint(0, dim-1)
            y = randint(0, dim-1)
            while self.board[x][y] == '+' or self.board[x][y] == '*' and self.valid(dim):
                x = randint(0, dim - 1)
                y = randint(0, dim - 1)
            self.board[x][y] = '.'
            apple_count -= 1

    def valid(self, dim):
        cnt = 0
        for i in range(dim):
            for j in range(dim):
                if self.board[i][j] == '.':
                    for d in range(8):
                        x = i
                        y = j
                        x += self._di[d]
                        y += self._dj[d]
                        while dim - 1  >= y >= 0 and dim - 1 >= x >= 0:
                            if self.board[x][y] == '.':
                                cnt += 1
                                break
                            x += self._di[d]
                            y += self._dj[d]
                    if cnt > 0:
                        return False
                    return True
