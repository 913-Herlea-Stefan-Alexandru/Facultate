from Domain.Board import Board


class Game:
    def __init__(self, dim):
        self.board = Board(dim)
        self._dim = dim

    def move(self, number):
        if number == 0:
            for i in range(self._dim):
                for j in range(self._dim):
                    if self.board[i][j] == '*':
                        if self.board[i+1][j] == '+':
                            aux = self.board[i+1][j]
                            self.board[i-1][j] = self.board[i][j]
                            self.board[i][j] = aux



