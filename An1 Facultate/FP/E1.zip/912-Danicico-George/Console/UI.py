from Game.game_service import ServiceException


class UI:

    @staticmethod
    def print_menu():
        print("move [n] - moves the snake n positions, if n isnt specified it moves one position")

    def __init__(self, game):
        self._game_service = game

    def make_a_move(self, parameters):
        if len(parameters) == 1:
            # it means that we will move the snake only one time
            self._game_service.move_one_step()
        else:
            number_of_moves = int(parameters[1])
            while number_of_moves:
                self._game_service.move_one_step()
                number_of_moves -= 1

        self.print_board()

    def move_up(self, command):
        self._game_service.set_direction('up')
        self.print_board()

    def move_left(self, command):
        self._game_service.set_direction('left')
        self.print_board()

    def move_right(self, command):
        self._game_service.set_direction('right')
        self.print_board()

    def move_down(self, command):
        self._game_service.set_direction('down')
        self.print_board()

    def print_board(self):
        print(self._game_service.board)

    def start(self):
        done = False

        command_dict = {'move': self.make_a_move,
                        'up': self.move_up,
                        'right': self.move_right,
                        'left': self.move_left,
                        'down': self.move_down
                        }
        print("Snake Game V1.0")
        self.print_board()
        while not done:
            UI.print_menu()
            try:
                command = input("Enter the command please: ")
                command = command.split(' ')
                if command[0] in command_dict:
                    command_dict[command[0]](command)
                else:
                    print("Invalid command entered!...\n")
            except ServiceException as ve:
                print(str(ve))
                done = True
                print("GAME OVER!")
            except Exception as ve:
                print(str(ve))
                done = True
                print("GAME OVER!")


