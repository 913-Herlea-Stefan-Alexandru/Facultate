import random

class Board:
    '''
    The board entity
    '''


    def __init__(self):

        with open("settings.txt", 'r') as f:
            lines = f.readlines()
            self._dim = int(lines[0])
            self._nr_apples = int(lines[1])
            self._snake = 3
        f.close()

        self._data = [[None for j in range(self._dim)] for i in range(self._dim)]

        for i in range(self._dim):
            for j in range(self._dim):
                if j == self._dim//2 :
                    if i == self._dim//2 - 1:
                        self._data[i][j] = '*'
                    elif i == self._dim//2 + 1 or i == self._dim//2 :
                        self._data[i][j] = '+'

        for x in range(self._nr_apples):
            i = random.randint(0,self._dim - 1)
            j = random.randint(0, self._dim - 1)
            while self._data[i][j] is not None:
                i = random.randint(0, self._dim - 1)
                j = random.randint(0, self._dim - 1)

            self._data[i][j] = '.'


    @property
    def dim(self):
        return self._dim

    @property
    def nr_apples(self):
        return self._nr_apples

    @property
    def data(self):
        return self._data

    def __str__(self):
        '''
        :return: The string representation of the board
        '''

        board = '-----------------------------\n'
        for i in range(self._dim):
            for j in range(self._dim):
                board += ' | '
                if self._data[i][j] is None:
                    board += ' '
                else:
                    board += str(self._data[i][j])
            board += ' | \n'
            board += '-----------------------------\n'
        return board

    def move(self,x,dir):
        for i in range(self._dim):
            for j in range(self._dim):
                if self._data[i][j] == '*':
                    i_head = i
                    j_head = j
                    break

        if dir == 'up':
            if x=='-':
                if i_head == 1 or i_head==0 or self._data[i_head-1][j_head]=='+':
                    return False
                else:

                    if self._data[i_head-1][j_head] is None:
                        for i in range(self._snake+1):
                            self._data[i_head-1+i][j_head] = self._data[i_head+i][j_head]
                        self._data[i_head+self._snake-1][j_head] = None

                    else:

                        self._snake = self._snake+1
                        for i in range(self._snake+1):
                            self._data[i_head-1+i][j_head] = self._data[i_head+i][j_head]
                        self._data[i_head + self._snake -2][j_head] = '+'

                        i = random.randint(0, self._dim - 1)
                        j = random.randint(0, self._dim - 1)
                        while self._data[i][j] is not None:
                            i = random.randint(0, self._dim - 1)
                            j = random.randint(0, self._dim - 1)

                        self._data[i][j] = '.'


            else:
                x = int(x[0])
                if i_head < x:
                    return False
                for i in range(x):
                    if self._data[i_head-1-i][j_head] == '+':
                        return False

                nr_ap = 0
                for i in range(self._snake + 1):
                    if self._data[i_head - x + i][j_head] == '.':
                        nr_ap = nr_ap + 1
                    self._data[i_head - x + i][j_head] = self._data[i_head + i][j_head]

                for x in range(nr_ap):
                    i = random.randint(0, self._dim - 1)
                    j = random.randint(0, self._dim - 1)
                    while self._data[i][j] is not None:
                        i = random.randint(0, self._dim - 1)
                        j = random.randint(0, self._dim - 1)

                    self._data[i][j] = '.'

                self._snake = self._snake + nr_ap



    def up(self):
        for i in range(self._dim):
            for j in range(self._dim):
                if self._data[i][j] == '*':
                    i_head = i
                    j_head = j
                    break
        if i_head == 0:
            return False

        self._data[i_head-1][j_head] = '*'
        self._data[i_head][j_head] = '+'


    def right(self):
        for i in range(self._dim):
            for j in range(self._dim):
                if self._data[i][j] == '*':
                    i_head = i
                    j_head = j
                    break
        if j_head == self._dim-1:
            return False
        self._data[i_head][j_head+1]='*'
        self._data[i_head][j_head] = '+'
        self._data[i_head+self._snake-1][j_head] = None

    def left(self):
        for i in range(self._dim):
            for j in range(self._dim):
                if self._data[i][j] == '*':
                    i_head = i
                    j_head = j
                    break
        if j_head == 0:
            return False

        self._data[i_head][j_head-1] = '*'
        self._data[i_head][j_head] = '+'
        self._data[i_head + self._snake - 1][j_head] = None

    def down(self):
        for i in range(self._dim):
            for j in range(self._dim):
                if self._data[i][j] == '*':
                    i_head = i
                    j_head = j
                    break
        if i_head == self._dim-1:
            return False

        self._data[i_head+1][j_head] = '*'
        self._data[i_head][j_head] = '+'




'''
b = Board()
print(b)
b.move('-','up')
print(b)
b.right()
print(b)
'''
