from entities import Board


class UI:
    def __init__(self):
        self._last_dir = 'up'


    def move_command_ui(self,command):
        tokens = command.split(' ', 1)
        command_params = tokens[1].strip() if len(tokens) == 2 else '-'
        return command_params


    def direction_command_ui(self,command_word,b):
        if command_word == 'up':
            if b.up() is False:
                print('Game over')
            b.up()
            self._last_dir = 'up'

        elif command_word == 'down':
            if b.down() is False:
                print('Game over')
            b.down()
            #self._last_dir = 'down'

        elif command_word == 'left':
            if b.left() is False:
                print('Game over')
            b.left()
            #self._last_dir = 'left'

        elif command_word == 'right':
            if b.right() is False:
                print('Game over')
            b.right()
            #self._last_dir = 'right'


    def start_game(self):
        b = Board()
        command_dict = {'move': self.move_command_ui,
                        'up': self.direction_command_ui('up',b),
                        'down': self.direction_command_ui('down',b),
                        'right': self.direction_command_ui('right',b),
                        'left': self.direction_command_ui('left',b)}
        done = False

        print(b)
        while not done:
            command = input('command> ')
            try:


                if command in ['up', 'down', 'right', 'left']:
                    command_dict[command,b]
                    print(b)

                elif command == 'move':
                    b.move('-','up')
                    #command_dict[command]
                    print(b)
                elif 'move' in command:
                    x = command_dict['move']
                    b.move(int(x),'up')
                    print(b)

                elif command == 'exit':
                    done = True
                else:
                    print('bad command')
            except ValueError as ve:
                print(str(ve))


ui = UI()
ui.start_game()

