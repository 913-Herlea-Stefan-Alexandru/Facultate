from board import Board
from ui import UI


def read_settings():
    SETTINGS_FILE = "settings/settings.properties"
    f = open(SETTINGS_FILE, "r")
    lines = f.read().split("\n")
    settings = {}
    for line in lines:
        setting = line.split("=")
        if len(setting) > 1:
            settings[setting[0]] = setting[1]
    f.close()
    return settings


if __name__ == "__main__":
    settings = read_settings()
    DIM = int(settings["DIM"])
    apple_count = int(settings["apple_count"])
    board = Board(DIM, apple_count)
    ui = UI(board)
    ui.run_game()
