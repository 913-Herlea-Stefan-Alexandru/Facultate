from texttable import Texttable
import random


class BoardException(Exception):
    def __init__(self, errors):
        self._errors = errors

    def getErrors(self):
        return self._errors


class Board:
    def __init__(self, size, apple_count):
        """
            1 - head of the snake
            2 - body segment
            -3 - apple
        """
        self._size = size
        self._apple_count = apple_count

        self._board = [[0 for x in range(size)] for y in range(size)]
        self._board[self._size // 2 - 1][self._size // 2] = 1
        self._board[self._size//2][self._size//2] = 2
        self._board[self._size // 2 + 1][self._size // 2] = 2
        self._randomize_apples()

    def get_symbol(self, x, y):
        return self._board[x][y]

    def set_symbol(self, x, y, symbol):
        self._board[x][y] = symbol

    def search_head(self):
        for i in range(0, self._size):
            for j in range(0, self._size):
                if self._board[i][j] == 1:
                    return i, j

    def place_apple_randomly(self):
        while True:
            row = random.randint(0, self._size)
            col = random.randint(0, self._size)
            if self._board[row][col] == 1 or self._board[row][col] == 2:
                break
        self._board[row][col] = -3

    def _randomize_apples(self):
        map = []
        for row in range(0, self._size):
            for col in range(0, self._size):
                if (row != self._size // 2 - 1 and col != self._size // 2) or \
                        (row != self._size//2 and col != self._size // 2) or \
                        (self._size // 2 + 1 and col != self._size // 2):
                    map.append((row, col))

        apples = self._apple_count
        while apples > 0:
            # choose the location of the next apple
            location = random.choice(map)
            row = location[0]
            col = location[1]
            # remove location from the list of eligible locations
            map.remove(location)
            self._board[row][col] = -3
            apples -= 1

    def move_up(self):
        row, col = self.search_head()
        if row - 1 < 0:
            raise BoardException("you exit up out of the board!")
        else:
            self.set_symbol(row - 1, col, 1)
            self.set_symbol(row, col, 2)

    def move_left(self):
        row, col = self.search_head()
        if col - 1 < 0:
            raise BoardException("you exit left out of the board!")
        else:
            self.set_symbol(row, col - 1, 1)
            self.set_symbol(row, col, 2)

    def move_right(self):
        row, col = self.search_head()
        if col + 1 >= self._size:
            raise BoardException("you exit left out of the board!")
        else:
            self.set_symbol(row, col + 1, 1)
            self.set_symbol(row, col, 2)

    def move_down(self):
        row, col = self.search_head()
        if row + 1 >= self._size:
            raise BoardException("you exit left out of the board!")
        else:
            self.set_symbol(row + 1, col, 1)
            self.set_symbol(row, col, 2)

    def remove_tail(self):
        for row in range(self._size):
            for col in range(self._size):
                pass

    def move_snake(self, row, col):
        head_row, head_col = self.search_head()
        new_head_row = head_row + row
        new_head_col = head_col + col
        if (new_head_row < 0) or (new_head_row >= self._size) or \
                (new_head_col < 0) or (new_head_col >= self._size):  # snake exited the board
            raise BoardException("game over!")
        elif self._board[new_head_row][new_head_col] > 0:  # snake "ate" himself
            raise BoardException("game over!")
        elif self._board[new_head_row][new_head_col] == -3:  # snake ate apple
            # self._board[head_row][head_col] = new_head_row, new_head_col
            self.place_apple_randomly()
        else:
            self._board[new_head_row][new_head_col] = 1 + self._board[head_row][head_col]
            self.remove_tail()

    def __str__(self):
        t = Texttable()
        # add each table row
        for row in range(0, self._size):
            row_data = []
            for val in self._board[row][0:self._size]:
                if val == 1:  # 1 - head of snake "*"
                    row_data.append("*")
                elif val == 2:  # 2 - body of snake "+"
                    row_data.append("+")
                elif val == -3:  # -3 - apple "."
                    row_data.append(".")
                else:
                    row_data.append(" ")
            t.add_row(row_data)
        return t.draw()
