from board import BoardException


class UI:
    def __init__(self, board):
        self._board = board

    def run_game(self):
        game_over = False
        print("\n• the snake first goes up!\n")
        while not game_over:
            print(self._board)
            move = input("\n• where to go? ")
            if move == "exit":
                print("thank you for playing snake! arrivederci!")
            elif move not in ["up", "down", "left", "right"]:
                try:
                    if move == "left":
                        self._board.move_left()
                    elif move == "up":
                        self._board.move_up()
                    elif move == "down":
                        self._board.move_down()
                    elif move == "right":
                        self._board.move_right()
                except BoardException as be:
                    print(be)
                    game_over = True
            elif move not in ["up", "down", "left", "right"]:
                print("• bad command!\n")
            else:
                print("• the snake moved " + move + ".\n")
