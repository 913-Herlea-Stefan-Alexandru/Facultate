import settings
from Domain.Entity import Board
from Repository.repositories import Repository
from Service.services import Service
from UI.Console import UI


dim=settings.DIM
apple_count=settings.apple_count

board = Board(dim, dim, apple_count)

repo=Repository(board)
ser=Service(repo)
ui=UI(ser)
ui.run()