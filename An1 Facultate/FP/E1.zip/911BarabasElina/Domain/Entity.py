from texttable import Texttable
import random


class Board:

    def __init__(self, rows, columns, number_of_apples):

        self._rows = rows
        self._columns = columns
        self._number_of_apples = number_of_apples
        self._data = [[0 for column in range(self._columns + 2)] for row in range(self._rows + 2)]
        self.place_apples()
        self.place_snake()

    def get_data(self):
        return self._data

    def clear(self):
        self._data = [[0 for column in range(self._columns + 2)] for row in range(self._rows + 2)]

    def set_cell(self, row, column, value):
        self._data[row][column] = value

    def get_cell(self, row, column):
        return self._data[row][column]

    def get_rows(self):
        return self._rows

    def get_columns(self):
        return self._columns

    def place_apples(self):

        apples=self._number_of_apples
        dimension=self._rows

        ok=True
        for index in range(0,self._rows):
            for second_index in range(0,self._columns):
                 if self._data[index][second_index]!=0:
                     ok=False

        if ok:
            while apples !=0:

                one_part_row=random.randint(0,dimension//2-1)
                second_part_row=random.randint(dimension//2+1,dimension-1)
                row=random.randint( one_part_row,second_part_row)

                one_part=random.randint(0,dimension//2-1)
                second_part=random.randint(dimension//2+1,dimension-1)
                column =random.randint(one_part,second_part)

                if self._data[row-1][column]!='.' and self._data[row+1][column]!='.' and self._data[row][column+1]!='.' and self._data[row][column-1]!='.' and self._data[row][column+1]!='.' and self._data[row-1][column-1]!='.' and self._data[row+1][column+1]!='.' and self._data[row-1][column+1]!='.' and self._data[row+1][column-1]!='.':
                    self._data[row][column]='.'
                else:
                    apples=apples+1
                    
                apples=apples-1

    def place_snake(self):

         ok=True
         for index in range(0,self._rows):
             for second_index in range(0,self._columns):
                  if self._data[index][second_index]=='*':
                      ok=False

         if ok:

             row_middle = self._rows //2
             column_middle =self._columns //2
             self._data[row_middle-1][column_middle]='*'
             self._data[row_middle][column_middle]='+'
             self._data[row_middle+1][column_middle]='+'

    def get_snake_position(self):

        row_middle = self._rows //2
        column_middle =self._columns //2
        return row_middle-1,column_middle,row_middle,column_middle,row_middle+1,column_middle


    def __str__(self):

        table = Texttable()

        for row in range(0, self._rows):
            data = []
            for value in self._data[row][0:self._columns]:
                data.append(value)
            table.add_row(data)
        return table.draw()







