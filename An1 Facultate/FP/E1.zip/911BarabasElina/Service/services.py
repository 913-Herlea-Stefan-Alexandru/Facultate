from Domain.Entity import Board
from Repository.repositories import Repository


class Service:

    def __init__(self, repository):
        self.__repository = repository

    def get_board(self):
        return self.__repository.get_board()

    def move_snake(self, direction, number_of_moves):

        board = self.__repository.get_data()
        row_head, column_head, row_body1, column_body1, row_body2, column_body2 = self.__repository.get_snake()

        if row_head == row_body1 and row_body1 == row_body2:

            if direction == 2:

                is_apple = self.__repository.get_cell(row_head - number_of_moves, column_head)
                if is_apple != '.':

                    column_head = column_head + number_of_moves
                    self.__repository.set_cell(row_head, column_head, '*')
                    column_body1 = column_body1 + number_of_moves
                    self.__repository.set_cell(row_body1, column_body1, '+')
                    column_body2 = column_body2 + number_of_moves
                    self.__repository.set_cell(row_body2, column_body2, '+')

                    while number_of_moves > 0:
                        column_body2 = column_body2 - 1
                        self.__repository.set_cell(row_body2, column_body2, 0)
                        number_of_moves -= number_of_moves
                else:
                    column_head = column_head + number_of_moves
                    self.__repository.set_cell(row_head, column_head, '*')
                    column_body1 = column_body1 + number_of_moves
                    self.__repository.set_cell(row_body1, column_body1, '+')
                    column_body2 = column_body2 + number_of_moves
                    self.__repository.set_cell(row_body2, column_body2, '+')

        if column_head == column_body1 and column_body2 == column_body1:

            if direction == -1:

                is_apple = self.__repository.get_cell(row_head - number_of_moves, column_head)
                if is_apple != '.':
                    row_head = row_head - number_of_moves
                    self.__repository.set_cell(row_head, column_head, '*')
                    row_body1 = row_body1 - number_of_moves
                    self.__repository.set_cell(row_body1, column_body1, '+')
                    row_body2 = row_body2 - number_of_moves
                    self.__repository.set_cell(row_body2, column_body2, '+')
                    self.__repository.set_cell(row_body2 + number_of_moves, column_body2, 0)

                    while number_of_moves > 0:
                        row_body2 = row_body2 + 1
                        self.__repository.set_cell(row_body2, column_body2, 0)
                        number_of_moves -= number_of_moves
                else:
                    row_head = row_head - number_of_moves
                    self.__repository.set_cell(row_head, column_head, '*')
                    row_body1 = row_body1 - number_of_moves
                    self.__repository.set_cell(row_body1, column_body1, '+')
                    row_body2 = row_body2 - number_of_moves
                    self.__repository.set_cell(row_body2, column_body2, '+')
                    self.__repository.set_cell(row_body2 + number_of_moves, column_body2, 0)
