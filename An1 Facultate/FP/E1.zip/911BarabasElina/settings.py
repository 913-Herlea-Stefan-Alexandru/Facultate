DIM=10
apple_count=5