from Domain.Entity import Board
from Repository.repositories import Repository
from Service.services import Service


class UI:

    def __init__(self, service):
        self.__service = service

    def run(self):

        print("Welcome to snake!")
        print(self.__service.get_board())
        we_play = True

        counter=0
        direction=-1

        """
        for direction we have 4 coordinates: if direction=-1 it means up, if direction=-2 it means left,
        if direction=2 it means right, if direction=1 it means down
        """
        while we_play:

            command = input('>>>')
            command = command.strip()
            parts = command.split()
            if parts[0] == 'exit':
                return
            else:

                if parts[0]=='move':
                    if len(parts) == 1:
                        if parts[0]=='move':
                            if counter==0:
                                number_of_moves=1
                                self.__service.move_snake(-1,number_of_moves)
                                counter=1
                            else:
                                number_of_moves = 1
                                self.__service.move_snake(direction, number_of_moves)
                                counter = 1
                            print(self.__service.get_board())

                    elif parts[0]=='move':
                            number_of_moves=int(parts[1])
                            if counter==0:
                                self.__service.move_snake(-1, number_of_moves)
                                counter = 1
                            else:
                                self.__service.move_snake(direction, number_of_moves)
                                counter = 1
                            print(self.__service.get_board())

                elif parts[0]=='up':
                    direction=-1
                    print(self.__service.get_board())
                elif parts[0] == 'right':
                    direction = 2
                    print(self.__service.get_board())
                elif parts[0]=='left':
                    direction=-2
                    print(self.__service.get_board())
                elif parts[0] == 'down':
                    direction = 1
                    print(self.__service.get_board())
                else:
                    print('bad command!')

