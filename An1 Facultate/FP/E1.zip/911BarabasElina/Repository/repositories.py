from Domain.Entity import Board


class Repository:

    def __init__(self, board):
        self.__board = board

    def get_board(self):
       return self.__board

    def get_data(self):
       return self.__board.get_data()
    def get_number_of_rows(self):
        return self.__board.get_rows()

    def get_number_of_columns(self):
        return self.__board.get_columns()

    def get_cell(self,row,column):
        return self.__board.get_cell(row,column)

    def set_cell(self,row,column,new_value):
        return self.__board.set_cell(row,column,new_value)

    def get_snake(self):

        coordinate1_head,coordinate2_head,coordinate1_body1,coordinate2_body1,coordinate1_body2,coordinate2_body2=self.__board.get_snake_position()
        return coordinate1_head,coordinate2_head,coordinate1_body1,coordinate2_body1,coordinate1_body2,coordinate2_body2
