from board import Board
from UI import UI


def get_from_settings(file_name):
    content=[]
    with open(file_name,'r') as c:
        line = c.readline().strip()
        while line != "":
            content.append(line)
            line = c.readline().strip()
        c.close()
    return int(content[0]),int(content[1])

dim,apples=get_from_settings('settings.properties')
board=Board(dim,apples)
UI=UI(board)
UI.run()
