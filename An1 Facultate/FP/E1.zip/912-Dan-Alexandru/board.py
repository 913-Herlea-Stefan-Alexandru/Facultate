import random

import numpy as np

class Board:
    def __init__(self,dim,apples):
        self.__direction='up'
        self.__snake_points=[]
        self.__apples=apples
        self.__dim=dim
        self.__board = np.full((int(dim), int(dim)), ' ')
        self.create_snake()
        self.update()
        self.place_apples(apples)

    @property
    def dim(self):
        return self.__dim

    @property
    def board(self):
        return self.__board

    @property
    def direction(self):
        return self.__direction
    @property
    def dimension(self):
        return self.__dim

    @direction.setter
    def direction(self,direction):
        self.__direction=direction

    def get(self,x,y):
        return self.__board[x][y]

    def is_free(self, x, y):
        return self.get(x, y) == ' '

    def create_snake(self):
        self.__snake_points.append({'row':self.__dim//2+1,'col':self.__dim//2})
        self.__snake_points.append({'row': self.__dim // 2 , 'col': self.__dim // 2})
        self.__snake_points.append({'row': self.__dim // 2 - 1, 'col': self.__dim // 2})

    def update(self):
        for i in range(self.__dim):
            for j in range(self.__dim):
                if self.__board[i][j]=='+' or self.__board[i][j]=='*':
                    self.__board[i][j]=' '
        for point in self.__snake_points:
            r = point['row']
            c = point['col']
            self.__board[r][c]='+'
        r=self.__snake_points[-1]['row']
        c=self.__snake_points[-1]['col']
        self.__board[r][c] = '*'

    def not_adiacent(self,r,c):
        if r==0:
            if c == 0:
                if  self.__board[r+1][c]=='.'  or self.__board[r][c+1]=='.':
                    return False
            elif c == self.__dim-1:
                if self.__board[r+1][c]=='.' or self.__board[r][c-1]=='.':
                    return False
            else:
                if self.__board[r + 1][c] == '.' or self.__board[r][c+1]=='.' or self.__board[r][c-1]=='.':
                    return False
        elif r== self.__dim-1:
            if c == 0:
                if  self.__board[r-1][c]=='.'  or self.__board[r][c+1]=='.':
                    return False
            elif c == self.__dim-1:
                if self.__board[r-1][c]=='.' or self.__board[r][c-1]=='.':
                    return False
            else:
                if self.__board[r - 1][c] == '.' or self.__board[r][c+1]=='.' or self.__board[r][c-1]=='.':
                    return False

        else:
            if c == 0:
                if  self.__board[r-1][c]=='.'  or self.__board[r][c+1]=='.' or self.__board[r+1][c]:
                    return False
            elif c == self.__dim-1:
                if self.__board[r-1][c]=='.' or self.__board[r][c-1]=='.' or self.__board[r+1][c]=='.':
                    return False
            else:
                if self.__board[r - 1][c] == '.' or self.__board[r][c+1]=='.' or self.__board[r][c-1]=='.' or self.__board[r + 1][c] == '.':
                    return False
        return True

    def number_of_available_places(self):
        nr=0
        for i in range(self.__dim):
            for j in range(self.__dim):
                if self.not_adiacent(i,j)==True:
                    nr += 1
        return nr

    def place_apple(self):
        done=True
        while done==True:
            try:
                r = random.randint(0, self.__dim-1)
                c = random.randint(0, self.__dim-1)
                if self.number_of_available_places()!=0:
                    if self.is_free(r, c) and self.not_adiacent(r,c)==True:
                        self.__board[r][c] = '.'
                        break
                    else:
                        raise ValueError
                else:
                    if self.is_free(r, c):
                        self.__board[r][c] = '.'
                        break
                    else :
                        raise ValueError
            except ValueError:
                done=True

    def place_apples(self,apples):
        for i in range(apples):
            self.place_apple()

    def get_head(self):
        head=self.__snake_points[-1]
        r = head['row']
        c = head['col']
        return r,c

    def move(self):
        r, c = self.get_head()
        if self.__direction == 'up':
           if self.get(r-1,c)=='.':
               self.__snake_points.append({'row':r-1,'col':c})
               self.place_apple()
           else:
               self.__snake_points.append({'row': r - 1, 'col': c})
               self.__snake_points.remove(self.__snake_points[0])
        elif self.__direction=='down':
            if self.get(r + 1, c) == '.':
                self.__snake_points.append({'row': r + 1, 'col': c })
                self.place_apple()
            else:
                self.__snake_points.append({'row': r + 1, 'col': c })
                self.__snake_points.remove(self.__snake_points[0])
        elif self.__direction=='right':
            if self.get(r , c+1) == '.':
                self.__snake_points.append({'row': r  , 'col': c + 1})
                self.place_apple()
            else:
                self.__snake_points.append({'row': r  , 'col': c + 1})
                self.__snake_points.remove(self.__snake_points[0])
        elif self.__direction=='left':
            if self.get(r , c-1) == '.':
                self.__snake_points.append({'row': r  , 'col': c - 1})
                self.place_apple()
            else:
                self.__snake_points.append({'row': r  , 'col': c - 1})
                self.__snake_points.remove(self.__snake_points[0])
        self.update()

    def change_direction(self,direction):
        if self.__direction=='up' and direction=='down':
            raise ValueError('Cant do a 180 degrees change in direction')
        elif  self.__direction=='down' and direction=='up':
            raise ValueError('Cant do a 180 degrees change in direction')
        elif  self.__direction=='left' and direction=='right':
            raise ValueError('Cant do a 180 degrees change in direction')
        elif  self.__direction=='right' and direction=='left':
            raise ValueError('Cant do a 180 degrees change in direction')
        else:
            self.__direction=direction







"""
board=Board(5,2)
board.update()
print(board.board)
board.move()
print(board.board)
"""


