
from game import Game

def split_command(command):
    command = command.strip()
    tokens = command.split(' ', 1)
    command_word = tokens[0].strip().lower()
    command_params = tokens[1].strip() if len(tokens) == 2 else ''
    return command_word, command_params
class UI:
    def __init__(self,board):
        self.__board=board
        self.__game=Game(self.__board)


    def run(self):
        print(self.__board.board)
        while self.__game.game_over==False:
            command=input('enter a command:')
            try:
                cmd_word, cmd_params = split_command(command)
                if cmd_word=='up':
                    if self.__board.direction!='up':
                        self.__board.change_direction('up')
                        self.__game.move()
                        print(self.__board.board)
                elif cmd_word=='down':
                    if self.__board.direction != 'down':
                        self.__board.change_direction('down')
                        self.__game.move()
                        print(self.__board.board)
                elif cmd_word == 'right':
                    if self.__board.direction != 'right':
                        self.__board.change_direction('right')
                        self.__game.move()
                        print(self.__board.board)
                elif cmd_word == 'left':
                    if self.__board.direction != 'left':
                        self.__board.change_direction('left')
                        self.__game.move()
                        print(self.__board.board)
                elif cmd_word == 'move':
                    if cmd_params == '':
                        self.__game.move()
                        print(self.__board.board)
                    else:
                        for i in range(int(cmd_params)):
                            self.__game.move()
                            if self.__game.game_over==True:
                                break
                        print(self.__board.board)
                else:
                    raise ValueError('Bad command')
            except ValueError as ve :
                print(str(ve))
        print('Game Over!')


