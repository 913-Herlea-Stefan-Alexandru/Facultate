
class Game():
    def __init__(self,board):
        self.__board=board
        self.__game_over=False

    @property
    def game_over(self):
        return self.__game_over

    def move(self):
        r,c = self.__board.get_head()
        if self.__board.direction=='up':
            if  r==0:
                self.__game_over=True
            elif self.__board.board[r-1][c]=='+' or self.__board.board[r-1][c]=='*' :
                self.__game_over = True
            else :
                self.__board.move()
        elif self.__board.direction=='down':
            if  r == self.__board.dimension-1:
                self.__game_over = True
            elif self.__board.board[r + 1][c] == '+' or self.__board.board[r + 1][c] == '*' :
                self.__game_over=True
            else:
                self.__board.move()
        elif self.__board.direction=='right':
            if  c == self.__board.dimension-1:
                self.__game_over=True
            elif self.__board.board[r][c+1]=='+' or self.__board.board[r][c+1]=='*' :
                self.__game_over=True
            else:
                self.__board.move()
        elif self.__board.direction=='left':
            if  c == 0:
                self.__game_over=True
            elif self.__board.board[r][c-1]=='+' or self.__board.board[r][c-1]=='*' :
                self.__game_over=True
            else:
                self.__board.move()




