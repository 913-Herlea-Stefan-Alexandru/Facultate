from Board.board import *


class Game:
    def __init__(self, dim, app):
        self._board = Board(int(dim), int(app))

    def get_board(self):
        return self._board

    def make_move(self):
        row = self._board.get_head()[0]
        col = self._board.get_head()[1]
        direction = self._board.get_direction()
        if direction == 'up':
            for i in range(self._board.row_count):
                for j in range(self._board.col_count):
                    if self._board.get_data()[i][j] == '*':
                        self._board.set_data(i - 1, j, '*')
                        self._board.set_data(i, j, ' ')
                    if self._board.get_data()[i][j] == '+':
                        self._board.set_data(i - 1, j, '+')
                        self._board.set_data(i, j, ' ')
        elif direction == 'left':
            for i in range(self._board.row_count):
                for j in range(self._board.col_count):
                    if self._board.get_data()[i][j] == '*':
                        self._board.set_data(i, j - 1, '*')
                        self._board.set_data(i, j, ' ')
            for i in range(self._board.row_count):
                for j in range(self._board.col_count):
                    if self._board.get_data()[i][j] == '+':
                        self._board.set_data(i - 1, j, '+')
                        self._board.set_data(i, j, ' ')
        # elif direction=='right':
        #     for i in range(self._board.row_count):
        #         for j in range(self._board.col_count):
        #             if self._board.get_data()[i][j]=='*':
        #                     self._board.set_data(i,j+1,'*')
        #                     self._board.set_data(i, j, ' ')
        # if direction == 'down':
        #     for i in range(self._board.row_count):
        #         for j in range(self._board.col_count):
        #             if self._board.get_data()[i][j] == '*':
        #                 self._board.set_data(i + 1, j, '*')
        #                 self._board.set_data(i, j, ' ')

    def eats_apple(self):
        count = 0
        for i in range(self._board.row_count):
            for j in range(self._board.col_count):
                if self._board.get_data()[i][j] == '.':
                    count += 1
        if count != self._board.get_apples():
            a = self._board.get_apples() - count
            while a > 0:
                self._board.place_new_apple()
                self._board.increase_length()
                #self.modify_snake() # if we comment this out the length won t go crazy
                a -= 1

    def modify_snake(self):
        count = 0
        for i in range(self._board.row_count):
            for j in range(self._board.col_count):
                if self._board.get_data()[i][j] == '*' or self._board.get_data()[i][j] == '*':
                    count += 1
        if count != self._board.get_length():
            a = self._board.get_length() - count
            while a > 0:
                head = self._board.get_head()
                dir = self._board.get_direction()
                if dir == 'up':
                    self._board.set_data(head[0] - 1, head[1], '*')
                    self._board.set_data(head[0], head[1], '+')
                a -= 1

    def game_over(self, direction):
        row = self._board.get_head()[0]
        col = self._board.get_head()[1]
        # the cases in which it hits the edge
        if direction == "down" and row == self._board.get_dimension() - 1:
            return True
        elif direction == "up" and row == 0:
            return True
        elif direction == "right" and col == self._board.get_dimension() - 1:
            return True
        elif direction == "left" and col == 0:
            return True
        data = self._board.get_data()
        if direction == "down" and data[row + 1][col] == '+':
            return True
        elif direction == "up" and data[row - 1][col] == '+':
            return True
        elif direction == "left" and data[row][col - 1] == '+':
            return True
        elif direction == "right" and data[row][col + 1] == '+':
            return True
        return False

    def check_new_direction(self, new):
        if new == 'up' and self._board.get_direction() == 'down':
            return False
        elif new == 'down' and self._board.get_direction() == 'up':
            return False
        elif new == 'left' and self._board.get_direction() == 'right':
            return False
        elif new == 'right' and self._board.get_direction() == 'left':
            return False
        return True
