from texttable import Texttable
from random import randint, choice


class Board:
    def __init__(self, dim, apple_count):
        self._dim = int(dim)
        self._apples = int(apple_count)
        self._rows = self._dim
        self._columns = self._dim
        self._direction = "up"
        self._length = 3
        # Empty squares marked with SPACE
        self._data = [[' ' for j in range(self._columns)] for i in range(self._rows)]
        self.place_first_snake()
        self.place_first_apples()

    def get_direction(self):
        return self._direction

    def set_direction(self, value):
        self._direction = value
        return self._direction

    def get_apples(self):
        return self._apples

    def increase_length(self):
        self._length += 1
        return self._length

    def get_length(self):
        return self._length

    @property
    def row_count(self):
        return self._rows

    @property
    def col_count(self):
        return self._columns

    def get_dimension(self):
        return self._dim

    def get_data(self):
        return self._data

    def set_data(self, x, y, value):
        self._data[x][y] = value
        return self._data

    def get_head(self):
        for i in range(self._dim):
            for j in range(self._dim):
                if self._data[i][j] == '*':
                    return [i, j]

    def __str__(self):
        """
        Function to display the board nicely
        :return:
        """
        t = Texttable()
        for row in range(self._rows):
            row_data = []

            for index in self._data[row]:
                if index == ' ':
                    row_data.append(' ')
                else:
                    row_data.append(index)

            t.add_row(row_data)

        return t.draw()

    def is_free(self, x):
        """
        Check if there is any place left in that column
        :param x:
        :return:
        """
        return self.get(0, x) == ' '

    def get(self, x, y):
        """
        Return symbol at position [x,y] on board
            ' '     -> empty square
            '*', '+' -> symbols from the snake
            '.' -> apple

        """
        return self._data[x][y]

    def place_first_snake(self):
        head = self._dim // 2
        self._data[head - 1][head] = '*'
        self._data[head][head] = '+'
        self._data[head + 1][head] = '+'

    def check_surroundings(self, x, y):
        if x == 0:
            if y == 0:
                return self._data[x][y] == " " and \
                       self._data[x][y + 1] == " " and \
                       self._data[x + 1][y] == " " and \
                       self._data[x + 1][y + 1] == " "

            elif y == self._dim - 1:
                return self._data[x][y] == " " and \
                       self._data[x][y - 1] == " " and \
                       self._data[x + 1][y] == " " and \
                       self._data[x - 1][y - 1] == " "

            else:
                return self._data[x][y] == " " and \
                       self._data[x][y + 1] == " " and \
                       self._data[x][y - 1] == " " and \
                       self._data[x + 1][y] == " " and \
                       self._data[x + 1][y + 1] == " " and \
                       self._data[x + 1][y - 1] == " "

        elif x == self._dim - 1:
            if y == 0:
                return self._data[x][y] == " " and \
                       self._data[x][y + 1] == " " and \
                       self._data[x - 1][y] == " " and \
                       self._data[x - 1][y + 1] == " "

            elif y == self._dim - 1:
                return self._data[x][y] == " " and \
                       self._data[x][y - 1] == " " and \
                       self._data[x - 1][y] == " " and \
                       self._data[x - 1][y - 1] == " "

            else:
                return self._data[x][y] == " " and \
                       self._data[x][y + 1] == " " and \
                       self._data[x][y - 1] == " " and \
                       self._data[x - 1][y] == " " and \
                       self._data[x - 1][y + 1] == " " and \
                       self._data[x - 1][y - 1] == " "

        elif y == 0:
            return self._data[x][y] == " " and \
                   self._data[x][y + 1] == " " and \
                   self._data[x - 1][y] == " " and \
                   self._data[x + 1][y] == " " and \
                   self._data[x - 1][y + 1] == " " and \
                   self._data[x + 1][y + 1] == " "

        elif y == self._dim - 1:
            return self._data[x][y] == " " and \
                   self._data[x][y - 1] == " " and \
                   self._data[x - 1][y] == " " and \
                   self._data[x + 1][y] == " " and \
                   self._data[x - 1][y - 1] == " " and \
                   self._data[x + 1][y - 1] == " "

        else:
            return self._data[x][y] == " " and \
                   self._data[x][y + 1] == " " and \
                   self._data[x][y - 1] == " " and \
                   self._data[x - 1][y] == " " and \
                   self._data[x + 1][y] == " " and \
                   self._data[x - 1][y + 1] == " " and \
                   self._data[x - 1][y - 1] == " " and \
                   self._data[x + 1][y - 1] == " " and \
                   self._data[x + 1][y + 1] == " "

    def place_first_apples(self):
        count = 0
        ok = False

        while not ok:
            i = randint(0, self._dim - 1)
            j = randint(0, self._dim - 1)

            if self.check_surroundings(i, j):
                self._data[i][j] = '.'
                count += 1

            if count == self._apples:
                ok = True

    def place_new_apple(self):
        count = 0
        ok = False

        while not ok:
            i = randint(0, self._dim - 1)
            j = randint(0, self._dim - 1)

            if self.check_surroundings(i, j):
                self._data[i][j] = '.'
                count += 1

            if count == 1:
                ok = True
