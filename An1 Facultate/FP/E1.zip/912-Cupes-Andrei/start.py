from jproperties import Properties
from Board.board import *
from UI.ui import *

configs = Properties()

with open('settings.properties', 'rb') as config_file:
    configs.load(config_file)

dim = configs.get("dimension").data
nr = configs.get("apple_count").data
# print(str(dim))
# print(str(nr))
ui = UI(dim, nr)

ui.start()
