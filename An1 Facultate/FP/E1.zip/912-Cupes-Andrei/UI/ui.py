from Game.game import Game


class UI:
    def __init__(self, dim, appl):
        self._game = Game(dim, appl)

    def welcome(self):
        print('WELCOME! THIS IS YOUR BOARD:')
        print(self._game.get_board())

    def gameover(self, direction):
        return self._game.game_over(direction)

    def finished(self):
        print("GAME OVER!")

    def move_more(self, cmd):
        cmd.split(' ')
        pos = cmd[5]
        pos = int(pos)
        while pos != 0:
            if self.gameover(self._game.get_board().get_direction()) is True:
                self.finished()
                done = True
                return done
            else:
                self._game.make_move()
                self._game.eats_apple()
                print(self._game.get_board())
            pos -= 1

    def move_one(self):
        if self.gameover(self._game.get_board().get_direction()) is True:
            self.finished()
            done = True
            return done
        else:
            self._game.make_move()
            self._game.eats_apple()
            print(self._game.get_board())

    def check_dir(self, cmd):
        if self.gameover(cmd):
            self.finished()
            done = True
            return done
        elif self._game.check_new_direction(cmd) is True:
            self._game.get_board().set_direction(cmd)
            print('DIRECTION WAS CHANGED TO: ' + cmd.upper())
            self.move_one()

    def start(self):
        self.welcome()

        done = False
        while not done:
            cmd = input('command>')
            if cmd == 'move':
                if self.move_one() is True:
                    done = True
            elif "move" in cmd:
                if self.move_more(cmd) is True:
                    done = True
            elif cmd == 'up' or cmd == 'left' or cmd == 'down' or cmd == 'right':
                if self.check_dir(cmd) is True:
                    done = True

            else:
                print('Invalid input!')
