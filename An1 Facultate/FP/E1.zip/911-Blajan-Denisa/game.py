from board import Board


class MoveSnake:
    def __init__(self, DIM, apple_count):
        self._rows = DIM
        self._columns = DIM
        self._apple_count = apple_count
        self._board = Board(DIM, apple_count)

    def eat_apple(self):
        for row in range(self._rows):
            for column in range(self._columns):
                if self._board[row][column] == '•':
                    pass

    def game_over(self, row, column):
        if self._board[row][column] == "*":
            if row == 0 and column != 0 and column != self._columns - 1:
                print("Game Over - snake hits the top wall!")
            elif row == 0 and column == 0:
                print("Game Over - snake hits the top wall!")
            elif row == 0 and column == self._columns - 1:
                print("Game Over - snake hits the top wall!")
            else:
                pass

            if row == self._rows - 1 and column != 0 and column != self._columns - 1:
                print("Game Over - snake hits the top wall!")
            elif row == self._rows - 1 and column == 0:
                print("Game Over - snake hits the top wall!")
            elif row == self._rows - 1 and column == self._columns - 1:
                print("Game Over - snake hits the top wall!")
            else:
                pass
            if column == 0 and row != 0 and row != self._rows - 1:
                print("Game Over - snake hits the top wall!")
            elif column == 0 and row == 0:
                print("Game Over - snake hits the top wall!")
            elif column == 0 and row == self._rows - 1:
                print("Game Over - snake hits the top wall!")
            else:
                pass

            if column == self._columns - 1 and row != 0 and row != self._rows - 1:
                print("Game Over - snake hits the top wall!")
            elif column == self._columns - 1 and row == 0:
                print("Game Over - snake hits the top wall!")
            elif column == self._columns - 1 and row == self._rows - 1:
                print("Game Over - snake hits the top wall!")
