from board import Board


def read_settings():
    settings_file = "settings.properties"
    f = open(settings_file, "r")
    lines = f.read().split("\n")
    settings = {}
    for line in lines:
        sett = line.split("=")
        if len(sett) > 1:
            settings[sett[0]] = sett[1]
    f.close()
    return settings


if __name__ == '__main__':
    settings = read_settings()
    DIM = int(settings["DIM"])
    apple_count = int(settings["apple_count"])
    board = Board(DIM, apple_count)
    print(board)
