import random

from texttable import Texttable


class Board:
    def __init__(self, DIM, apple_count, empty_cell=' '):
        self._rows = DIM
        self._columns = DIM
        self._apple_count = apple_count
        self._empty_cell = empty_cell
        self._board = self.create_board()
        self.snake_position()
        self.apples_positions()

    def get_rows(self):
        return self._rows

    def set_rows(self, value):
        self._rows = value

    def get_columns(self):
        return self._columns

    def set_columns(self, value):
        self._columns = value

    def get_empty_cell(self):
        return self._empty_cell

    def set_empty_cell(self, value):
        self._empty_cell = value

    def create_board(self):
        """
        creates the board for the game
        """
        board = []
        for row in range(int(self.get_rows())):
            board_rows = []
            for column in range(int(self.get_columns())):
                board_rows.append(self.get_empty_cell())
            board.append(board_rows)
        return board

    def snake_position(self):
        row_position = int(self._rows) // 2
        column_position = int(self._columns) // 2
        self._board[row_position - 1][column_position] = "*"
        self._board[row_position][column_position] = "+"
        self._board[row_position + 1][column_position] = "+"

    def apples_positions(self):
        table = []
        for row in range(self._rows):
            for column in range(self._columns):
                if self._board[row][column] == ' ':
                    table.append((row, column))

        apples_count = self._apple_count
        while apples_count > 0:
            position = random.choice(table)
            row = position[0]
            column = position[1]
            table.remove(position)
            if self._board[row - 1][column] == "•":
                self._board[row][column] = " "
            elif self._board[row][column - 1] == "•":
                self._board[row][column] = " "
            else:
                self._board[row][column] = "•"
                apples_count = apples_count - 1

    def __str__(self):
        """
        the board using Text table
        """
        board = Texttable()
        finish = []
        for row in range(int(self._rows)):
            finish.append(self._board[row])
            for column in range(int(self._columns)):
                finish[row][column] = self._board[row][column]
        for row in finish:
            board.add_row(row)
        return board.draw()
