


class Game:
    def __init__(self, board, validator ):
        self._board = board
        self._validator = validator
        self._harta = self._board.get_battlefield()
        self._snake = board.get_sarpe()


    def verif_map(self,x,y):
        if x<0 or y<0 or y > self._board.get_dimension() or x > self._board.get_dimension():
            return 1
        return 0
    def verif_coada(self,x,y):
        if self._harta[x][y] == 1 or self._harta[x][y] == 2:
            return 1
        else :
            return 0


    def move(self, steps):


        msg = ""
        sarpe = self._snake


        newx = sarpe.get_newx()
        newy =sarpe.get_newy()

        for i in range(0, steps):
            x = sarpe.get_x()
            y = sarpe.get_y()
            if self.verif_map(x+newx,y+newy) == 1 or self.verif_coada(x+newx, y+newy) ==1 :
                msg=  "Game over"
                return msg
            else:
                if self.verif_mar(x+newx , y +newy) == 1:

                    self._harta[x][y] = 2
                    self._harta[x+newx][y+newy] = 1
                    sarpe.set_lung(1)
                    self._board.place_apple(1)
                    msg += "Notice the snake grows longer." + '\n'
                else:

                    self._harta[x+newx][y+newy] = 1
                    self._harta[x][y] = 2
                    lungime = (sarpe.get_lung()-1)
                    minus =  -1
                    lungx = x + ((lungime  * newx) * minus)
                    lungy = y + ((lungime * newy) * minus)
                    self._harta[  lungx  ][ lungy] = 0 #elim coada

                sarpe.set_x(x+newx)
                sarpe.set_y(y+newy)

        return msg
    def validate(self,msg):
        string = self._validator.validate(msg)
        return string
    def eat_apple(self,x,y):
        pass

    def get_map(self):
        return self._board
    def verif_mar(self,x,y):
        "if mar return 1"
        if self._harta[x][y] == 3:
            return 1
        return 0