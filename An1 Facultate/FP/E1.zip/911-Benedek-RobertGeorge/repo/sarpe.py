
#actualy is domain

class snake:

    def __init__(self,x,y,newx,newy,lung):
        """ the starting point of head x,y and the direction newx newy , lung =the lenght """
        self._x = x
        self._y = y
        self._newx = newx
        self._newy = newy
        self._lung = lung


    def get_x(self):
        return self._x
    def get_y(self):
        return self._y

    def get_newy(self):
        return self._newy
    def get_newx(self):
        return self._newx

    def set_y(self,value):
        self._y = value
    def set_x(self,value):
        self._x = value

    def set_newx(self, value):
        self._newx = value

    def set_newy(self, value):
        self._newy = value

    def get_lung(self):
        return self._lung
    def set_lung(self,value):
        self._lung+= value

class Validator :
    def __init__(self):
        self._string = ""

    def validate(self, string):
        self._string =""
        lenn = len(string)
        if len(string )> 8:
            self._string += "The command is not ok. "
        string = string.split(" ")
        if string[0] != "down" and  string[0] != "up" and string[0] != "left" and string[0] != "right" and string[0]!='move':
            self._string += " The command its wrong written"
        if string[0] == "move" and lenn > 4:
            if (int(string[1]) >= 7):
                self._string +="You cant move so much"

        return self._string
