
class Settings:
    """
    A class that loads data from settings.properties
    and gives information about settings.
    """
    def __init__(self):
        self.dict= {}
        self._load()

    def _load(self):
        settings_file = open("settings.properties.properties", 'rt')

        lines = settings_file.readlines()

        settings_file.close()

        self.dict= {}

        for line in lines:
            line = line.split('=')
            line[0] = line[0].strip('\n "')
            line[1] = line[1].strip('\n "')
            self.dict[line[0]] = line[1]

    def settings(self, setting):
        if setting in self.dict :
            return self.dict[setting]

