

class UI:
    def __init__(self,service):
        self._service = service

    def move_ui(self,steps):

        msg = self._service.move(steps)

        if msg != "":
            print(msg)
        if msg == "Game over":
            return 1
        return 0

    def start(self):
        print(self._service.get_map())
        are_we_done = 0
        while not are_we_done:
            command = input(" > ")
            lenn = len(command)
           # msg = self._service.validate(command)
            command = command.split()
            msg=""
            if msg == "":

                if command[0] == 'move':
                    if lenn > 4 :
                        #print(int(command[1]))
                        are_we_done = self.move_ui(int(command[1]))
                    else :
                        are_we_done= self.move_ui(1)

                print(self._service.get_map())
            else :
                print(msg)
        print("Game over")
