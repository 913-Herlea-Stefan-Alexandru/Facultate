from User.UI import UI
from service.service import Game
from settings import Settings
from table.harta import Map
from repo.sarpe import *


settings_class = Settings()
dim = int(settings_class.settings('dim'))
apples = int(settings_class.settings('apple'))


#placing the initial board , snake and apples
sarpe = snake(dim//2-1,dim//2,-1,0,3)
validator = Validator()
map = Map(dim,apples,sarpe)
map.place_apple(apples)

service = Game(map,validator)
ui = UI(service)
ui.start()

print(map)
