from texttable import Texttable
import random



class Battlefield_exception(Exception):
    def __init__(self,mesaj):
        super().__init__(self,mesaj)

class MapException(Battlefield_exception):
    def __init__(self,mesaj):
        pass


class Map:
    def __init__(self,dimension , apples, sarpe):
        """make the map for ships"""
        self._battlefield = [[0 for col in range(dimension+1)]for line in range(dimension+1)]
        self._dimension = dimension
        self._apples = apples
        self._sarpe = sarpe
        self.place_snake()

    def get_sarpe(self):
        return self._sarpe

    def place_apple(self, number):

        ''' the function need the coordinates for a apple and it will be  marked '''
        mesaj = ""
        for nr in range(number):
            x,y = self.computer_hit()

            self._battlefield[x][y] = 3


    def place_snake(self):
        x = self._sarpe.get_x()
        y = self._sarpe.get_y()

        self._battlefield[x][y] = 1
        self._battlefield[x+1][y] = 2
        self._battlefield[x+2][y] = 2







    def get_battlefield(self):
        return self._battlefield

    def computer_hit(self):
        """random chose the coord """

        for i in range(0,15):
            x = random.randint(0, self._dimension - 1)
            y = random.randint(0, self._dimension - 1)
            if self.computer_hit_validator(x,y) == 1:
                return (x,y)



    def computer_hit_validator(self ,x,y):
        "check to be ook "
        if x > self._dimension  or x < 0 or y > self._dimension  or y < 0:
            return 0
        if (x-1 >= 0 and self._battlefield[x - 1][y] == 3 ) or (x+1 < self._dimension and self._battlefield[x + 1][y] == 3) :  # col
            return 0
        if (y+1 < self._dimension and self._battlefield[x][y+1] == 3 )or (y-1 >= 0 and self._battlefield[x][y-1] == 3): #linie
            return 0

        if self._battlefield[x][y] == 3:
            return 0
        if self._battlefield[x][y] == 1:
            return 0
        if self._battlefield[x][y] == 0 :
            return 1

        return 0


    def get_dimension(self):
        return self._dimension
    def __str__(self):
        '''making the texttable for the battlefield'''
        t = Texttable()
        header = [' ']




        index = 1

        for row in range(0,self._dimension+0):
            data = []


            for val in self._battlefield[row][0:-1]:
                if val >= 10 and val <20:
                    data.append("S" + str(val) )

                elif val == 3:
                    data.append('.')
                elif val == 1:
                    data.append('*')
                elif val == 2 :
                    data.append('+')
                else:
                    data.append(' ')
            t.add_row( data)
        return t.draw()

