class Snake:
    def __init__(self, head, body, direction):
        self._head = head
        self._body = body
        self._direction = direction  # 0 = up, 1 = right, 2 = down, 3 = left

    @property
    def head(self):
        return self._head

    @head.setter
    def head(self, value):
        self._head = value

    @property
    def body(self):
        return self._body

    @property
    def direction(self):
        return self._direction

    @direction.setter
    def direction(self, value):
        self._direction = value
