import random


class Game:
    def __init__(self, board, snake):
        self._board = board
        self._snake = snake

    @property
    def board(self):
        return self._board

    @property
    def snake(self):
        return self._snake

    def place_snake(self):
        self._board.board[(self._board.dim + 1) // 2 - 2][(self._board.dim + 1) // 2 - 1] = 10
        self._board.board[(self._board.dim + 1) // 2 - 1][(self._board.dim + 1) // 2 - 1] = 11
        self._board.board[(self._board.dim + 1) // 2][(self._board.dim + 1) // 2 - 1] = 11

    def can_place_apple(self):
        res = []
        for i in range(self._board.dim):
            for j in range(self._board.dim):
                if self._board.board[i][j] == 0:
                    ret_val = True
                    if i > 0:
                        if self._board.board[i - 1][j] != 0:
                            ret_val = False
                    if i < self._board.dim - 1:
                        if self._board.board[i + 1][j] != 0:
                            ret_val = False
                    if j > 0:
                        if self._board.board[i][j - 1] != 0:
                            ret_val = False
                    if j < self._board.dim - 1:
                        if self._board.board[i][j + 1] != 0:
                            ret_val = False
                    if ret_val:
                        res.append([i, j])
        return res

    def place_apples(self, nr_of_apples):
        lst = self.can_place_apple()
        while len(lst) != 0 and nr_of_apples > 0:
            elem = random.choice(lst)
            self._board.board[elem[0]][elem[1]] = 1
            nr_of_apples -= 1
            lst = self.can_place_apple()
        if nr_of_apples != 0:
            raise ValueError("No more apples can be placed")

    def is_valid_move(self):
        head = self._snake.head
        direction = self._snake.direction
        tail = self._snake.body[-1]
        self._board.board[tail[0]][tail[1]] = 0
        ret_val = False
        if direction == 0:
            if head[0] == 0:
                ret_val = False
            elif self._board.board[head[0] - 1][head[1]] < 10:
                ret_val = True
        elif direction == 1:
            if head[1] == self._board.dim - 1:
                ret_val = False
            elif self._board.board[head[0]][head[1] + 1] < 10:
                ret_val = True
        elif direction == 2:
            if head[0] == self._board.dim - 1:
                ret_val = False
            elif self._board.board[head[0] + 1][head[1]] < 10:
                ret_val = True
        elif direction == 3:
            if head[1] == 0:
                ret_val = False
            elif self._board.board[head[0]][head[1] - 1] < 10:
                ret_val = True
        self._board.board[tail[0]][tail[1]] = 11
        return ret_val

    def make_move(self):
        head = self._snake.head
        direction = self._snake.direction
        if self.is_valid_move():
            if direction == 0:  # if it is empty
                if self._board.board[head[0] - 1][head[1]] == 0:
                    self._snake.body.insert(0, [head[0], head[1]])
                    self._board.board[head[0]][head[1]] = 11
                    self._snake.head = [head[0] - 1, head[1]]
                    self._board.board[head[0] - 1][head[1]] = 10
                    tail = self._snake.body.pop()
                    self._board.board[tail[0]][tail[1]] = 0
                else:  # if it is an apple
                    self._snake.body.insert(0, [head[0], head[1]])
                    self._board.board[head[0]][head[1]] = 11
                    self._snake.head = [head[0] - 1, head[1]]
                    self._board.board[head[0] - 1][head[1]] = 10
                    self.place_apples(1)
            elif direction == 1:  # if it is empty
                if self._board.board[head[0]][head[1] + 1] == 0:
                    self._snake.body.insert(0, [head[0], head[1]])
                    self._board.board[head[0]][head[1]] = 11
                    self._snake.head = [head[0], head[1] + 1]
                    self._board.board[head[0]][head[1] + 1] = 10
                    tail = self._snake.body.pop()
                    self._board.board[tail[0]][tail[1]] = 0
                else:  # if it is an apple
                    self._snake.body.insert(0, [head[0], head[1]])
                    self._board.board[head[0]][head[1]] = 11
                    self._snake.head = [head[0], head[1] + 1]
                    self._board.board[head[0]][head[1] + 1] = 10
                    self.place_apples(1)
            elif direction == 2:  # if it is empty
                if self._board.board[head[0] + 1][head[1]] == 0:
                    self._snake.body.insert(0, [head[0], head[1]])
                    self._board.board[head[0]][head[1]] = 11
                    self._snake.head = [head[0] + 1, head[1]]
                    self._board.board[head[0] + 1][head[1]] = 10
                    tail = self._snake.body.pop()
                    self._board.board[tail[0]][tail[1]] = 0
                else:  # if it is an apple
                    self._snake.body.insert(0, [head[0], head[1]])
                    self._board.board[head[0]][head[1]] = 11
                    self._snake.head = [head[0] + 1, head[1]]
                    self._board.board[head[0] + 1][head[1]] = 10
                    self.place_apples(1)
            elif direction == 3:  # if it is empty
                if self._board.board[head[0]][head[1] - 1] == 0:
                    self._snake.body.insert(0, [head[0], head[1]])
                    self._board.board[head[0]][head[1]] = 11
                    self._snake.head = [head[0], head[1] - 1]
                    self._board.board[head[0]][head[1] - 1] = 10
                    tail = self._snake.body.pop()
                    self._board.board[tail[0]][tail[1]] = 0
                else:  # if it is an apple
                    self._snake.body.insert(0, [head[0], head[1]])
                    self._board.board[head[0]][head[1]] = 11
                    self._snake.head = [head[0], head[1] - 1]
                    self._board.board[head[0]][head[1] - 1] = 10
                    self.place_apples(1)
            return True
        else:
            return False
