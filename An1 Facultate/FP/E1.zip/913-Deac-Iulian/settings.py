class Settings:
    def __init__(self, file):
        self.file_name = file

    def dimension(self):
        file_open = open(self.file_name, "r")
        line = file_open.readline()
        while len(line) > 0:
            tokens = line.strip().split("=")
            if tokens[0] == "dim":
                return int(tokens[1])
            line = file_open.readline()
        file_open.close()

    def apples(self):
        file_open = open(self.file_name, "r")
        line = file_open.readline()
        while len(line) > 0:
            tokens = line.strip().split("=")
            if tokens[0] == "apple_count":
                return int(tokens[1])
            line = file_open.readline()
        file_open.close()
