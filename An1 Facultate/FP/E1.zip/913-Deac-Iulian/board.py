from texttable import Texttable


class Board:
    def __init__(self, dim, apple_count):
        self._dim = dim
        self._apple_count = apple_count
        self._board = []
        for i in range(self._dim):
            r = [0] * self._dim
            self._board.append(r)

    @property
    def board(self):
        return self._board

    @property
    def dim(self):
        return self._dim

    @property
    def apple_count(self):
        return self._apple_count

    def print_board(self):
        """
        0 = empty
        1 = apple
        10 = snake head
        11 = snake body
        """
        t = Texttable()
        for i in range(self.dim):
            r = []
            for j in range(self.dim):
                elem = self._board[i][j]
                if elem == 0:
                    r.append(' ')
                elif elem == 1:
                    r.append('.')
                elif elem == 10:
                    r.append('*')
                elif elem == 11:
                    r.append('+')
            t.add_row(r)
        return t.draw()
