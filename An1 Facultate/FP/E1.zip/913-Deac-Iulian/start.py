from board import Board
from game import Game
from settings import Settings
from snake import Snake


def start_game():
    settings = Settings('settings.properties')
    dim = settings.dimension()
    apple_count = settings.apples()

    b = Board(dim, apple_count)

    s_head = [(dim - 1) // 2 - 1, (dim - 1) // 2]
    s = Snake(s_head, [s_head, [s_head[0] + 1, s_head[1]], [s_head[0] + 2, s_head[1]]], 0)

    g = Game(b, s)

    g.place_snake()
    g.place_apples(apple_count)

    done = False
    while not done:
        try:
            print(g.board.print_board())
            command = input("give next command> ")
            tokens = command.split(" ")
            if tokens[0] == "exit":
                done = True
            elif tokens[0] == "move":
                if len(tokens) == 2 and tokens[1] != '':
                    for i in range(int(tokens[1])):
                        if not g.make_move():
                            print("game over")
                            done = True
                else:
                    if not g.make_move():
                        print("game over")
                        done = True
            elif tokens[0] == "up":
                if g.snake.direction == 2:
                    raise ValueError("can not go 180 degrees")
                elif g.snake.direction != 0:
                    g.snake.direction = 0
                    if not g.make_move():
                        print("game over")
                        done = True
            elif tokens[0] == "down":
                if g.snake.direction == 0:
                    raise ValueError("can not go 180 degrees")
                elif g.snake.direction != 2:
                    g.snake.direction = 2
                    if not g.make_move():
                        print("game over")
                        done = True
            elif tokens[0] == "right":
                if g.snake.direction == 3:
                    raise ValueError("can not go 180 degrees")
                elif g.snake.direction != 1:
                    g.snake.direction = 1
                    if not g.make_move():
                        print("game over")
                        done = True
            elif tokens[0] == "left":
                if g.snake.direction == 1:
                    raise ValueError("can not go 180 degrees")
                elif g.snake.direction != 3:
                    g.snake.direction = 3
                    if not g.make_move():
                        print("game over")
                        done = True
            else:
                print("bad command!")
        except ValueError as disaster:
            print(disaster)


start_game()
