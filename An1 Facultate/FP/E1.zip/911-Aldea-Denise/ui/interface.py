class Ui:
    def __init__(self, brain, board):
        self.__brain = brain
        self.__board = board

    def print_board(self):
        board = self.__board.board_copy()
        for x in range(self.__board.dimension()):
            for y in range(self.__board.dimension()):
                if board[x][y] == 0:
                    print("0 ", end='')
                elif board[x][y] == 1:
                    print("* ", end='')
                elif board[x][y] == 2:
                    print("+ ", end='')
                elif board[x][y] == 3:
                    print(". ", end='')
            print("")

    def main(self):
        game_over = False
        current_direction = "up"
        while not game_over:
            self.print_board()
            command = input("Enter a command: ")
            if "move" in command:
                game_over = self.__brain.move(command, current_direction)
                
            elif command == "up":
                if current_direction == "down":
                    print("The snake cannot turn 180 degrees!")
                elif current_direction != "up":
                    game_over = self.__brain.move_up(current_direction)
                    current_direction = "up"
                    
            elif command == "down":
                if current_direction == "up":
                    print("The snake cannot turn 180 degrees!")
                elif current_direction != "down":
                    game_over = self.__brain.move_up(current_direction)
                    current_direction = "down"
                    
            elif command == "left":
                if current_direction == "right":
                    print("The snake cannot turn 180 degrees!")
                elif current_direction != "left":
                    game_over = self.__brain.move_up(current_direction)
                    current_direction = "left"
                    
            elif command == "right":
                if current_direction == "left":
                    print("The snake cannot turn 180 degrees!")
                elif current_direction != "right":
                    game_over = self.__brain.move_up(current_direction)
                    current_direction = "right"
                    
            else:
                print("Incorrect command!")

            if game_over or self.__board.check_game_over():
                self.print_board()
                print("Game over!")
                game_over = True
