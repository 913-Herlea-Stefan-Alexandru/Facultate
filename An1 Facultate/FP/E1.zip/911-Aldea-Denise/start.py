from board.repository import GameBoard
from brain.functionalities import GameBrain
from ui.interface import Ui


settings = open("settings.txt", "r")
text = settings.read().split()
dimension = text[0]
apple_count = text[1]
gameboard = GameBoard(int(dimension), int(apple_count))
gamebrain = GameBrain(gameboard)
ui = Ui(gamebrain, gameboard)
ui.main()