class GameBrain:
    def __init__(self, board):
        self.__board = board

    def move(self, command, current_direction):
        if command == "move":
            valid = self.__board.check_in_front(current_direction)
            if valid:
                self.__board.move_by_one(current_direction)
            else:
                return True
        else:
            command = command.split()
            for i in range(int(command[1])):
                valid = self.__board.check_in_front(current_direction)
                if valid:
                    self.__board.move_by_one(current_direction)
                else:
                    return True

    def turn_up(self, current_direction):
        pass

    def turn_down(self, current_direction):
        pass

    def turn_left(self, current_direction):
        pass

    def turn_right(self, current_direction):
        pass
