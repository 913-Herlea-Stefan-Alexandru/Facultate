import random
import numpy as np


class GameBoard:
    def __init__(self, dimension, apple_count):
        self.__dimension = dimension
        self.__apple_count = apple_count
        # board: 0=free space, 1=snake head, 2=snake body, 3=apple
        self.__board = self.initialise_board(np.zeros((dimension, dimension)), dimension, apple_count)
        self.__head_x = dimension // 2 - 1
        self.__head_y = dimension // 2
        self.__tail_x = dimension // 2 + 1
        self.__tail_y = dimension // 2
        # direction: 1=up, 2=right, 3=down, 4=left; direction is up by default
        self.__body_direction = [1, 1, 1]

    @staticmethod
    def initialise_board(board, dimension, apple_count):
        # Place the snake in the middle of the board
        board[dimension // 2 - 1][dimension // 2] = 1
        board[dimension // 2][dimension // 2] = 2
        board[dimension // 2 + 1][dimension // 2] = 2

        # Randomly place the apples
        for i in range(apple_count):
            correct = False
            while not correct:
                x = random.randint(0, dimension-1)
                y = random.randint(0, dimension-1)
                while x == y:
                    y = random.randint(0, dimension - 1)
                # Check if the apple is in a corner or on a border
                if board[x][y] == 0:
                    if x == 0 and y == 0:
                        if board[x+1][y] == 0 and board[x][y+1] == 0:
                            board[x][y] = 3
                            correct = True
                    elif x == 0 and y == dimension-1:
                        if board[x][y-1] == 0 and board[x+1][y] == 0:
                            board[x][y] = 3
                            correct = True
                    elif x == dimension-1 and y == 0:
                        if board[x-1][y] == 0 and board[x][y+1] == 0:
                            board[x][y] = 3
                            correct = True
                    elif x == dimension-1 and y == dimension-1:
                        if board[x-1][y] == 0 and board[x][y-1] == 0:
                            board[x][y] = 3
                            correct = True
                    elif x == 0:
                        if board[x+1][y] == 0 and board[x][y+1] == 0 and board[x][y-1] == 0:
                            board[x][y] = 3
                            correct = True
                    elif x == dimension-1:
                        if board[x-1][y] == 0 and board[x][y+1] == 0 and board[x][y-1] == 0:
                            board[x][y] = 3
                            correct = True
                    elif y == 0:
                        if board[x+1][y] == 0 and board[x-1][y] == 0 and board[x][y+1] == 0:
                            board[x][y] = 3
                            correct = True
                    elif y == dimension-1:
                        if board[x+1][y] == 0 and board[x-1][y] == 0 and board[x][y-1] == 0:
                            board[x][y] = 3
                            correct = True
                    else:
                        if board[x-1][y] == 0 and board[x+1][y] == 0 and board[x][y+1] == 0 and \
                                board[x][y-1] == 0:
                            board[x][y] = 3
                            correct = True
        return board

    def board_copy(self):
        return self.__board.copy()

    def dimension(self):
        return self.__dimension

    def move_by_one(self, direction):
        if direction == "up":
            if self.check_in_front(direction):
                self.__board[self.__head_x][self.__head_y] = 2
                self.__head_x -= 1
                self.__board[self.__head_x][self.__head_y] = 1
                self.shift_directions()
                self.__body_direction[0] = 1
                self.__board[self.__tail_x][self.__tail_y] = 0
                self.move_tail()
        elif direction == "down":
            if self.check_in_front(direction):
                self.__board[self.__head_x][self.__head_y] = 2
                self.__head_x += 1
                self.__board[self.__head_x][self.__head_y] = 1
                self.shift_directions()
                self.__body_direction[0] = 3
                self.__board[self.__tail_x][self.__tail_y] = 0
                self.move_tail()
        elif direction == "left":
            if self.check_in_front(direction):
                self.__board[self.__head_x][self.__head_y] = 2
                self.__head_x += 1
                self.__board[self.__head_x][self.__head_y] = 1
                self.shift_directions()
                self.__body_direction[0] = 4
                self.__board[self.__tail_x][self.__tail_y] = 0
                self.move_tail()
        elif direction == "right":
            if self.check_in_front(direction):
                self.__board[self.__head_x][self.__head_y] = 2
                self.__head_x += 1
                self.__board[self.__head_x][self.__head_y] = 1
                self.shift_directions()
                self.__body_direction[0] = 2
                self.__board[self.__tail_x][self.__tail_y] = 0
                self.move_tail()

    def shift_directions(self):
        for i in range(1, len(self.__body_direction)):
            self.__body_direction[-i] = self.__body_direction[-i-1]

    def move_tail(self):
        if self.__body_direction[-1] == 1:
            self.__tail_x -= 1
        elif self.__body_direction[-1] == 2:
            self.__tail_y += 1
        elif self.__body_direction[-1] == 3:
            self.__tail_x += 1
        elif self.__body_direction[-1] == 4:
            self.__tail_y -= 1

    def check_for_apple(self, direction):
        if direction == "up":
            if self.__head_x - 1 == 3:
                return True
        elif direction == "down":
            if self.__head_x + 1 == 3:
                return True
        elif direction == "left":
            if self.__head_y - 1 == 3:
                return False
        elif direction == "right":
            if self.__head_y + 1 == 3:
                return False
        return True

    def check_in_front(self, direction):
        if direction == "up":
            if self.__head_x == 0:
                return False
        elif direction == "down":
            if self.__head_x == self.__dimension - 1:
                return False
        elif direction == "left":
            if self.__head_y == 0:
                return False
        elif direction == "right":
            if self.__head_y == self.__dimension - 1:
                return False
        return True

    def check_game_over(self):
        return False

