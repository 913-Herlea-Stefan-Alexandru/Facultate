from board import Board


class Game:
    def __init__(self, DIM, apple_count):
        self._board = Board(DIM, apple_count)

    def print_board(self):
        return self._board.board

    def move_snake(self, number_of_positions):
        """
        Moving the snake 'n' squares in the direction it is facing
        :param number_of_positions:
        :return:
        """
        snake_head_row, snake_head_column = self._board.snake_head[0], self._board.snake_head[1]
        body_row, body_column = self._board.snake_body[0], self._board.snake_body[1]
        if snake_head_row == body_row: #it can move either left or right
            if snake_head_column - body_column < 0:
                for index in range(number_of_positions):
                    over = self.move_snake_left(1)
            else:
                for index in range(number_of_positions):
                    over = self.move_snake_right(1)
        elif snake_head_column == body_column:
            if snake_head_row - body_row < 0:
                for index in range(number_of_positions):
                    over = self.move_snake_up(1)
            else:
                for index in range(number_of_positions):
                    over = self.move_snake_down(1)
        return over

    def move_snake_down(self, number_of_positions):
        snake_vector = self.snake_vector()
        # check if the snake can go to downwards

        head_row, head_column = snake_vector[0][0], snake_vector[0][1]
        body_row, body_column = snake_vector[1][0], snake_vector[1][1]

        if head_row - body_row < 0:
            raise ValueError("You cannot move down!")
            return

        if self.eaten_apple(head_row + 1, head_column) == 1:
            self._board.place_apple()
            apple_count = 1
        else:
            apple_count = 0

        for number_pos in range(number_of_positions):

            head_row, head_column = snake_vector[0][0], snake_vector[0][1]

            self._board.board[head_row + 1][head_column] = '*'
            self._board.board[head_row][head_column] = '+'
            # self._board.snake_head = [head_row, head_column+1]
            if self.eaten_apple(head_row, head_column):
                self._board.place_apple()
            for index in range(1, len(snake_vector)):
                prev_row = snake_vector[index - 1][0]
                prev_column = snake_vector[index - 1][1]
                #print(self._board.board[prev_row][prev_column], prev_row, prev_column)
                current_row = snake_vector[index][0]
                current_column = snake_vector[index][1]
                #print(current_row, current_column)
                self._board.board[current_row][current_column] = self._board.board[prev_row][prev_column]
            self._board.board[snake_vector[len(snake_vector) - 1][0]][snake_vector[len(snake_vector) - 1][1]] = ' '

        #if apple_count == 1:
        #    self._board.board[snake_vector[len(snake_vector) - 1][0]][snake_vector[len(snake_vector) - 1][1]] = '+'
        #else:
        self._board.board[snake_vector[len(snake_vector) - 1][0]][snake_vector[len(snake_vector) - 1][1]] = ' '

        self._board.board[snake_vector[len(snake_vector)-1][0]][snake_vector[len(snake_vector)-1][1]] = ' '
        self._board.snake_head = [head_row + 1, head_column]
        self._board.snake_body = [head_row, head_column]

        if self.you_hit_a_wall(head_row + 1, head_column ):
            return 0
        return 1

    def move_snake_up(self, number_of_positions):
        snake_vector = self.snake_vector()
        # check if the snake can go to upwards

        head_row, head_column = snake_vector[0][0], snake_vector[0][1]
        body_row, body_column = snake_vector[1][0], snake_vector[1][1]

        if head_row - body_row > 0:
            raise ValueError("You cannot move up!")
            return

        if self.eaten_apple(head_row + 1, head_column) == 1:
            self._board.place_apple()
            apple_count = 1
        else:
            apple_count = 0

        for number_pos in range(number_of_positions):

            head_row, head_column = snake_vector[0][0], snake_vector[0][1]
            self._board.board[head_row-1][head_column] = '*'
            self._board.board[head_row][head_column] = '+'
            # self._board.snake_head = [head_row, head_column+1]
            if self.eaten_apple(head_row, head_column):
                self._board.place_apple()
            for index in range(1, len(snake_vector)):
                prev_row = snake_vector[index - 1][0]
                prev_column = snake_vector[index - 1][1]
                #print(self._board.board[prev_row][prev_column], prev_row, prev_column)
                current_row = snake_vector[index][0]
                current_column = snake_vector[index][1]
                #print(current_row, current_column)
                self._board.board[current_row][current_column] = self._board.board[prev_row][prev_column]
            self._board.board[snake_vector[len(snake_vector) - 1][0]][snake_vector[len(snake_vector) - 1][1]] = ' '

        #if apple_count == 1:
        #    self._board.board[snake_vector[len(snake_vector) - 1][0]][snake_vector[len(snake_vector) - 1][1]] = '+'
        #else:
        self._board.board[snake_vector[len(snake_vector) - 1][0]][snake_vector[len(snake_vector) - 1][1]] = ' '

        self._board.board[snake_vector[len(snake_vector)-1][0]][snake_vector[len(snake_vector)-1][1]] = ' '
        self._board.snake_head = [head_row-1, head_column]
        self._board.snake_body = [head_row, head_column]

        if self.you_hit_a_wall(head_row-1, head_column):
            return 0
        return 1

    def move_snake_left(self, number_of_positions):
        snake_vector = self.snake_vector()
        # check if the snake can go to left

        head_row, head_column = snake_vector[0][0], snake_vector[0][1]
        body_row, body_column = snake_vector[1][0], snake_vector[1][1]

        if head_column - body_column > 0:
            raise ValueError("You cannot move left!")
            return

        if self.eaten_apple(head_row, head_column - 1) == 1:
            self._board.place_apple()
            apple_count = 1
        else:
            apple_count = 0

        for number_pos in range(number_of_positions):

            head_row, head_column = snake_vector[0][0], snake_vector[0][1]

            self._board.board[head_row][head_column - 1] = '*'
            self._board.board[head_row][head_column] = '+'
            # self._board.snake_head = [head_row, head_column+1]
            if self.eaten_apple(head_row, head_column):
                self._board.place_apple()
            for index in range(1, len(snake_vector)):
                prev_row = snake_vector[index - 1][0]
                prev_column = snake_vector[index - 1][1]
                #print(self._board.board[prev_row][prev_column], prev_row, prev_column)
                current_row = snake_vector[index][0]
                current_column = snake_vector[index][1]
                #print(current_row, current_column)
                self._board.board[current_row][current_column] = self._board.board[prev_row][prev_column]
            #self._board.board[snake_vector[len(snake_vector) - 1][0]][snake_vector[len(snake_vector) - 1][1]] = ' '


        self._board.board[snake_vector[len(snake_vector)-1][0]][snake_vector[len(snake_vector)-1][1]] = ' '
        self._board.snake_head = [head_row , head_column - 1]
        self._board.snake_body = [head_row, head_column]

        if self.you_hit_a_wall(head_row, head_column - 1):
            return 0
        return 1

    def move_snake_right(self, number_of_positions):
        snake_vector = self.snake_vector()
        #check if the snake can go to the right

        head_row, head_column = snake_vector[0][0], snake_vector[0][1]
        body_row, body_column = snake_vector[1][0], snake_vector[1][1]

        if body_column - head_column > 0:
            raise ValueError("You cannot move right!")
            return

        #TODO CHECK IF SNAKE HIT THE WALL
        for number_pos in range(number_of_positions):

            head_row, head_column = snake_vector[0][0], snake_vector[0][1]
            if self.eaten_apple(head_row, head_column+1) == 1:
                self._board.place_apple()
                apple_count = 1
            else:
                apple_count = 0
            self._board.board[head_row][head_column + 1] = '*'


            self._board.board[head_row][head_column] = '+'
            # self._board.snake_head = [head_row, head_column+1]
            if self.eaten_apple(head_row, head_column):
                self._board.place_apple()
            for index in range(1, len(snake_vector)):
                prev_row = snake_vector[index - 1][0]
                prev_column = snake_vector[index - 1][1]
                # print(self._board.board[prev_row][prev_column], prev_row, prev_column)
                current_row = snake_vector[index][0]
                current_column = snake_vector[index][1]
                # print(current_row, current_column)
                self._board.board[current_row][current_column] = self._board.board[prev_row][prev_column]
            #self._board.board[snake_vector[len(snake_vector) - 1][0]][snake_vector[len(snake_vector) - 1][1]] = ' '
            #if self.you_hit_a_wall(self.snake_vector()):
                #return 0
        #print(apple_count)
        #if apple_count == 1:
        #    self._board.board[snake_vector[len(snake_vector) - 1][0]][snake_vector[len(snake_vector) - 1][1]] = '+'
        #else:
        self._board.board[snake_vector[len(snake_vector) - 1][0]][snake_vector[len(snake_vector) - 1][1]] = ' '

        self._board.snake_head = [head_row, head_column + 1]
        self._board.snake_body = [head_row, head_column]

        if self.you_hit_a_wall(head_row, head_column + 1):
            return 0
        return 1

    def snake_vector(self):
        return self._board.find_snake_pos_vector()

    def eaten_apple(self, row, column):
        """
        Checks if by moving one square in a certain direction
        an apple has been eaten
        :return:
        """
        #print(row, column, self._board.board[row][column])
        if self.within_bounds(row, column):
            if self._board.get(row, column) == '.':
                return 1
            return 0


    def within_bounds(self, row, column):
        """
        If the snake is not within bounds the game is over
        :param row:
        :param column:
        :return:
        """
        return self._board.in_bounds(row, column)

    def you_hit_a_wall(self, row, column):
        """
        A snake has hit the wall if it's head it's gone/ out of bounds
        :param vector:
        :return: 1 if the snake has hit the wall, else 0
        """
        #print(row, column)
        if self.within_bounds(row, column) == 0:
            return 1
        return 0


