from game import Game


class UI:
    def __init__(self, DIM, apple_counter):
        self._game = Game(DIM, apple_counter)
        self._dimension = DIM

    def display_board(self):
        board = self._game.print_board()
        string = '-----------------\n'
        for i in range(self._dimension):
            for j in range(self._dimension):
                string += '|' + board[i][j]
            string += "| "
            string += "\n----------------\n"

        print(string)

    @staticmethod
    def menu():
        print()
        print("move n << move the snake `n` squares, in the direction it is currently facing.")
        print("up << snake goes up")
        print("down << snake goes down")
        print("left << snake goes left")
        print("right >> snake goes right")
        print()

    def parse_command(self, command):
        cmd = command.split(" ")
        if len(cmd) == 1:
            return cmd[0].lower(),None
        else:
            return cmd[0], cmd[1]

    def move_up(self):
        return self._game.move_snake_up(1)

    def move_down(self):
        return self._game.move_snake_down(1)

    def move_left(self):
        return self._game.move_snake_left(1)

    def move_right(self):
        return self._game.move_snake_right(1)

    def move(self, number_of_positions):
        return self._game.move_snake(number_of_positions)

    def start_ui(self):
        #display the empty board
        is_it_over_yet = 0
        over = 1
        #print(self._game.snake_vector())
        self.display_board()
        while not is_it_over_yet:
            self.menu()
            command = input("Input your command>> ")
            cm1, cm2 = self.parse_command(command)
            try:
                if cm2 is None:
                    if cm1 == 'left':
                        over = self.move_left()
                    elif cm1 == 'right':
                        over = self.move_right()
                    elif cm1 == 'up':
                        over = self.move_up()
                    elif cm1 == 'down':
                        over = self.move_down()
                    elif cm1 == 'move':
                        over = self.move(1)
                elif cm1 == 'move':
                    #print(int(cm2))
                    over = self.move(int(cm2))
            except ValueError as verror:
                print(str(verror))
            if over == 0:
                print("You hit a wall!")
                is_it_over_yet = 1
            else:
                self.display_board()


if __name__ == '__main__':
    try:
        f = open("settings.txt", 'rt')
        lines = f.readlines()
        f.close()

        for index in range(len(lines)):
            line = lines[index]
            tokens = line.split(" ")
            dimension_token = tokens[0].split("=")
            dimension = dimension_token[1]
            apple_token = tokens[1].split("=")
            apple_counter = apple_token[1]
    except IOError:
        raise ValueError("Input file not found!")

    SnakeGame = UI(int(dimension), int(apple_counter))
    SnakeGame.start_ui()
