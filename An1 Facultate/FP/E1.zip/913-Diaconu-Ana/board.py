import random


class Board:
    def __init__(self, DIM, apple_count):
        self._board = [[' ' for i in range(DIM+1)] for j in range(DIM+1)]
        self._dimension = DIM
        self._apple_count = apple_count
        self.place_snake_init()
        snake_row, snake_column = self.find_snake_head()
        self._snake_head = [snake_row, snake_column]
        body_1, body_2 = self.find_snake_body()
        self._snake_body = [body_1, body_2]

        for i in range(self._apple_count):
            self.place_apple()

    def __str__(self):
        string = '------------------\n'
        for i in range(self._dimension):
            for j in range(self._dimension):
                string += '|'+self._board[i][j]
            string +="| "
            string += "\n-----------------\n"

        return string

    def set(self, row, column, symbol):
        self._board[row][column] = symbol

    def get(self,  row,   column):
        return self._board[row][column]

    @property
    def snake_head(self):
        return self._snake_head

    @snake_head.setter
    def snake_head(self, value):
        self._snake_head[0] = value[0]
        self._snake_head[1] = value[1]

    @property
    def snake_body(self):
        return self._snake_body

    @snake_body.setter
    def snake_body(self, value):
        self._snake_body[0] = value[0]
        self._snake_body[1] = value[1]

    @property
    def board(self):
        return self._board

    def in_bounds(self,  row, column):
        if row < 0 or row >= self._dimension:
            return 0
        if column < 0 or column >= self._dimension:
            return 0
        return 1

    def check_if_possible_to_place(self, row, column):
        """
        Check if you can place an apple on a certain position
        :param row:
        :param column:
        :return:
        """
        if self._board[row][column] != ' ':
            return 0

        if self.in_bounds(row-1, column):
            if self._board[row-1][column] == ' ':
                ok1 = 1
            else:
                ok1 = 0
        else:
            ok1 = 1

        if self.in_bounds(row+1, column):
            if self._board[row+1][column] == ' ':
                ok2 = 1
            else:
                ok2 = 0
        else:
            ok2 = 1

        if self.in_bounds(row, column-1):
            if self._board[row][column-1] == ' ':
                ok3 = 1
            else:
                ok3 = 0
        else:
            ok3 = 1

        if self.in_bounds(row, column+1):
            if self._board[row][column+1] == ' ':
                ok4 = 1
            else:
                ok4 = 0
        else:
            ok4 = 1

        return ok1 and ok2 and ok3 and ok4

    def place_apple(self):
        """
        Randomly places an apple on the board
        so that two apples cannot be adjacent on the row/column,
        cannot overlap the snake's starting position
        :return:
        """
        row = random.randrange(0, self._dimension-1)
        column = random.randrange(0, self._dimension-1)
        while not (self.in_bounds(row, column) and self.check_if_possible_to_place(row, column)):
            row = random.randrange(0, self._dimension - 1)
            column = random.randrange(0, self._dimension - 1)
        else:
            self._board[row][column] = '.'
            #print("Placed apple", row, column)

    def place_snake_init(self):
        """
        Places snake in the middle of the board
        :return:
        """
        middle_column = self._dimension // 2
        head = middle_column - 1
        body2 = middle_column + 1

        self._board[head][middle_column] = '*'
        self._board[middle_column][middle_column] = '+'
        self._board[body2][middle_column] = '+'

    def find_snake_head(self):
        for i in range(self._dimension):
            for j in range(self._dimension):
                if self._board[i][j] == '*':
                    return i,j

    def find_snake_body(self):
        """
        Find the first body part directly tied to the head
        :return:
        """
        row, column = self.find_snake_head()
        if self.in_bounds(row-1, column):
            if self._board[row-1][column] == '+':
                return row-1, column

        if self.in_bounds(row+1, column):
            if self._board[row+1][column] == '+':
                return row+1, column

        if self.in_bounds(row, column-1):
            if self._board[row][column-1] == '+':
                return row, column - 1

        if self.in_bounds(row, column+1):
            if self._board[row][column+1] == '+':
                return row, column+1

    def check_if_coordinates_in_the_list(self, list, row, column):
        for index in list:
            if index[0] == row and index[1] == column:
                return 0
        return 1

    def find_snake_pos_vector(self):
        """
        Makes a list of the snake body parts
        """
        list = [self._snake_head]
        list.append(self._snake_body)
        over = 0
        while not over:
            row, column = list[-1][0], list[-1][1]
            if self.in_bounds(row - 1, column) and self._board[row - 1][column] == '+':
                    if self.check_if_coordinates_in_the_list(list, row - 1, column):
                        list.append([row - 1, column])
            elif self.in_bounds(row + 1, column) and self._board[row + 1][column] == '+':
                    if self.check_if_coordinates_in_the_list(list, row + 1, column):
                        list.append([row + 1, column])
            elif self.in_bounds(row, column - 1) and self._board[row][column - 1] == '+':
                    if self.check_if_coordinates_in_the_list(list, row, column - 1):
                        list.append([row, column - 1])
            elif self.in_bounds(row, column + 1) and self._board[row][column + 1] == '+':
                    if self.check_if_coordinates_in_the_list(list, row, column + 1):
                        list.append([row - 1, column + 1])

            over = 1

        return list




