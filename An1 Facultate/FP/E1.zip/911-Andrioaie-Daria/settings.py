from jproperties import Properties

from Domain.board import Board
from Domain.snake import Snake
from Service.game import GameService
from UI.console_based_ui import ConsoleUI


class PropertiesConfiguration:
    def __init__(self):
        self._configurations = Properties()
        self._file_name = 'settings.properties'

        settings_file = open(self._file_name, 'rb')
        self._configurations.load(settings_file)

        try:
            self._board_dimension = int(self._configurations.get("dimension").data)
            self._apple_count = int(self._configurations.get('apple_count').data)
        except KeyError as error_message:
            print(error_message)
            exit(0)

    def start(self):
        board = Board(self._board_dimension, self._apple_count)
        game_service = GameService(board)
        ui = ConsoleUI(game_service)
        ui.start()
