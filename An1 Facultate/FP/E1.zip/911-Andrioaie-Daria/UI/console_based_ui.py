class ConsoleUI:
    def __init__(self, game_service):
        self._game = game_service

    @property
    def game_service(self):
        return self._game

    def is_game_draw(self):
        pass

    def is_game_lost(self):
        pass

    def print_board(self):
        board_of_game = self.game_service.board
        print(board_of_game)

    def make_move(self, command_parameters):
        if command_parameters == '':
            command_parameters = 1
        self.game_service.make_forward_move(int(command_parameters))

    def change_direction(self, direction):
        pass

    def read_user_command(self):
        user_command = input("Next move: ")
        return user_command

    def split_user_command(self, command):
        """
        Splits the command entered by the user into a command_word and command_parameters
        :param command: the command typed by the user
        :return: a list in which the first element is the command word and the second are the command parameters
        """

        command_as_units = command.strip().split(" ", 1)

        if len(command_as_units) == 1:
            command_as_units.append('')
        return command_as_units


    def start(self):

        while not self.is_game_lost() and not self.is_game_draw():
            self.print_board()
            print('\n')
            print('\n')
            try:
                users_choice = self.read_user_command()
                command_word, command_parameters = self.split_user_command(users_choice)
                if command_word == "move":
                    self.make_move(command_parameters)
                elif command_word == "up" or command_word == "down" or command_word == "right" or command_word == "left":
                    self.change_direction(command_word)
                else:
                    print("Bad command.")

            except Exception as exception_message:
                print(exception_message)

        self.print_board()

        if self.is_game_lost():
            print('Game over!')
        elif self.is_game_draw():
            print('The snake reached its maximum length. Good job!')
