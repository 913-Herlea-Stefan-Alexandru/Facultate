class GameService:
    def __init__(self, board):
        self._board = board

    def get_snake(self):
        return self.board.snake

    def get_snake_direction(self):
        snake = self.get_snake()
        return snake.current_direction

    def get_apples(self):
        return self.board.placed_apples

    def get_snake_body(self):
        snake = self.get_snake()
        return snake.body

    def get_board_dimension(self):
        return self.board.dimension

    @property
    def board(self):
        return self._board

    def make_forward_move(self, number_of_steps):
        snake_body = self.get_snake_body()

        # remove the old version of the snake from the board
        self.board.clear_snake()

        # change the snake coordinates
        for step in range(number_of_steps):
            direction = self.get_snake_direction()
            row_head_coordinates = snake_body[0][0]
            row_of_predecessor = row_head_coordinates
            column_head_coordinates = snake_body[0][1]
            column_of_predecessor = column_head_coordinates

            if direction == "up":
                # row_head_coordinates -= 1
                snake_body[0][0] -= 1
            if direction == "down":
                #row_head_coordinates += 1
                snake_body[0][0] += 1
            if direction == "left":
                #column_head_coordinates -= 1
                snake_body[0][1] -= 1
            if direction == "right":
                #column_head_coordinates += 1
                snake_body[0][1] += 1


            for index in range(len(snake_body)-1):
                old_row_coordinate = snake_body[index+1][0]
                old_column_coordinate = snake_body[index+1][1]

                snake_body[index+1][0] = row_of_predecessor
                snake_body[index+1][1] = column_of_predecessor

                row_of_predecessor = old_row_coordinate
                column_of_predecessor = old_column_coordinate


        # if the new coordinates of the snake exceed the boundaries of the board, the game is lost
        if self.is_game_lost():
            return



        # if the snake ate an apple, grow in length
        eaten_apples = self.ate_apples()
        if eaten_apples:
            self.grow_in_length(eaten_apples)
            self.place_new_apples(eaten_apples)

        # place snake back
        self.board.place_snake()

    def grow_in_length(self, amount_of_ate_apples):
        for i in range(amount_of_ate_apples):
            direction = self.get_snake_direction()
            snake_body = self.get_snake_body()
            row_of_last_part = snake_body[-1][0]
            column_of_last_part = snake_body[-1][1]

            if direction == "up":
                row_of_new_part = row_of_last_part + 1
                column_of_new_part = column_of_last_part

            elif direction == "down":
                row_of_new_part = row_of_last_part - 1
                column_of_new_part = column_of_last_part

            elif direction == "left":
                row_of_new_part = row_of_last_part
                column_of_new_part = column_of_last_part + 1

            elif direction == "right":
                row_of_new_part = row_of_last_part
                column_of_new_part = column_of_last_part - 1

            self.get_snake_body().append([row_of_new_part, column_of_new_part])
            snake = self.get_snake()
            snake.body_length += 1

    def ate_apples(self):
        amount_of_eaten_apples = 0
        placed_apples = self.get_apples()
        snake_body = self.get_snake_body()
        for apple in placed_apples:
            if apple in snake_body:
                amount_of_eaten_apples += 1

        return amount_of_eaten_apples

    def is_game_lost(self):
        head_coordinates = self.get_snake_body()[0]
        row_head_coordinate = head_coordinates[0]
        column_head_coordinate = head_coordinates[1]
        if row_head_coordinate < 0 or row_head_coordinate >= self.get_board_dimension():
            return True

        if column_head_coordinate < 0 or column_head_coordinate >= self.get_board_dimension():
            return True

        return False

    def place_new_apples(self, amount_of_new_apples):
        self.board.place_new_apples(amount_of_new_apples)