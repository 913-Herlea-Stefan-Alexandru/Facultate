from settings import PropertiesConfiguration

game = PropertiesConfiguration()
game.start()