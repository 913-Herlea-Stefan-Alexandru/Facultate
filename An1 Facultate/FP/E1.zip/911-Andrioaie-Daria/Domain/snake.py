class Snake:
    def __init__(self, board_dimension):
        center = board_dimension // 2
        self._body = []
        self.body.append([center-1, center])
        self.body.append([center, center])
        self.body.append([center + 1, center])

        self._body_length = 2
        self._current_direction = "up"


    @property
    def body_length(self):
        return self._body_length

    @body_length.setter
    def body_length(self, value):
        self._body_length = value

    @property
    def current_direction(self):
        return self._current_direction

    @current_direction.setter
    def current_direction(self, new_direction):
        self._current_direction = new_direction

    @property
    def body(self):
        return self._body