from random import randint

import texttable

from Domain.snake import Snake


class Board:
    """
    Class that represents the m x m board of the game, in the form of a matrix.
    """
    def __init__(self, dimension, apple_count):
        self._dimension = dimension
        self._representation_of_data = [[None for column in range(self._dimension)] for row in range(self._dimension)]
        self._snake = Snake(dimension)

        self._apple_count = apple_count
        self.place_snake()
        self._placed_apples = self.place_apples()

    @property
    def dimension(self):
        """
        Getter method for the number of rows.
        """
        return self._dimension

    @property
    def snake(self):
        return self._snake

    @property
    def apple_count(self):
        return self._apple_count

    @property
    def placed_apples(self):
        return self._placed_apples


    def place_snake(self):
        head_coordinates = self.snake.body[0]
        row_head_coordinates = head_coordinates[0]
        column_head_coordinates = head_coordinates[1]
        self._representation_of_data[row_head_coordinates][column_head_coordinates] = "*"

        for i in range(self.snake.body_length):
            row_body_part = self.snake.body[i+1][0]
            column_body_part = self.snake.body[i+1][1]
            self._representation_of_data[row_body_part][column_body_part] = "+"

    def clear_snake(self):
        head_coordinates = self.snake.body[0]
        row_head_coordinates = head_coordinates[0]
        column_head_coordinates = head_coordinates[1]
        self._representation_of_data[row_head_coordinates][column_head_coordinates] = " "

        for i in range(self.snake.body_length):
            row_body_part = self.snake.body[i + 1][0]
            column_body_part = self.snake.body[i + 1][1]
            self._representation_of_data[row_body_part][column_body_part] = " "


    def is_adjacent(self, row, column, placed_apples):
        center = self.dimension // 2
        #if (row == center and column == center) or (row == center+1 and column == center) or (row == center + 2 and column == center):
        if [row, column] in self.snake.body:
            return True

        for apple in placed_apples:
            row_of_already_placed_apple = apple[0]
            column_of_already_placed_apple = apple[1]
            if row == row_of_already_placed_apple and abs(column_of_already_placed_apple - column) == 1:
                return True
            if column == column_of_already_placed_apple and abs(row - row_of_already_placed_apple) == 1:
                return True
            if column == column_of_already_placed_apple and row == row_of_already_placed_apple:
                return True

        return False

    def place_apples(self):
        apples_to_be_placed = self.apple_count
        placed_apples = []
        while apples_to_be_placed:
            row = randint(0, self.dimension-1)
            column = randint(0, self.dimension-1)
            if not self.is_adjacent(row, column, placed_apples):
                placed_apples.append([row, column])
                self._representation_of_data[row][column] = "."
                apples_to_be_placed -= 1

        return placed_apples

    def place_new_apples(self, amount_of_new_apples):
        while amount_of_new_apples:
            row = randint(0, self.dimension - 1)
            column = randint(0, self.dimension - 1)
            if not self.is_adjacent(row, column, self.placed_apples):
                self.placed_apples.append([row, column])
                self._representation_of_data[row][column] = "."
                amount_of_new_apples -= 1

    def slot_of_board(self, index_of_row, index_of_column):
        """
        Getter method for a single slot of the board.
        :param index_of_row: represents the coordinate of the row.
        :param index_of_column: represents the coordinate of the column.
        :return: the element that is to be found at the given coordinates.
        """
        return self._representation_of_data[index_of_row][index_of_column]


    def __str__(self):
        """
        The method 'converts' the internal representation of the board into a readable format that will be used for
        printing.
        It uses the module 'texttable' and creates a table with 7 columns and progressively adds the rows to the table.
        :return: the board in the form of a nice, readable table.
        """
        table = texttable.Texttable()
        for row in range(self.dimension):
            row_data = []

            for index in self._representation_of_data[row]:
                if index is None:
                    row_data.append(' ')
                else:
                    row_data.append(index)
            table.add_row(row_data)

        return table.draw()
