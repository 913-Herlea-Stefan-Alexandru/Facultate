from domain.game import Game


class UI:
    def __init__(self):
        self._game = Game()

    def run_menu(self):
        print(' ')
        print('1- move[n], where n is the number of moves you want to go')


    def start(self):
        finished = False
        print(self._game.board)
        while not finished:
            self.run_menu()
            nmb= int(input('Enter a nmb: '))
            if nmb  == 1:
                direction = input('Enter: move[n], where n is the number of moves you want to go:')
                pos = int(direction[5])
                move = self._game.move(pos)
                if move == False:
                    #we validate to see if we can make so much moves on the board, otherwie the game is over
                    finished= True
                    print('You lose')
                else:
                    self._game.move2(pos)
                    print('ok')





ui = UI()
ui.start()