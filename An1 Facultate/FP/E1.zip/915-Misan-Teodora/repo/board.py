from texttable import Texttable


class Board:
    def __init__(self):
        self._rows = 7
        self._columns = 7

        self._data = [[None for j in range(self._columns)] for i in range(self._rows)]
        self._data[7//2-1][7//2] = 0
        self._data[7//2][7//2]= 1
        self._data[7// 2+1][7 // 2] = 1

        self._data[0][1] = -1
        self._data[0][5] = -1
        self._data[1][3] = -1
        self._data[2][0] = -1
        self._data[2][2] = -1
        self._data[4][6] = -1
        self._data[5][0] = -1
        self._data[5][3] = -1
        self._data[5][5] = -1
        self._data[6][1] = -1
        self._linie= [7//2-1,7//2, 7// 2+1]
        # we save the row and the col for the head and for the tale of the snake
        self._coloane= [7//2,7//2, 7//2]


    @property
    def snake(self):
        return self._snake

    @property
    def row_count(self):
        return self._rows

    @property
    def col_count(self):
        return self._columns

    def move(self, steps):
        row_cap = self._linie[0]
        col_cap = self._coloane[0]
        row_first_tale= self._linie[1]
        col_first_tale = self._coloane[1]
        if row_cap+1 == row_first_tale and col_cap==col_first_tale and row_cap+steps>7:
            print('OK')
            return False
        elif row_cap-1==row_first_tale and col_cap==col_first_tale and (7-row_cap)+steps>7:
            return False
        elif col_cap+1== col_first_tale and row_cap==row_first_tale and col_cap+steps>7:
            return False
        elif col_cap-1 == col_first_tale and row_cap==row_first_tale and (7-col_cap)+ steps > 7:
            return False

    def move2(self, steps):
#here we will nome the snake
        reverse_steps= steps
        len_snake = len(self._linie)
        row_cap = self._linie[0]
        row_cap_last = self._linie[len_snake-1]
        col_cap_last = self._coloane[len_snake-1]
        col_cap = self._coloane[0]
        row_first_tale= self._linie[1]
        col_first_tale = self._coloane[1]
        if col_cap==col_first_tale and row_cap+1==row_first_tale:
            cont=0
            self._data[row_cap+steps][col_cap] = 0
            #we put the head on the valid position
            while steps>0:
                self._data[row_cap+cont][col_cap]=1
                steps =steps-1
                cont +=1
            cont= steps
            while reverse_steps>0:
                self._data[row_cap_last][col_cap_last] = None
                reverse_steps = reverse_steps-1
        pass











        # print(len(self._snake))
        #print(self._snake[0])
        # print(self._snake[1])
        # print(self._snake[2])

    def __str__(self):
        t = Texttable()
        t.header(['A', 'B', 'C', 'D', 'E', 'F', 'G', ' '])
        x= range(7)
        for row in x:
            row_data = []

            for index in self._data[row]:
                if index is None:
                    row_data.append(' ')
                elif index == 0 :
                    row_data.append('*')
                elif index == 1:
                    row_data.append('+')
                elif index == -1:
                    row_data.append('.')

            t.add_row(row_data + [row])

        return t.draw()

