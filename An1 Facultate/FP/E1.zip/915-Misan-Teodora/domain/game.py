from repo.board import Board


class Game:
    def __init__(self):
        self._board = Board()

    @property
    def board(self):
        return self._board

    def move(self, nmb):
        self._board.move(nmb)

    def move2(self, steps):
        self._board.move2(steps)