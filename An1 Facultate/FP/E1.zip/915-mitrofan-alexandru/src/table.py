import random
from queue import Queue


class Table:
    def __init__(self, dim, apples):
        self._dim = dim
        self._apples = apples
        self._snake = Queue()
        self._snake.put([(dim // 2) + 1, dim // 2])
        self._snake.put([(dim // 2), dim // 2])
        self._snake.put([(dim // 2) - 1, dim // 2])
        self._table = []
        self._dir = "up"
        self._head = [(dim // 2) - 1, dim // 2] # head of snake

        for i in range(dim):
            self._table.append([])
            for j in range(dim):
                if i == j and j == dim // 2:
                    self._table[i-1][j] = "*"
                    self._table[i].append("+")
                elif i == j+1 and j == dim // 2:
                    self._table[i].append("+")
                else:
                    self._table[i].append(" ")
        copy_apples = apples
        while copy_apples != 0:
            self.place_apple()
            copy_apples = copy_apples - 1

    def __str__(self):
        sep_string = "+"
        for i in range(len(self._table)):
            sep_string += "---+"
        sep_string += "\n"
        string = sep_string
        for i in range(0, len(self._table)):
            str1 = "|"
            for j in range(0, len(self._table)):
                str1 += " " + str(self._table[i][j]) + " |"
            str1 += "\n"
            string += str1
            string += sep_string
        return string

    def check_for_available_square(self, i, j):
        if self._table[i][j] != " ":
            return False
        if i > 0:
            if self._table[i-1][j] == ".":
                return False
        if j > 0:
            if self._table[i][j-1] == ".":
                return False
        if i < self._dim-1:
            if self._table[i+1][j] == ".":
                return False
        if j < self._dim-1:
            if self._table[i][j+1] == ".":
                return False
        return True

    def get_empty_available_squares(self):
        lst = []
        for i in range(0, len(self._table)):
            for j in range(0, len(self._table)):
                if self.check_for_available_square(i, j):
                    lst.append([i, j])
        return lst

    def place_apple(self):
        lst = self.get_empty_available_squares()
        move = random.choice(lst)
        self._table[move[0]][move[1]] = "."

    def move_once(self, direction):
        self._table[self._head[0]][self._head[1]] = "+"
        if direction == "up":
            if self._head[0] == 0:
                return False
            self._head[0] = self._head[0] - 1
        if direction == "down":
            if self._head[0] == self._dim-1:
                return False
            self._head[0] = self._head[0] + 1
        if direction == "left":
            if self._head[1] == 0:
                return False
            self._head[1] = self._head[1] - 1
        if direction == "right":
            if self._head[1] == self._dim-1:
                return False
            self._head[1] = self._head[1] + 1
        if self._table[self._head[0]][self._head[1]] == "+":
            return False
        if self._table[self._head[0]][self._head[1]] == ".":
            self._table[self._head[0]][self._head[1]] = "*"
            self.place_apple()
        else:
            self._table[self._head[0]][self._head[1]] = "*"
            old_tail = self._snake.get()
            self._table[old_tail[0]][old_tail[1]] = " "
        self._snake.put(self._head)
        return True

    def apply(self, move):
        if move[1] == "up" and self._dir == "down":
            return "180"
        if move[1] == "down" and self._dir == "up":
            return "180"
        if move[1] == "left" and self._dir == "right":
            return "180"
        if move[1] == "right" and self._dir == "left":
            return "180"
        if move[1] != "same":
            self._dir = move[1]
        while move[0] != 0:
            if self.move_once(self._dir) is False:
                return "end_game"
            move[0] = move[0] - 1
        return "ok"
