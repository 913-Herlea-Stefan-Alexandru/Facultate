
class UI:
    def print_table(self, table):
        print("Current game area:\n")
        print(table)

    def read_move(self):
        move = input("command: ")
        moves = move.split(" ")
        if len(moves) == 2:
            return [int(moves[1]), "same"]
        if moves[0] == "move":
            return [1, "same"]
        return [1, moves[0]]

    def end_game(self):
        print("Game Over")

    def big_turn(self):
        print("You can't turn 180 degrees!")