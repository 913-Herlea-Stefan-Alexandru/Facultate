from src.game import Game

if __name__ == "__main__":
    with open("settings.settings", "r") as f:
        dim = f.readline().split("=")
        apples = f.readline().split("=")
        game = Game(int(dim[1]), int(apples[1]))
        game.start()
