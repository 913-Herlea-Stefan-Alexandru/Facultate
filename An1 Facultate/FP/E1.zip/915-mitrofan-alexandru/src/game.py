from src.table import Table
from src.ui import UI


class Game:
    def __init__(self, dim, apples):
        self.__dim = dim
        self.__apples = apples

    def start(self):
        ui = UI()
        table = Table(self.__dim, self.__apples)
        while True:
            ui.print_table(table)
            move = ui.read_move()
            output = table.apply(move)
            if output == "end_game":
                ui.end_game()
                return
            if output == "180":
                ui.big_turn()
