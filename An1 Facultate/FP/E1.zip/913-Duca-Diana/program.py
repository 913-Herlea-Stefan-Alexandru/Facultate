from texttable import Texttable
import random

class Board:
    def __init__(self,dim, apples):
        self._rows=dim
        self._cols=dim
        self._apples=apples
        self._data = [[0 for col in range(self._cols + 2)] for row in range(self._rows + 2)]
        self._lay_snake()
        self._lay_apples()

    def current_position(self):
        ok=False
        for row in range(1, self._rows + 1):
            for col in range(1, self._cols + 1):
                if self._data[row][col]==3:
                    ok=True
                    return [row, col]
        if ok==False:
            return False


    def tail_position(self):
        mini=10
        for row in range(1, self._rows + 1):
            for col in range(1, self._cols + 1):
                if self._data[row][col]==2:
                    if self.sums_of_nearby_positions(row,col)<mini:
                        mini=self.sums_of_nearby_positions(row,col)
        for row in range(1, self._rows + 1):
            for col in range(1, self._cols + 1):
                if self._data[row][col] == 2:
                    if self.sums_of_nearby_positions(row,col)==mini:
                        return [row,col]

    def sums_of_nearby_positions(self, row, col):
        sum=0
        if self._data[row + 1][col] == 2:
            sum += 2
        elif self._data[row][col + 1] == 2:
            sum += 2
        elif self._data[row][col - 1] == 2:
            sum += 2
        elif self._data[row - 1][col] == 2:
            sum += 2
        if self._data[row + 1][col] == 3:
            sum += 3
        if self._data[row][col + 1] == 3:
            sum += 3
        if self._data[row][col - 1] == 3:
            sum += 3
        if self._data[row - 1][col] == 3:
            sum += 3
        return sum

    def _lay_snake(self):
        location=self._rows//2
        self._data[self._rows//2+1][self._cols//2+1]=2
        self._data[self._rows // 2 + 2][self._cols // 2 + 1] = 2
        self._data[location][location+1]=3
    def direction(self):
        row=self.current_position()[0]
        col=self.current_position()[1]
        if self._data[row-1][col]==2:
            return 'down'
        elif self._data[row][col-1]==2:
            return 'right'
        elif self._data[row+1][col]==2:
            return 'up'
        else:
            return 'left'
    def _lay_apple(self):
        map = []
        for row in range(1, self._rows + 1):
            for col in range(1, self._cols + 1):
                map.append((row, col))
        apples=1
        while apples > 0:
            location = random.choice(map)
            row = location[0]
            col = location[1]
            if self._data[row][col]==0 and self._data[row+1][col]!=1 and self._data[row-1][col]!=1 and \
                    self._data[row][col+1]!=1 and self._data[row][col-1]!=1:
                self._data[row][col] = 1
                apples-=1
    def _lay_apples(self):
        map = []
        for row in range(1, self._rows + 1):
            for col in range(1, self._cols + 1):
                map.append((row, col))

        apples = self._apples
        while apples > 0:
            location = random.choice(map)
            row = location[0]
            col = location[1]
            if self._data[row][col]==0 and self._data[row+1][col]!=1 and self._data[row-1][col]!=1 and \
                    self._data[row][col+1]!=1 and self._data[row][col-1]!=1:
                self._data[row][col] = 1
                apples-=1

    def __str__(self):
        t = Texttable()
        header = [' ']
        for h in range(self._cols):
            header.append(chr(65 + h))
        t.header(header)
        for row in range(1, self._rows + 1):
            data = []

            for val in self._data[row][1:-1]:
                if val == 0:
                    data.append(' ')
                elif val==1:
                    data.append('.')
                elif val==2:
                    data.append("+")
                elif val==3:
                    data.append("*")

            t.add_row([row] + data)
        return t.draw()
    def right(self):
        if self.direction()=="up":
            row=self.current_position()[0]
            col=self.current_position()[1]
            self._data[row][col]=0
            if self._data[row][col+1]==1:
                self._lay_apple()
            self._data[row+1][col+1]=3
        elif self.direction()=='down':
            row,col =self.current_position()
            self._data[row][col]=0
            if self._data[row-1][col+1]==1:
                self._lay_apple()
            self._data[row-1][col+1]=3
        elif self.direction()=='right':
            row,col=self.current_position()
            row1,col1=self.tail_position()
            if self._data[row][col+1]==1:
                self._lay_apple()
            else:
                self._data[row1][col1] = 0
            self._data[row][col+1]=3
            self._data[row][col]=2


    def down(self):
        row1, col1 = self.tail_position()
        row = self.current_position()[0]
        col = self.current_position()[1]
        self._data[row][col]=2
        if self._data[row+1][col] == 1:
            self._lay_apple()
        else:
            self._data[row1][col1] = 0
        self._data[row+1][col]=3


    def left(self):
        if self.direction()=="up":
            row = self.current_position()[0]
            col = self.current_position()[1]
            self._data[row][col] = 0
            if self._data[row+1][col-1]==1:
                self._lay_apple()
            self._data[row + 1][col - 1] = 3
        elif self.direction()=='down':
            row,col= self.current_position()
            if self._data[row-1][col-1]==1:
                self._lay_apple()
            else:
                self._data[row][col] = 0
            self._data[row-1][col-1]=3

        elif self.direction()=='left':
            row,col=self.current_position()
            row1,col1=self.tail_position()
            if self._data[row][col-1]==1:
                self._lay_apple()
            else:
                self._data[row1][col1] = 0
            self._data[row][col-1]=3
            self._data[row][col]=2



    def up(self):
        row1, col1 = self.tail_position()
        row = self.current_position()[0]
        col = self.current_position()[1]
        if self._data[row-1][col] == 1:
            self._lay_apple()
        else:
            self._data[row1][col1] = 0
        self._data[row-1][col]=3
        self._data[row][col]=2




    def move(self,n):
        if self.direction() == 'right':
            if n==1:
                self.right()
            else:
                for i in range(0,n):
                    self.right()
        elif self.direction() == 'up':
            if n==1:
                self.up()
            else:
                for i in range(0,n):
                    self.up()
        elif self.direction() == 'down':
            if n==1:
                self.down()
            else:
                for i in range(0,n):
                    self.down()
        elif self.direction() == 'left':
            if n==1:
                self.left()
            else:
                for i in range(0,n):
                    self.left()
    def end_game(self):
        row,col=self.current_position()
        if self.current_position()==False:
            print("End of Game!")
        return True
class UI():
    def __init__(self):
        dim=int(input("Dimension: "))
        apples=int(input("Apples: "))
        self._board=Board(dim,apples)
    def start(self):
        done = False
        print("Your commands: up, down, right, move[n], exit")
        while not done:
            print(str(self._board))
            cmd=input("Your command: ")
            l=len(cmd)
            dir=self._board.direction()
            if (dir=='right' and cmd=='left') or (dir=='up' and cmd=="down") or (dir=='left' and cmd=='right') or (dir=='down' and cmd=="up"):
                print("Bad command")
            elif cmd=="up":
                if self._board.direction()!='up':
                    self._board.up()
            elif cmd=="down":
                if self._board.direction()!='down':
                    self._board.down()

            elif cmd=="right":
                if self._board.direction()!='right':
                    self._board.right()

            elif cmd=="left":
                if self._board.direction()!='left':
                    self._board.left()
            elif cmd[0]=='m' and cmd[1]=='o' and cmd[2]=='v' and cmd[3]=='e':
                if l==4:
                    self._board.move(1)
                elif l>4:
                    self._board.move(int(cmd[5]))

            elif cmd=="exit":
                done=True



b=UI()
b.start()




