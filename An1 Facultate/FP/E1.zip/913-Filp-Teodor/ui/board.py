import texttable
# 1 - snake head
# 2 - snake tail
# 3 - apple
# 4 - empty space
class Board:
    def __init__(self, dimensions, gameService):
        self.board = texttable.Texttable()
        self.dimensions = dimensions
        self.game_service = gameService
        self.commands = {}
        self.setup()
        self.setup_commands()

    def setup(self):
        self.board.header([' ' for i in range(self.dimensions)])

    def reset_board(self):
        self.board.reset()
        self.setup()

    def get_formatted_board(self):
        mapper = ["*", "+", ".", " "]
        board = self.game_service.get_board()
        for i in range(len(board)):
            for j in range(len(board[i])):
                board[i][j] = mapper[board[i][j]-1]

        return board

    def setup_commands(self):
        self.commands = {
            "move": self._handle_move,
            "up": self._handle_up,
            "down": self._handle_down,
            "left": self._handle_left,
            "right": self._handle_right
        }

    def _handle_right(self):
        self.game_service.change_direction("right")

    def _handle_left(self):
        self.game_service.change_direction("left")

    def _handle_down(self):
        self.game_service.change_direction("down")

    def _handle_up(self):
        self.game_service.change_direction("up")

    def _handle_move(self, steps = 1):
        steps = int(steps)
        self.game_service.move_snake(steps)

    def draw(self):
        self.board.add_rows(self.get_formatted_board())
        print(self.board.draw())
        self.reset_board()

    def display_commands(self):
        print("1. move [n]")
        print("2. up | down | right | left")
        
    def get_formatted_command(self, command_string):
        tokens = command_string.lower().strip().split()

        return tokens[0], tokens[1:] if len(tokens) > 1 else []

    def start(self):
        done = False

        try: 
            while not done:
                self.draw()
                self.display_commands()
                command, args = self.get_formatted_command(input("Enter a command: "))
                if command not in self.commands:
                    print("Invalid command")
                elif command == "Exit":
                    done = True
                else:
                    self.commands[command](*args)
        except Exception as ex:
            print("GAME OVER: " + str(ex))
        