from config import Configuration
from ui.board import Board
from service.game_service import GameService

config = Configuration("settings.json")

service = GameService(config["dim"], config["apple_count"])
board = Board(config["dim"], service)
board.start()