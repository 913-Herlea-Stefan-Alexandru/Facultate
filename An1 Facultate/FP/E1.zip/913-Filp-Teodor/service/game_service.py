from copy import deepcopy
from domain.snake import Snake
from domain.cell import Cell
from random import randint
from domain.snake import Snake

class GameService:
    def __init__(self, dimensions, apple_count):
        self.dimensions = dimensions
        self.apple_count = apple_count
        self.data = []
        self.snake = Snake(Cell(dimensions // 2, dimensions //2, 1))
        self.apples = []
        self.setup_board()

    def setup_board(self):
        self.data = [[Cell(i, j, 4)  for i in range(self.dimensions)] for j in range(self.dimensions)]
        self.add_snake_to_board()
        self.generate_apples(self.apple_count)
        self.add_apples_to_board()

    def add_snake_to_board(self):
        snakeHead = self.snake.head
        self.data[snakeHead.i][snakeHead.j].value = snakeHead.value

        for item in self.snake.tail:
            self.data[item.i][item.j].value = item.value 

    def add_apples_to_board(self):
        for apple in self.apples:
            self.data[apple.i][apple.j].value = apple.value

    def get_empty_cells(self):
        empty_cells = []
        for row in self.data:
            for item in row:
                if item.value == 4:
                    empty_cells.append(item)

        return empty_cells

    def generate_apples(self, apples):
        empty_cells = self.get_empty_cells()
        while apples > 0 and len(empty_cells) > 0:
            candidateCell = empty_cells[randint(0, len(empty_cells) - 1)]
            newI = candidateCell.i
            newJ = candidateCell.j

            if self.data[newI][newJ].value != 4:
                empty_cells.remove(candidateCell)
                continue

            dl = [-1, 0, 1, 0]
            dc = [0, 1, 0 , -1]

            found_neighbour = False
            for row in dl:
                for col in dc:
                    if not self.is_outside_board(newI + row, newJ + col):
                        found_apple_neighbour = list(filter(lambda ap: ap.i == newI + row and ap.j == newJ + col, self.apples))
                        if found_apple_neighbour:
                            found_neighbour = True

            if not found_neighbour:
                self.apples.append(Cell(newI, newJ, 3))
                apples -= 1
            else:
                empty_cells.remove(candidateCell)

    def update_board(self, eaten_apples):
        self.data = [[Cell(i, j, 4)  for i in range(self.dimensions)] for j in range(self.dimensions)]
        self.generate_apples(eaten_apples)
        self.add_apples_to_board()
        self.add_snake_to_board()

    def remove_eaten_apples(self):
        eaten_apples = 0

        for apple in self.apples:
            eaten = False
            if apple.i == self.snake.head.i and apple.j == self.snake.head.j:
                eaten = True
            
            for item in self.snake.tail:
                if apple.i == item.i and apple.j == item.j:
                    eaten = True

            if eaten == True:
                self.apples.remove(apple)
                eaten_apples += 1

        return eaten_apples

    def has_apple_in_front(self):
        for apple in self.apples:
            if apple.i == self.snake.head.i + self.snake.direction.i and apple.j == self.snake.head.j + self.snake.direction.j:
                return True
        return False

    def check_if_snake_will_hit_wall(self):
        head = self.snake.head
        direction = self.snake.direction
        if head.i + direction.i < 0 or head.j + direction.j < 0:
            raise ValueError("Snake hit wall")
        if head.i + direction.i >= self.dimensions or head.j + direction.j >= self.dimensions:
            raise ValueError("Snake hit wall")

    def move_snake(self, steps):
        for step in range(steps):
            self.check_if_snake_will_hit_wall()
            self.snake.move(self.has_apple_in_front())
        eaten = self.remove_eaten_apples()
        self.update_board(eaten)

    def change_direction(self, direction):
        directions = {
            "left": Cell(0, -1, 0),
            "right": Cell(0, 1, 0),
            "down": Cell(1, 0, 0),
            "up": Cell(-1, 0, 0)
        }
        newDirection = directions[direction]
        if self.snake.direction.i + newDirection.i == 0 and self.snake.direction.j + newDirection.j == 0:
            raise ValueError("A snake going up cannot immediately go down")
        self.snake.direction = newDirection
        self.move_snake(1)

    def is_outside_board(self, i , j):
        return i < 0 or i >= self.dimensions or j < 0 or j >= self.dimensions

    def get_board(self):
        returnBoard = []
        for i in range(len(self.data)):
            row = []
            for j in range(len(self.data[i])):
                row.append(self.data[i][j].value)
            returnBoard.append(row)
        return returnBoard

    