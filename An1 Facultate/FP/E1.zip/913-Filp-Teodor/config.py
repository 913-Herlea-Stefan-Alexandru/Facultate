import json 

class Configuration:
    def __init__(self, path):
        self.path = path
        self.data = {}
        self.load()

    def load(self):
        with open(self.path) as file:
            self.data = json.load(file)
    
    def __getitem__(self, key):
        return self.data[key]