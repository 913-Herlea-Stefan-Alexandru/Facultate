class Cell:
    def __init__(self, i, j,  value):
        self.i = i
        self.j = j
        self.value = value

    def __add__(self, other):
        return Cell(self.i  + other.i, self.j + other.j, self.value)
