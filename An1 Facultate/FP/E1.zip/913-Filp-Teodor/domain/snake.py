from domain.cell import Cell
# -1 0 -> up
# 0 -1 -> left
# 0 1 -> right
# 1 0 -> down

class SnakeDeadError(Exception):
    def __init__(self, message):
        super().__init__(message)

class Snake:
    def __init__(self, head):
        self.head = head
        self.tail = [Cell(head.i + 1, head.j, 2), Cell(head.i + 2, head.j, 2)]
        self.direction = Cell(-1, 0, None) # -1 0
    
    def move(self, should_grow):
        oldHead = Cell(self.head.i, self.head.j, 2)

        self.head.i = self.head.i + self.direction.i
        self.head.j = self.head.j + self.direction.j

        self.tail.insert(0, oldHead)
        if not should_grow:
            self.tail.pop()

        self.check_if_eaten_tail()

    def check_if_eaten_tail(self):
        headI = self.head.i
        headJ = self.head.j
        for item in self.tail:
            if item.i == headI and item.j == headJ:
                raise SnakeDeadError("Snake has eaten its tail")
        