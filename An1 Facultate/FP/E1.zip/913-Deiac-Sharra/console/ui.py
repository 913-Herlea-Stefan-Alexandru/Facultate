from console.settings import configuration
from domain.board import Board
from domain.snake import Snake
from game.game import Game


class UI:
    def __init__(self, game):
        self._game = game

    def read_move(self):
        move = input('Select a command: ')
        if not move[0].isalpha():
            raise ValueError('Bad input!')
        row = int(move[1])
        # Calculate column index from character's ASCII code
        col = ord(move[0].lower()) - 97
        return row, col

    def start(self):
        game_over = False

        while not game_over:
            # Print the board state
            print(self._game.board)
            print(' ')


config = configuration()
list = []
config.read_setting_file(list)
board = Board(int(list[0]), int(list[1]))
snake = Snake()
game = Game(board, snake)