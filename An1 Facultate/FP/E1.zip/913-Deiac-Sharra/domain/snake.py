class Snake:
    def __init__(self):
        self._positions = []

    @property
    def positions(self):
        return self._positions

    def head(self):
        return self._positions[0]

    def snake_orientation(self, head_position):
        s_row = head_position[0]
        s_col = head_position[1]
        if [s_row+1, s_col] in self._positions:
            return 'up'
        if [s_row, s_col - 1] in self._positions:
            return 'right'
        if [s_row, s_col+1] in self._positions:
            return 'left'
        if [s_row-1, s_col] in self._positions:
            return 'down'
