class Game:
    def __init__(self, board, snake):
        self._board = board
        self._snake = snake

    @property
    def board(self):
        return self._board

    def move(self, squares):
        snake_head = self._snake.positions[0]
        orientation = self._snake.snake_orientation(snake_head)
        row = snake_head[0]
        col = snake_head[1]
        if orientation == 'up':
            while squares > 0 and row > 0:
                while self.board.get(row, col) in [0, 1]:
                    if self.board.get(row - 1, col) == self.board.get(row, col):
                        pass
