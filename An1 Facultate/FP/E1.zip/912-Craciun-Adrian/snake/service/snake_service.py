from snake.repository.snake_repo import TableRepository


class TableService:
    def __init__(self, dimension, number_of_apples):
        self.repo = TableRepository(dimension, number_of_apples)

    def verify_if_180(self, move):
        return self.repo.verify_if_180(move)

    def user_move_right(self):
        return self.repo.user_move_right()

    def user_move_left(self):
        return self.repo.user_move_left()

    def user_move_up(self):
        return self.repo.user_move_up()

    def user_move_down(self):
        return self.repo.user_move_down()

    def user_move_a_number(self, n):
        self.repo.user_move_a_number(n)
