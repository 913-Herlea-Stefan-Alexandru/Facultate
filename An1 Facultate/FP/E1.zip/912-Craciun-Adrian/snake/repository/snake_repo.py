import numpy as np
import random


class TableRepository:
    def __init__(self, dimension, number_of_apples):
        self.dimension = int(dimension)
        self.number_of_apples = int(number_of_apples)
        self.game_table = 0
        self.create_table()
        self.snake_tail_length = 0
        self.snake_tail_i = 0
        self.snake_tail_j = 0
        self.positioning = "up"

    def create_table(self):
        """
        This function i supposed to create the table of the game
        :return:
        """
        index = 0
        line = []
        list_of_lines = []
        while index <= self.dimension:
            line.append(0)
            index += 1

        index_2 = 0
        while index_2 <= self.dimension:
            list_of_lines.append(line)
            index_2 += 1
        self.game_table = np.array(list_of_lines)

        self.add_snake()
        index_3 = 1
        while index_3 <= self.number_of_apples:
            self.add_apple()
            index_3 += 1

    def add_apple(self):
        """
        This function adds an apple randomly generated in the game table
        :return:
        """
        n = self.dimension - 2
        i = random.randint(0, n)
        j = random.randint(0, n)
        while self.game_table[i][j] == 1 or self.game_table[i][j] == 9 or self.game_table[i][j] == 2 or\
                self.game_table[i + 1][j] == 9 or self.game_table[i][j + 1 ] == 9 or self.game_table[i - 1][j] == 9 or\
                self.game_table[i][j - 1] == 9:
            i = random.randint(0, n)
            j = random.randint(0, n)
        self.game_table[i][j] = 9

    def add_snake(self):
        """
        This function adds the snake's head randomly generated in the game table
        :return:
        """
        i = random.randint(0, self.dimension - 2)
        j = random.randint(0, self.dimension - 2)
        self.game_table[i][j] = 1

    def verify_if_180(self, move):
        """
        This function verifies if the user wants to move the snake 180 degrees
        :param move:
        :return:
        """
        dimension = self.dimension
        for i in range(0, dimension - 1):
            for j in range(0, dimension - 1):
                if move == "right" and self.game_table[i][j + 1] == 2 and self.game_table[i][j] == 1:
                    return False
                elif move == "left" and self.game_table[i][j - 1] == 2 and self.game_table[i][j] == 1:
                    return False
                elif move == "up" and self.game_table[i - 1][j] == 2 and self.game_table[i][j] == 1:
                    return False
                elif move == "down" and self.game_table[i + 1][j] == 2 and self.game_table[i][j] == 1:
                    return False
        return True

    def verify_if_apple(self, i, j):
        """
        This function verifies if at the params i and j we have an apple
        :param i: the line, given by the user
        :param j: the column, given by the user
        :return:
        """
        if self.game_table[i][j] == 9:
            self.snake_tail_length += 1
            self.add_apple()
            return True
        return False

    def verify_if_lost(self, i, j):
        n = self.dimension
        if self.game_table[i][j] == 2 or i == -1 or i == n - 1 or j == -1 or j == n - 1:
            return True
        return False

    def user_move_right(self):
        """
        The function for the move right
        :return:
        """
        self.positioning = "right"
        dimension = self.dimension
        for i in range(0, dimension - 1):
            for j in range(0, dimension - 1):
                if self.game_table[i][j] == 1:
                    self.game_table[i][j] = 0
                    if self.verify_if_apple(i, j + 1):
                        self.game_table[i][j] = 2
                    if self.verify_if_lost(i, j + 1):
                        raise ValueError
                    self.game_table[i][j + 1] = 1
                    return

    def user_move_left(self):
        """
        The function for the move left
        :return:
        """
        self.positioning = "left"
        dimension = self.dimension
        for i in range(0, dimension - 1):
            for j in range(0, dimension - 1):
                if self.game_table[i][j] == 1:
                    self.game_table[i][j] = 0
                    if self.verify_if_apple(i, j - 1):
                        self.game_table[i][j] = 2
                    if self.verify_if_lost(i, j - 1):
                        raise ValueError
                    self.game_table[i][j - 1] = 1
                    return

    def user_move_up(self):
        """
        The function for the move up
        :return:
        """
        self.positioning = "up"
        dimension = self.dimension
        for i in range(0, dimension - 1):
            for j in range(0, dimension - 1):
                if self.game_table[i][j] == 1:
                    self.game_table[i][j] = 0
                    if self.verify_if_apple(i - 1, j):
                        self.game_table[i][j] = 2
                    if self.verify_if_lost(i - 1, j):
                        raise ValueError
                    self.game_table[i - 1][j] = 1
                    return

    def user_move_down(self):
        """
        The function for the move down
        :return:
        """
        self.positioning = "down"
        dimension = self.dimension
        for i in range(0, dimension - 1):
            for j in range(0, dimension - 1):
                if self.game_table[i][j] == 1:
                    self.game_table[i][j] = 0
                    if self.verify_if_apple(i + 1, j):
                        self.game_table[i][j] = 2
                    if self.verify_if_lost(i + 1, j):
                        raise ValueError
                    self.game_table[i + 1][j] = 1
                    return

    def user_move_a_number(self, n):
        """
        This function moves the snake n times in the oriented position
        :return:
        """
        n = int(n)
        i = 0
        while i < n:
            if self.positioning == "down":
                self.user_move_down()
            if self.positioning == "up":
                self.user_move_up()
            if self.positioning == "right":
                self.user_move_right()
            if self.positioning == "left":
                self.user_move_left()
            i += 1
