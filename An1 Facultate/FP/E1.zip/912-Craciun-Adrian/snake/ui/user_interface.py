from configparser import ConfigParser
from snake.service.snake_service import TableService
import sys


def print_180():
    print("You moved 180 degrees! You've hit your tail!")


"""
    I wanted to use numpy for the table and forgot that I can not put characters in the matrix so I made the following 
    changes to the problem statement: 
        
    The head of the snake is noted by 1
    The tail of the snake is supposed to be noted by 2
    The apples in the matrix are noted by 9
"""


class UI:
    def __init__(self, dim, number_of_apples):
        self.service = TableService(dim, number_of_apples)

    def print_table(self):
        dimension = self.service.repo.dimension
        for i in range(0, dimension - 1):
            for j in range(0, dimension - 1):
                print(self.service.repo.game_table[i][j], end=" ")
            print()

    def start(self):
        while True:
            self.print_table()
            cmd = input("your command: ")
            try:
                if cmd == "right":
                    if not self.service.verify_if_180(cmd):
                        print_180()
                        sys.exit()
                    self.service.user_move_right()
                elif cmd == "left":
                    if not self.service.verify_if_180(cmd):
                        print_180()
                    self.service.user_move_left()
                elif cmd == "up":
                    if not self.service.verify_if_180(cmd):
                        print_180()
                    self.service.user_move_up()
                elif cmd == "down":
                    if not self.service.verify_if_180(cmd):
                        print_180()
                    self.service.user_move_down()
                else:
                    cmd = cmd.split()
                    if len(cmd) == 1:
                        self.service.user_move_a_number(1)
                    elif len(cmd) == 2:
                        number_of_moves = cmd[1]
                        self.service.user_move_a_number(number_of_moves)
            except ValueError as Ve:
                print("You lost!")
                sys.exit()


settings = ConfigParser()
settings.read("settings.properties")

DIM = settings["DEFAULT"]["DIM"]
apple_count = settings["DEFAULT"]["apple_count"]

DIM = int(DIM)
DIM += 1
apple_count = int(apple_count)

ui = UI(DIM, apple_count)
ui.start()
