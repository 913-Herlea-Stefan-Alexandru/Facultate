from texttable import Texttable

from Domain.board import Table
import random

class BoardService:
    def __init__(self,Dim,apple_count):
        self._Dim=int(Dim)
        self._bord=Table(self._Dim)
        self._apples = int(apple_count)
        self._dir=1
        self._len=3

        x = self._Dim // 2
        self._snake_x= [x-1,x,x+1]
        self._snake_y = [x , x, x ]
        self._cap_x=x-1
        self._cap_y = x
        self._coada_x = x+1
        self._coada_y = x

    def move_dir(self,nr,direction):
        self._dir=direction
        print(nr)
        nr=int(nr)
        if self._dir==1:
            while nr>0:
                if self._cap_x !=0 and   self._bord._board[self._cap_x-1][self._cap_y]==' ':

                    self._cap_x = self._snake_x[0]
                    self._cap_y = self._snake_y[0]
                    self._coada_x = self._snake_x[self._len-1]
                    self._coada_y = self._snake_y[self._len-1]

                    self._bord._board[self._cap_x-1][self._cap_y]='*'
                    self._bord._board[self._cap_x][self._cap_y]='+'
                    self._bord._board[self._coada_x][self._coada_y] = ' '

                    for i in range(self._len-1,-1,-1):
                        self._snake_x[i]= self._snake_x[i-1]
                    self._snake_x[0]=self._cap_x-1

                    for i in range(self._len-1 ,-1,-1):
                        self._snake_y[i] = self._snake_y[i - 1]
                    self._snake_y[0] = self._cap_y

                    self._cap_x = self._snake_x[0]
                    self._cap_y = self._snake_y[0]
                    self._coada_x = self._snake_x[self._len - 1]
                    self._coada_y = self._snake_y[self._len - 1]



                elif self._cap_x !=0 and   self._bord._board[self._cap_x-1][self._cap_y]=='.':
                    self._bord._board[self._cap_x - 1][self._cap_y] = '*'
                    self._bord._board[self._cap_x][self._cap_y] = '+'
                    self._bord._board[self._coada_x][self._coada_y] = '+'
                    self._len=self._len+1
                nr=nr-1

        elif self._dir == 3:
            if self._cap_x != self._Dim-1 and self._bord._board[self._cap_x + 1][self._cap_y] == ' ':

                self._cap_x = self._snake_x[0]
                self._cap_y = self._snake_y[0]
                self._coada_x = self._snake_x[self._len - 1]
                self._coada_y = self._snake_y[self._len - 1]

                self._bord._board[self._cap_x + 1][self._cap_y] = '*'
                self._bord._board[self._cap_x][self._cap_y] = '+'
                self._bord._board[self._coada_x][self._coada_y] = ' '

                for i in range(self._len - 1, -1, -1):
                    self._snake_x[i] = self._snake_x[i - 1]
                self._snake_x[0] = self._cap_x - 1

                for i in range(self._len - 1, -1, -1):
                    self._snake_y[i] = self._snake_y[i - 1]
                self._snake_y[0] = self._cap_y

                self._cap_x = self._snake_x[0]
                self._cap_y = self._snake_y[0]
                self._coada_x = self._snake_x[self._len - 1]
                self._coada_y = self._snake_y[self._len - 1]


        elif self._dir == 2:

            if self._cap_y < self._Dim - 1 and self._bord._board[self._cap_x ][self._cap_y+1] == ' ' or  self._bord._board[self._cap_x ][self._cap_y+1] == '.':

                self._cap_x = self._snake_x[0]
                self._cap_y = self._snake_y[0]
                self._coada_x = self._snake_x[self._len - 1]
                self._coada_y = self._snake_y[self._len - 1]

                self._bord._board[self._cap_x ][self._cap_y+1] = '*'
                self._bord._board[self._cap_x][self._cap_y] = '+'
                self._bord._board[self._coada_x][self._coada_y] = ' '

                for i in range(self._len - 1, -1, -1):
                    self._snake_x[i] = self._snake_x[i - 1]
                self._snake_x[0] = self._cap_x

                for i in range(self._len - 1, -1, -1):
                    self._snake_y[i] = self._snake_y[i - 1]
                self._snake_y[0] = self._cap_y +1

                self._cap_x = self._snake_x[0]
                self._cap_y = self._snake_y[0]
                self._coada_x = self._snake_x[self._len - 1]
                self._coada_y = self._snake_y[self._len - 1]

        nr = nr - 1






        table = Texttable()
        for row in self._bord._board:
            table.add_row(row)
        print(table.draw())





    def apples(self):
        for i in range(self._apples):

            while True:
                a = random.randint(0, self._Dim-1)
                b = random.randint(0, self._Dim-1)

                if a == 0 and b == 0 and self._bord._board[a][b] == ' ' and self._bord._board[a + 1][b] == ' ' and \
                        self._bord._board[a][b + 1] and self._bord._board[a + 1][b + 1] == ' ':
                    self._bord._board[a][b] = '.'
                    break

                elif a == self._Dim - 1 and b == 0 and self._bord._board[a][b] == ' ' and self._bord._board[a - 1][b] == ' ' and self._bord._board[a][b + 1] and self._bord._board[a - 1][b + 1] == ' ':
                    self._bord._board[a][b] = '.'
                    break

                elif a == self._Dim - 1 and b == self._Dim - 1 and self._bord._board[a][b] == ' ' and self._bord._board[a - 1][b] == ' ' and \
                        self._bord._board[a][b - 1] and self._bord._board[a - 1][b - 1] == ' ':
                    self._bord._board[a][b] = '.'
                    break
                elif a == 0 and b == self._Dim - 1 and self._bord._board[a][b] == ' ' and self._bord._board[a + 1][
                    b] == ' ' and \
                        self._bord._board[a][b - 1] and self._bord._board[a + 1][b - 1] == ' ':
                    self._bord._board[a][b] = '.'
                    break


                elif a== self._Dim - 1 and  self._bord._board[a][b] == ' ' and self._bord._board[a - 1][b] == ' '  and self._bord._board[a][b + 1] == ' ' and self._bord._board[a][b - 1] == ' ' and self._bord._board[a - 1][b + 1] == ' '  and self._bord._board[a - 1][b - 1] == ' ' :
                    self._bord._board[a][b] = '.'
                    break


                elif b== self._Dim - 1  and self._bord._board[a][b] == ' ' and self._bord._board[a - 1][b] == ' ' and self._bord._board[a + 1][b] == ' '  and self._bord._board[a][b - 1] == ' '  and self._bord._board[a - 1][b - 1] == ' ' and self._bord._board[a + 1][b - 1] == ' ':

                    self._bord._board[a][b] = '.'
                    break





                elif a == 0 and self._bord._board[a][b] == ' ' and self._bord._board[a + 1][b] == ' ' and self._bord._board[a][b + 1] == ' ' and self._bord._board[a][b - 1] == ' ' and self._bord._board[a + 1][b + 1] == ' ' and self._bord._board[a + 1][b - 1] == ' ':
                        self._bord._board[a][b] = '.'
                        break

                elif b == 0  and  self._bord._board[a][b] == ' ' and self._bord._board[a - 1][b] == ' ' and self._bord._board[a + 1][b] == ' ' and self._bord._board[a][b + 1] == ' '  and self._bord._board[a - 1][b + 1] == ' ' and self._bord._board[a + 1][b + 1] == ' '  :
                    self._bord._board[a][b] = '.'
                    break

                try :
                    if  self._bord._board[a][b] == ' ' and self._bord._board[a - 1][b] == ' ' and self._bord._board[a + 1][b] == ' ' and self._bord._board[a][b + 1] == ' ' and self._bord._board[a][b - 1] == ' ' and self._bord._board[a - 1][b + 1] == ' ' and self._bord._board[a + 1][b + 1] == ' ' and self._bord._board[a - 1][b - 1] == ' ' and self._bord._board[a + 1][b - 1] == ' ':

                            self._bord._board[a][b] = '.'
                            break
                except ValueError as re:
                    x=re



        table = Texttable()
        for row in self._bord._board:
            table.add_row(row)
        print(table.draw())

