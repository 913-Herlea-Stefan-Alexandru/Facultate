from texttable import Texttable
import random


class Table:

    def __init__(self, Dim):

        self.Dim = int(Dim)


        self._board= [[ ' ' for x in range(self.Dim)] for y in range(self.Dim)]

        x=self.Dim//2

        self._board[x][x]='+'
        self._board[x+1][x] = '+'
        self._board[x-1][x] = '*'

        self._board2 = self._board
        table = Texttable()

        for row in self._board:
            table.add_row(row)




        self._tablee=table
       # print(self._tablee.draw())








