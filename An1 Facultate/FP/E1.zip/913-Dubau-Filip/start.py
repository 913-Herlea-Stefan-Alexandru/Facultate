from Service.board_service import BoardService
from settings import Settings

a=Settings()
v= a.read()

print('dimension = ', v[0])
print('apple count =',v[1])
Service=BoardService(v[0],v[1])
Service.apples()

class Console():
    def __init__(self, Service):
        self._service = Service

    def print_menu(self):
        print('1:move [n]')
        print('2:up | right | down | left')


    def move_n(self):

        nr = input("Enter nr: ")
        direction = input("Enter nr(1 up , 2 right..): ")
        nr=int(nr)
        direction=int(direction)
        self._service.move_dir(nr,direction)

    def move_d(self):
        pass


    def start(self):
        cont = True
        # add, remove, update, and list both students and disciplines.
        command_dict = {'1': self.move_n, '2': self.move_d}

        while cont is True:

            command = input("Enter command: ")

            if command == '0':
                cont = False

            elif command in command_dict:

                try:
                    command_dict[command]()
                except Exception as ve:
                    print(str(ve))
            else:
                print('Invalid command!')

x=Console(Service)
x.start()



