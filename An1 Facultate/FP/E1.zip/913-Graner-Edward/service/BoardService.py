class BoardService:
    def __init__(self):
        self._board = []

    @property
    def bd(self):
        return self._board

    def init_board(self, dim):
        '''
        Initialise the board with '-'
        '''
        for i in range(0, dim, 1):
            row = []
            for j in range(0, dim, 1):
                row.append('-')
            self._board.append(row)

    def init_snake(self, dim):
        self._board[dim // 2][dim // 2] = '+'
        self._board[dim // 2 + 1][dim // 2] = '+'
        self._board[dim // 2 - 1][dim // 2] = '*'

    def av_space(self, dim):
        av_moves = []
        for i in range(0, dim, 1):
            for j in range(0, dim, 1):
                if self._board[i][j] == '-':
                    av_moves.append([i, j])
        return av_moves

    def gen_apples(self, dim):
        from random import randint
        av_moves = self.av_space(dim)
        move = randint(0, len(av_moves) - 1)
        return av_moves[move]

    def update_cell(self, dim):
        cell = self.gen_apples(dim)
        self._board[cell[0]][cell[1]] = '.'
        self.update_neighbours(cell[0], cell[1], dim)

    def update_neighbours(self, rw, col, dim):
        if rw - 1 >= 0 and self._board[rw-1][col] == '-':
            self._board[rw - 1][col] = 'X'
        if rw + 1 < dim and self._board[rw+1][col] == '-':
            self._board[rw + 1][col] = 'X'
        if col - 1 >= 0 and self._board[rw][col-1] == '-':
            self._board[rw][col - 1] = 'X'
        if col + 1 < dim and self._board[rw][col+1] == '-':
            self._board[rw][col + 1] = 'X'

    def update_back(self, dim):
        for i in range(0, dim, 1):
            for j in range(0, dim, 1):
                if self._board[i][j] == 'X':
                    self._board[i][j] = '-'


    def init_lst(self, dim):
        lst = [[dim // 2, dim // 2], [dim // 2 - 1, dim // 2], [dim // 2 + 1, dim // 2]]
        return lst

    def update_snake(self, lst, move, dim):
        head = lst[-1]
        if move == 'up':
            if 0 <= head[0] - 1:
                lst.append([head[0]-1, head[1]])
                self._board[head[0]-1][head[1]] = '*'
                for i in range(0, len(lst)-1, 1):
                    self._board[lst[i][0]][lst[i][1]] = '+'
                if self._board[lst[-1][0]][lst[-1][1]] == '.':
                    self._board[lst[0][0]][lst[0][1]] = '-'
                    lst.remove(lst[0])
            else:
                return 0
        elif move == 'down':
            if head[0]+1 < dim:
                lst.append([head[0]+1, head[1]])
                self._board[head[0] + 1][head[1]] = '*'
                for i in range(0, len(lst)-1, 1):
                    self._board[lst[i][0]][lst[i][1]] = '+'
                if self._board[lst[-1][0]][lst[-1][1]] == '.':
                    self._board[lst[0][0]][lst[0][1]] = '-'
                    lst.remove(lst[0])
            else:
                return 0
        elif move == 'right':
            if head[1]+1 < dim:
                lst.append([head[0], head[1]+1])
                self._board[head[0]][head[1] + 1] = '*'
                for i in range(0, len(lst)-1, 1):
                    self._board[lst[i][0]][lst[i][1]] = '+'
                if self._board[lst[-1][0]][lst[-1][1]] == '.':
                    self._board[lst[0][0]][lst[0][1]] = '-'
                    lst.remove(lst[0])
            else:
                return 0
        elif move == 'left':
            if head[1]-1 >= 0:
                lst.append([head[0], head[1] - 1])
                self._board[head[0]][head[1]-1] = '*'
                for i in range(0, len(lst) - 1, 1):
                    self._board[lst[i][0]][lst[i][1]] = '+'
                if self._board[lst[-1][0]][lst[-1][1]] == '.':
                    self._board[lst[0][0]][lst[0][1]] = '-'
                    lst.remove(lst[0])
            else:
                return 0
