from service.BoardService import BoardService


class UI:
    def __init__(self):
        self._board = BoardService()

    def print_menu(self):
        print('1. Start the game')
        print('2. Reset the game')
        print('3. Exit game')

    def reset_game_ui(self, dim, nr):
        self._board.init_board(dim)
        self._board.init_snake(dim)
        av_space = self._board.av_space(dim)
        while nr > 0 and len(av_space) > 0:
            self._board.update_cell(dim)
            nr = nr - 1
            av_space = self._board.av_space(dim)
        self._board.update_back(dim)

    def print_board(self, dim):
        for i in range(0, dim, 1):
            for j in range(0, dim, 1):
                print(self._board.bd[i][j] + ' ', end='')
            print('\n')

    def read_file(self):
        result = []
        try:
            f = open("settings", "r")
            line = f.readline().strip()
            while len(line) > 0:
                result.append(int(line))
                line = f.readline().strip()
            f.close()
        except IOError as e:
            print("An error occured - " + str(e))
            raise e
        return result

    def next_move(self, move, dim, dir, lst):
        self._board.update_snake(lst, move, dim)
        if self._board.update_snake(lst, move, dim) == 0:
            print('Game over!')

    def change_dir(self, dir):
        pass

    def start_game(self):
        pass

    def start(self):
        done = False
        res = self.read_file()
        dim = res[0]
        nr = res[1]
        dir = 'up'
        lst = self._board.init_lst(dim)
        self.reset_game_ui(dim, nr)
        while not done:
            self.print_menu()
            command = input('Command: ')
            if command == '0':
                done = True
            elif command == '1':
                self.print_board(dim)
                command = input('Next move: ')
                self.next_move(command, dim, dir, lst)
            elif command == '2':
                self.start_game()


ui = UI()
ui.start()
