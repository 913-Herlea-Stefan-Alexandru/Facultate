from UI.ui import ui

console = ui()
console.pre_game()
console.play()
