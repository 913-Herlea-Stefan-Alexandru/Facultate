class Snake:
    def __init__(self, board_dim):
        self.__board_dim = board_dim
        self.__direction = 0 # 0 - up  1 - right 2 - down  3 - left
        self.__orientations = {0: [-1, 0], 1: [0, 1], 2: [1, 0], 3: [0, -1]}
        self.__snake_length = 2
        self.__snake_coord = [[board_dim // 2 - 1, board_dim // 2], [board_dim // 2, board_dim // 2], [board_dim // 2 + 1, board_dim // 2] ]
        self.__snake_directions = [[-1, 0] for i in range(0, 3)]
        self.__dead = False

#place the snake in the middle of the table

    def move(self, n):

        for i in range(0, n):
            for i in range(0, self.__snake_length + 1):
                self.__snake_coord[i][0] += self.__snake_directions[i][0]
                self.__snake_coord[i][1] += self.__snake_directions[i][1]
            for i in reversed(range(1, self.__snake_length + 1)):
                self.__snake_directions[i] = self.__snake_directions[i - 1]


        for i in range(1, self.__snake_length + 1):
            if self.__snake_coord[0][0] == self.__snake_coord[i][0] and self.__snake_coord[0][1] == self.__snake_coord[i][1]:
                self.__dead = True
                raise ValueError("You hit your snake! Game Over!")

    def get_coordinates(self):
        return self.__snake_coord

    def get_length(self):
        return self.__snake_length

    def set_length(self, length):
        self.__snake_length = length
        new_coord = self.__snake_coord[-1].copy()
        if self.is_in_board( new_coord[0] - self.__snake_directions[-1][0], new_coord[1] - self.__snake_directions[-1][1]): # check if i have room for one a piece in the tail
            new_coord[0] -= self.__snake_directions[-1][0]
            new_coord[1] -= self.__snake_directions[-1][1]
            self.__snake_directions.append(self.__snake_directions[-1])
        else:
            raise ValueError("You hit the wall! Game Over")
        """
        else:
            if self.is_in_board(new_coord[0] - self.__snake_directions[0][0], new_coord[1] - self.__snake_directions[0][1]):
                new_coord[0] -= self.__snake_directions[0][0]
                new_coord[1] -= self.__snake_directions[0][1]
            else:
                for dir in self.__orientations.values():
                    if (dir[0] != self.__snake_directions[-1][0] or dir[0] != self.__snake_directions[-1][1]) and self.is_in_board(new_coord[0] - dir[0], new_coord[1] - dir[1]):
                        new_coord[0] -= dir[0]
                        new_coord[1] -= dir[1]
                        break
        """


        self.__snake_coord.append(new_coord)

    def change_orientation(self, orientation):
        if (self.__direction == 0 and orientation == 2) or (self.__direction == 0 and orientation == 2):
            raise ValueError("You cannot do 180")
        self.__direction = orientation
        self.__snake_directions[0] = self.__orientations[orientation]

    def get_orientation(self):
        return self.__direction

    def is_dead(self):
        return self.__dead

    def is_in_board(self, x, y):
        if x>= 0 and x< self.__board_dim and y >= 0 and y < self.__board_dim:
            return True
        return False
