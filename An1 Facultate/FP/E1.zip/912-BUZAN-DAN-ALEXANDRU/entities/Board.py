from random import randrange


class Board:
    def __init__(self, dim):

        self.__dim = dim
        self.__board = [[' ' for i in range(0, dim)] for j in range(0, dim)]
        self.__hit_the_wall = False

    def get_board(self):
        return self.__board

    def put_snake(self, snake_coord):
        """

        :param snake_coord:
        :return: 1 if snake eats an apple
        """
        self.__erase_snake()
        apple = 0
        if not self.is_in_board(snake_coord[0][0], snake_coord[0][1]):
            self.__hit_the_wall = True
            raise ValueError("You hit the wall! Game Over")
        if self.__board[snake_coord[0][0]][snake_coord[0][1]] == '.':
            apple = 1
        self.__board[snake_coord[0][0]][snake_coord[0][1]] = '*'
        for coord in snake_coord[1:]:
            self.__board[coord[0]][coord[1]] = '+'
        return apple

    def put_apples(self, number):
        for i in range(0, number):
            x = randrange(0, self.__dim)
            y = randrange(0, self.__dim)
            while not self.is_valid_apple(x, y):
                x = randrange(0, self.__dim)
                y = randrange(0, self.__dim)
            self.__board[x][y] = '.'


    def get_board_dim(self):
        return self.__dim

    def is_in_board(self, x, y):
        if x>= 0 and x< self.__dim and y >= 0 and y < self.__dim:
            return True
        return False

    def is_valid_apple(self, x, y):
        if x - 1 > 0:
            if self.__board[x - 1][y] == '.':
                return False

        if x + 1 < self.__dim:
            if self.__board[x + 1][y] == '.':
                return False

        if y - 1 > 0:
            if self.__board[x][y - 1] == '.':
                return False

        if y + 1 < self.__dim:
            if self.__board[x][y + 1] == '.':
                return False
        if self.__board[x][y] != ' ':
            return False
        return True

    def __erase_snake(self):
        for i in range(0, self.__dim):
            for j in range(0, self.__dim):
                if self.__board[i][j] == '+' or self.__board[i][j] == '*':
                    self.__board[i][j] = ' '

    def if_the_wall_hit(self):
        return self.__hit_the_wall

