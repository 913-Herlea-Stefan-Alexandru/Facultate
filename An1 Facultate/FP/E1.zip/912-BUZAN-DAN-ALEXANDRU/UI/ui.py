from Game.Game import Game


class ui:
    def __init__(self):

        self.__game = Game()
        self.__directions = {'up': 0, 'right': 1, 'down': 2, 'left': 3}

    def pre_game(self):
        self.print_board()

    def play(self):

        done = False
        while not done:
            try:
                command = input(">>")
                cmd = command.split(' ')
                for c in cmd:
                    c.strip()
                if cmd[0] == 'move':
                    if len(cmd) == 1:
                        self.__game.move(1)
                    else:
                        self.__game.move(int(cmd[1]))
                    self.print_board()
                elif cmd[0] in self.__directions.keys():
                    self.__game.change_orientation(self.__directions[cmd[0]])
                    self.print_board()
                else:
                    print("Wrong command")
                if self.__game.game_over():
                    done = True
            except ValueError as ve:
                print(str(ve))


    def print_board(self):
            board = self.__game.get_board()
            board_dim = self.__game.get_board_dim()
            for k in range(0, board_dim):
                for i in range(0, board_dim):
                    print("+---", end='')
                print("+")
                for i in range(0, board_dim):
                    print("| " + str(board[k][i]) + " ", end='')
                print("|")
            for i in range(0, board_dim):
                print("+---", end='')
            print("+")

