import configparser

from entities.Board import Board
from entities.Snake import Snake


class Game:
    def __init__(self):
        parser = configparser.ConfigParser()
        parser.read("settings.properties")

        self.__board = Board(int(parser['input']['dim']))
        self.__snake = Snake(int(parser['input']['dim']))
        self.__apple_count = int(parser['input']['apple_count'])
        self.__board.put_snake(self.__snake.get_coordinates())
        self.__board.put_apples(self.__apple_count)

    def get_board(self):
        return self.__board.get_board()

    def get_board_dim(self):
        return self.__board.get_board_dim()

    def move(self, n):
        self.__snake.move(n)
        snake_coord = self.__snake.get_coordinates()
        apple = self.__board.put_snake(snake_coord) # returns 1 if snake eats an apple
        if apple == 1:
            self.__snake.set_length(self.__snake.get_length() + 1)
            snake_coord = self.__snake.get_coordinates()  # took the new snake with an extra point in tail
            self.__board.put_snake(snake_coord)

            self.__board.put_apples(1)


    def change_orientation(self, orientation):
        if orientation != self.__snake.get_orientation():
            self.__snake.change_orientation(orientation) # if the orientation is the same, the snake shouldn't move
            self.move(1)

    def game_over(self):
        return self.__board.if_the_wall_hit() or self.__snake.is_dead()




