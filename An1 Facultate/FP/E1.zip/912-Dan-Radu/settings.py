class Settings:

    def __init__(self):
        self.__infile = open("setting.properties", "r")

    def read_file(self):
        line = self.__infile.readline()
        index = line.find('=') + 1
        dimension = int(line[index:].strip())
        line = self.__infile.readline()
        index = line.find('=') + 1
        apple_count = int(line[index:].strip())
        if dimension < 3:
            raise DimensionError("Invalid dimension in setting.properties file!")
        return dimension, apple_count


class DimensionError(Exception):
    def __init__(self, msg):
        self.__msg = msg
