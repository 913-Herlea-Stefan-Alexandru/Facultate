class UI:
    def __init__(self, game):
        self._game = game

    def move_ui(self, tokens):
        if tokens == '':
            return self._game.move(1)
        else:
            return self._game.move(tokens)

    def left_ui(self):
        if self._game.snake.direction == 'right':
            raise ValueError('op direction!')
        self._game.snake.direction = 'left'
        return self._game.move(1)

    def right_ui(self):
        if self._game.snake.direction == 'left':
            raise ValueError('op direction!')
        self._game.snake.direction = 'right'
        return self._game.move(1)

    def up_ui(self):
        if self._game.snake.direction == 'down':
            raise ValueError('op direction!')
        self._game.snake.direction = 'up'
        return self._game.move(1)

    def down_ui(self):
        if self._game.snake.direction == 'up':
            raise ValueError('op direction!')
        self._game.snake.direction = 'down'
        return self._game.move(1)

    def start_game(self):
        game_over = False
        game_status = True
        while not game_over:
            print(self._game.game)
            user_input = input('Enter command> ')
            try:
                cmd_word, cmd_params = self.split_input(user_input)
                tokens = cmd_params
                if tokens != '':
                    tokens = int(tokens)
                if cmd_word == 'move':
                    game_status = self.move_ui(tokens)
                elif cmd_word == 'left' and cmd_params == '':
                    game_status = self.left_ui()
                elif cmd_word == 'right' and cmd_params == '':
                    game_status = self.right_ui()
                elif cmd_word == 'up' and cmd_params == '':
                    game_status = self.up_ui()
                elif cmd_word == 'down' and cmd_params == '':
                    game_status = self.down_ui()
                else:
                    print('Invalid command!')
                if not game_status:
                    game_over = True
            except ValueError as ve:
                print(str(ve))

    @staticmethod
    def split_input(user_input):
        user_input = user_input.strip()
        tokens = user_input.split(' ', 1)
        cmd_word = tokens[0].strip().lower()
        if len(tokens) == 2:
            cmd_params = tokens[1].strip()
        else:
            cmd_params = ''

        return cmd_word, cmd_params
