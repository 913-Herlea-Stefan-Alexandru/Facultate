class Game:
    def __init__(self, board, snake):
        self._game = board
        self._snake = snake

    @property
    def game(self):
        return self._game

    @property
    def snake(self):
        return self._snake

    def move_up(self, n):
        grow = 0
        x, y = self._snake.head
        for i in range(n):
            if self._game.data[x - (i + 1)][y] == '.':
                grow = 1
            self._snake.move(grow)
            grow = 0
        return True

    def move_down(self, n):
        grow = 0
        x, y = self._snake.head
        for i in range(n):
            if self._game.data[x + (i + 1)][y] == '.':
                grow = 1
            self._snake.move(grow)
            grow = 0
        return True

    def move_left(self, n):
        grow = 0
        x, y = self._snake.head
        for i in range(n):
            if self._game.data[x][y - (i + 1)] == '.':
                grow = 1
            self._snake.move(grow)
            grow = 0
        return True

    def move_right(self, n):
        grow = 0
        x, y = self._snake.head
        for i in range(n):
            if self._game.data[x][y + (i + 1)] == '.':
                grow = 1
            self._snake.move(grow)
            grow = 0
        return True

    def move(self, n):
        if self._snake.direction == 'up':
            self.move_up(n)
        elif self._snake.direction == 'down':
            self.move_down(n)
        elif self._snake.direction == 'left':
            self.move_left(n)
        elif self._snake.direction == 'right':
            self.move_right(n)
        # self.set_snake()
        return True

    def set_snake(self):
        self._game.data[self._snake.head[0]][self._snake.head[1]] = '*'
        for i in range(len(self._snake.tail)):
            self._game.data[self._snake.tail[i][0]][self._snake.tail[i][1]] = '+'
