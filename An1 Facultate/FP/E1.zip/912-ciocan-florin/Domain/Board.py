from texttable import Texttable
import random


class Board:
    def __init__(self, dim, apple_count, snake):
        self._dim = dim
        self._apple_count = apple_count
        self._mid = dim // 2
        self._snake = snake

        self.data = [[' ' for j in range(self._dim)] for i in range(self._dim)]

        # Set Snake position
        self.set_snake()

        # Set apples
        self.random_apple_count()

    @property
    def dim(self):
        return self._dim

    @property
    def apple_count(self):
        return self._apple_count

    def data(self):
        return self.data

    def getitem(self, x, y):
        return self.data[x][y]

    def __str__(self):
        t = Texttable()
        for row in range(self._dim):
            row_data = []

            for index in self.data[row]:
                if index == ' ':
                    row_data.append(' ')
                else:
                    row_data.append(index)

            t.add_row(row_data)

        return t.draw()

    def valid_coord(self, x, y):
        if self.data[x][y] != ' ':
            return False

        if x > 0:
            if self.data[x-1][y] == '.':
                return False
        if x < self._dim - 1:
            if self.data[x+1][y] == '.':
                return False
        if y > 0:
            if self.data[x][y-1] == '.':
                return False
        if y < self._dim - 1:
            if self.data[x][y+1] == '.':
                return False

        return True

    def random_apple_count(self):
        k = 0
        while k < self._apple_count:
            x = random.randint(0, self._dim - 1)
            y = random.randint(0, self._dim - 1)
            if self.valid_coord(x, y):
                self.data[x][y] = '.'
                k = k + 1

    def set_snake(self):
        self.data[self._snake.head[0]][self._snake.head[1]] = '*'
        for i in range(len(self._snake.tail)):
            self.data[self._snake.tail[i][0]][self._snake.tail[i][1]] = '+'
