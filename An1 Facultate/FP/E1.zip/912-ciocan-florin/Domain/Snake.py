class Snake:
    def __init__(self, dim):
        self._head = (dim // 2 - 1, dim // 2)
        self._tail = [(dim // 2, dim // 2), (dim//2 + 1, dim // 2)]
        self._direction = 'up'

    @property
    def head(self):
        return self._head

    @property
    def tail(self):
        return self._tail

    @property
    def direction(self):
        return self._direction

    @direction.setter
    def direction(self, value):
        self._direction = value

    def move(self, grow):
        if self._direction == 'up':
            x, y = self._head
            self._tail[: 0] = (x, y)
            x = x - 1
            self._head = (x, y)
            if grow == 0:
                self._tail.pop()
        elif self._direction == 'down':
            x, y = self._head
            self._tail[: 0] = (x, y)
            x = x + 1
            self._head = (x, y)
            if grow == 0:
                self._tail.pop()
        elif self._direction == 'left':
            x, y = self._head
            self._tail[: 0] = (x, y)
            y = y - 1
            self._head = (x, y)
            if grow == 0:
                self._tail.pop()
        elif self._direction == 'right':
            x, y = self._head
            self._tail[: 0] = (x, y)
            y = y + 1
            self._head = (x, y)
            if grow == 0:
                self._tail.pop()
