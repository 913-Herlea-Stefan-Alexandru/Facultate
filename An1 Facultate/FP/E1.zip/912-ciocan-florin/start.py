from Domain.Board import Board
from Domain.Snake import Snake
from Game.game import Game
from settings.settings import SettingsConfig
from ui.ui import UI

settings = SettingsConfig()

snake = Snake(settings.dim)

board = Board(settings.dim, settings.apple, snake)

game = Game(board, snake)

ui = UI(game)

ui.start_game()
