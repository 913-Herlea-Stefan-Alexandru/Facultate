from jproperties import Properties


class SettingsConfig:
    def __init__(self):
        self._configs = Properties()
        self._file_name = 'settings/settings.properties'

        settings_file = open(self._file_name, 'rb')
        self._configs.load(settings_file)

        try:
            self._dim = int(self._configs.get("DIM").data)
            self._apple_count = int(self._configs.get("apple_count").data)
            if self._dim % 2 == 0:
                print("Only odd dimensions!")
                raise ValueError
            if self._apple_count > (self._dim * self._dim - 3):
                print("Board can't handle so much apples!")
                raise ValueError
        except (KeyError, ValueError):
            print("Invalid settings!")

    @property
    def dim(self):
        return self._dim
    @property
    def apple(self):
        return self._apple_count