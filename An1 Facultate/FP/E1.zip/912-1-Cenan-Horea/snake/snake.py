"""
The snake class
"""


class Snake:
    def __init__(self, setting):
        self._queue = [(setting.DIM // 2 + 1, setting.DIM // 2, 0), (setting.DIM // 2, setting.DIM // 2, 0),
                       (setting.DIM // 2 - 1, setting.DIM // 2, 0)]
        self._direction = 0
        self._dx = [-1, 0, 1, 0]
        self._dy = [0, 1, 0, -1]

    def reverse_direction(self, direction):
        if direction == 0:
            return 2
        if direction == 2:
            return 0
        if direction == 1:
            return 3
        if direction == 3:
            return 1

    def reverse_str(self, direction):
        if direction == 'up':
            return 'down'
        if direction == 'down':
            return 'up'
        if direction == 'right':
            return 'left'
        if direction == 'left':
            return 'right'

    def change_direction(self, new_dir):
        if new_dir == 'up':
            self._direction = 0
        if new_dir == 'right':
            self._direction = 1

        if new_dir == 'down':
            self._direction = 2

        if new_dir == 'left':
            self._direction = 3

    def get_direction(self):
        direction = ''
        if self._direction == 0:
            direction = 'up'
        if self._direction == 1:
            direction = 'right'
        if self._direction == 2:
            direction = 'down'
        if self._direction == 3:
            direction = 'left'
        return direction

    def move(self):
        """
        Moves the snake 1 square
        """
        head = self._queue[-1]
        new_head = (head[0] + self._dx[self._direction], head[1] + self._dy[self._direction], self._direction)
        self._queue.append(new_head)
        self._queue.pop(0)

    def grow(self):
        """
        Increases size of snake by 1
        """
        tail = self._queue[0]
        dir = self.reverse_direction(tail[2])
        new_tail = (tail[0] + self._dx[dir], tail[1] + self._dy[dir], tail[2])
        self._queue.insert(0, new_tail)

    @property
    def queue(self):
        return self._queue
