"""
The Board class
"""

import random

from texttable import Texttable


class Board:
    def __init__(self, snake, settings):
        self._snake = snake
        self._DIM = settings.DIM
        if self._DIM < 3:
            raise OSError('Board dimension too low')
        self._apple_count = settings.apple_count
        self._board = [[0 for x in range(self._DIM)] for y in range(self._DIM)]
        self.update_board()
        self._dx = [-1, 0, 1, 0]
        self._dy = [0, 1, 0, -1]
        for i in range(self._apple_count):
            self.place_apple()

    def update_board(self):
        for x in range(self._DIM):
            for y in range(self._DIM):
                if self._board[x][y] == 1 or self._board[x][y] == 2:
                    self._board[x][y] = 0
        for tile in self._snake.queue:
            self._board[tile[0]][tile[1]] = 1
        head = self._snake.queue[-1]
        self._board[head[0]][head[1]] = 2

    def is_free(self, x, y):
        """
        Checks if a position is free
        """
        if self._board[x][y] == 1 or self._board[x][y] == 2 or self._board[x][y] == -1:
            return False

        for i in range(4):
            new_x = x + self._dx[i]
            new_y = y + self._dy[i]
            if new_y >= 0 and new_x < self._DIM and new_y > 0 and new_y < self._DIM:
                if self._board[new_x][new_y] == -1:
                    return False
        return True

    def place_apple(self):
        placed = False
        count = 0
        while placed is False:
            x = random.randint(0, self._DIM - 1)
            y = random.randint(0, self._DIM - 1)
            count += 1
            if self.is_free(x, y):
                self._board[x][y] = -1
                placed = True
            if count > 1000:
                return

    def check_finish(self, position):
        x = position[0]
        y = position[1]
        if x == -1 or x == self._DIM or y == -1 or y == self._DIM:
            return True
        if self._board[x][y] == 1:
            return True
        return False

    def change_direction(self, dir):
        if self._snake.get_direction() == dir:
            raise TypeError('Direction is the same as the snake direction')
        reverse_dir = self._snake.reverse_str(self._snake.get_direction())
        if dir == reverse_dir:
            raise TypeError('Cant do 180 degrees')
        self._snake.change_direction(dir)

    def move(self):
        tail = self._snake.queue[0]
        self._board[tail[0]][tail[1]] = 0

        self._snake.move()
        head = self._snake.queue[-1]
        if self.check_finish(head):
            raise OSError('Game over!')
        if self._board[head[0]][head[1]] == -1:
            self._snake.grow()
            self.update_board()
            self.place_apple()
        self.update_board()

    def table(self):
        table = Texttable()
        new_board = [['  ' for x in range(self._DIM)] for y in range(self._DIM)]
        for i in range(self._DIM):
            for j in range(self._DIM):
                if self._board[i][j] == 0:
                    new_board[i][j] = ' '
                if self._board[i][j] == 1:
                    new_board[i][j] = '+'
                if self._board[i][j] == 2:
                    new_board[i][j] = '*'
                if self._board[i][j] == -1:
                    new_board[i][j] = '.'

        for i in range(self._DIM):
            table.add_row([*new_board[i]])
        return table
