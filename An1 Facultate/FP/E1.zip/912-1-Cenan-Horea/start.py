from Settings.Settings import Settings
from board.board import Board
from snake.snake import Snake
from ui.ui import UI

if __name__ == '__main__':
    setting = Settings()
    snake = Snake(setting)
    board = Board(snake, setting)
    ui = UI(board)

    while True:
        try:
            ui.draw()
            command = ui.get_command()
            command_word, command_params = ui.split_command(command)
            if command_word == 'move':
                ui.move_snake(command)
            elif command_word in ['up', 'right', 'down', 'left'] and command_params == '':
                ui.change_direction(command_word)
                ui.move_snake(command)
            else:
                print('Invalid command!')
        except OSError as ve:
            print(str(ve))
            break
        except Exception as e:
            print(str(e))
