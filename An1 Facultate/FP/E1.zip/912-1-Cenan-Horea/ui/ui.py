"""
The ui class
"""


class UI:
    def __init__(self, board):
        self._board = board

    def draw(self):
        print(self._board.table().draw())

    def get_command(self):
        command = input('Enter command: ')
        return command

    def _move(self):
        self._board.move()

    def split_command(self, command):
        """
        Split command string into command word and parameters
        :return: (command_word, command_params)
        """
        command = command.strip()
        tokens = command.split(' ', 1)
        command_word = tokens[0].strip().lower()
        command_params = tokens[1].strip().lower() if len(tokens) == 2 else ''
        return command_word, command_params

    def move_snake(self, command):
        command_word, command_params = self.split_command(command)
        if command_params == '':
            self._move()
        else:
            steps = int(command_params)
            for i in range(steps):
                self._move()

    def change_direction(self, command_param):
        self._board.change_direction(command_param)
