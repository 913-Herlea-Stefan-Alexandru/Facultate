from Settings.properties import apple_count, DIM


class Settings:
    def __init__(self):
        self.apple_count = apple_count
        self.DIM = DIM
