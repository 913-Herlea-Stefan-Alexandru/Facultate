DIM = 7
apple_count = 10
