import random

from texttable import Texttable

class Board:
    def __init__(self, dim, apples):
        self._rows = dim
        self._cols = dim
        self._apples = apples
        self._board = self.create_board()
        self._head = []
        self._body = []

    @property
    def rows(self):
        return self._rows

    @property
    def cols(self):
        return self._cols

    def create_board(self):
        board = []
        for i in range(self._rows):
            board_rows = []
            for j in range(self._cols):
                board_rows.append(' ')
            board.append(board_rows)
        return board

    def place_apples(self):
        i = 0
        used_cells = []
        while i < self._apples:
            ok = 1
            row = random.randint(0, self._rows-1)
            col = random.randint(0, self._cols-1)
            if ([row,col] in used_cells) or (col == self._cols//2 and row == self._rows//2) or (col == self._cols//2 and row == self._rows//2 - 1) or (col == self._cols//2 and row == self._rows//2 + 1):
                ok = 0
            else:
                used_cells.append([row,col])
                used_cells.append([row+1, col])
                used_cells.append([row-1, col])
                used_cells.append([row, col+1])
                used_cells.append([row, col-1])

            if ok == 1:
                self._board[row][col] = '.'
                i = i + 1

    def place_new_apple(self):
        ok = 0
        while ok == 0:
            ok = 1
            row = random.randint(0, self._rows - 1)
            col = random.randint(0, self._cols - 1)
            for i in range(self._rows):
                if self._board[i][col] == '.':
                    ok = 0
            for i in range(self._cols):
                if self._board[row][i] == '.':
                    ok = 0
            if self._board[row][col]!= ' ':
                ok = 0
            if ok == 1:
                self._board[row][col] = '.'

    def place_snake(self):
        row = self._rows // 2
        col = self._cols // 2

        self._board[row-1][col] = '*'
        self._board[row][col] = '+'
        self._board[row+1][col] = '+'
        self._head.append([row-1, col])
        self._body.append([row+1, col])
        self._body.append([row, col])

    def valid(self, direction):
        row = self._head[0][0]
        col = self._head[0][1]
        if direction == 'up' and row == 0:
            return False
        elif direction == 'down' and row == self._rows-1:
            return False
        elif direction == 'left' and col == 0:
            return False
        elif direction == 'right' and col == self._cols-1:
            return False
        return True

    def move(self, direction):
        row = self._head[0][0]
        col = self._head[0][1]
        if direction == 'up':
            self._board[row-1][col] = '*'
            self._board[row][col] = '+'
            row_delete = self._body[0][0]
            col_delete = self._body[0][1]
            self._board[row_delete][col_delete] = ' '
            self._body.pop(0)
            self._body.append(self._head[0])
            self._head.pop(0)
            self._head.append([row-1, col])

        if direction == 'left':
            self._board[row][col-1] = '*'
            self._board[row][col] = '+'
            row_delete = self._body[0][0]
            col_delete = self._body[0][1]
            self._board[row_delete][col_delete] = ' '
            self._body.pop(0)
            self._body.append(self._head[0])
            self._head.pop(0)
            self._head.append([row, col-1])

        if direction == 'right':
            self._board[row][col+1] = '*'
            self._board[row][col] = '+'
            row_delete = self._body[0][0]
            col_delete = self._body[0][1]
            self._board[row_delete][col_delete] = ' '
            self._body.pop(0)
            self._body.append(self._head[0])
            self._head.pop(0)
            self._head.append([row, col+1])

        if direction == 'down':
            self._board[row+1][col] = '*'
            self._board[row][col] = '+'
            row_delete = self._body[0][0]
            col_delete = self._body[0][1]
            self._board[row_delete][col_delete] = ' '
            self._body.pop(0)
            self._body.append(self._head[0])
            self._head.pop(0)
            self._head.append([row + 1, col])

    def __str__(self):
        t = Texttable()
        board = []
        for row in range(self._rows):
            board.append(self._board[row])
            for col in range(self._cols):
                board[row][col] = self._board[row][col]
        for row in board:
            t.add_row(row)
        return t.draw()

