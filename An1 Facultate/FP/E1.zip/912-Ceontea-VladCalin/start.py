from Board.board import Board
from UI.ui import console


def start():
    file = open('settings.properties', 'rt')
    lines = file.readlines()
    file.close()
    dim = 0
    apples = 0
    for line in lines:
        line = line.split(' ')
        if line[0] == 'DIM':
            dim = line[2]
        if line[0] == 'apples':
            apples = line[2]

    dim = dim.split('\'')
    apples = apples.split('\'')
    DIM = dim[1]
    apple_count = apples[1]
    DIM = int(DIM)
    apple_count = int(apple_count)

    board = Board(DIM, apple_count)
    ui = console(board)
    ui.game()

start()