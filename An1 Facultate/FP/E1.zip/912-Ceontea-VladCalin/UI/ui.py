
class console:

    def __init__(self, board):
        self._board = board

    def game(self):
        self._board.place_apples()
        self._board.place_snake()
        print(str(self._board))
        p = 1
        direction = 'up'
        while p == 1:
            command = input()
            command = command.split(' ')
            if len(command) != 1 and command[0] == 'move':
                i = 0
                while i < int(command[1]):
                    ok = 1
                    if not self._board.valid(direction):
                        p = 0
                        ok = 0
                    if ok == 1:
                        self._board.move(direction)
                    i = i + 1
                if p == 1:
                    print(str(self._board))
            elif len(command) != 1 and command[0] != 'move':
                print('Not a valid command!')
            else:
                if command[0] == 'move':
                    ok = 1
                    if not self._board.valid(direction):
                        p = 0
                        ok = 0
                    if ok == 1:
                        self._board.move(direction)
                        print(str(self._board))
                elif command[0] == 'up':
                    ok = 1
                    check = 1
                    if direction == 'up':
                        ok = 0
                        print('Already this direction!')
                        check = 0
                    if direction == 'down':
                        ok = 0
                        print('The snake cannot eat itself, silly!')
                    direction = 'up'
                    if not self._board.valid(direction) and check == 1:
                        p = 0
                        ok = 0
                    if ok == 1:
                        self._board.move(direction)
                        print(str(self._board))

                elif command[0] == 'left':
                    ok = 1
                    check = 1
                    if direction == 'left':
                        ok = 0
                        print('Already this direction!')
                        check = 0
                    if direction == 'right':
                        ok = 0
                        print('The snake cannot eat itself, silly!')
                    direction = 'left'
                    if not self._board.valid(direction) and check == 1:
                        p = 0
                        ok = 0
                    if ok == 1:
                        self._board.move(direction)
                        print(str(self._board))

                elif command[0] == 'right':
                    ok = 1
                    check = 1
                    if direction == 'right':
                        ok = 0
                        print('Already this direction!')
                        check = 0
                    if direction == 'left':
                        ok = 0
                        print('The snake cannot eat itself, silly!')
                    direction = 'right'
                    if not self._board.valid(direction) and check == 1:
                        p = 0
                        ok = 0
                    if ok == 1:
                        self._board.move(direction)
                        print(str(self._board))

                elif command[0] == 'down':
                    ok = 1
                    check = 1
                    if direction == 'down':
                        ok = 0
                        print('Already this direction!')
                        check = 0
                    if direction == 'up':
                        ok = 0
                        print('The snake cannot eat itself, silly!')
                    direction = 'down'
                    if not self._board.valid(direction) and check == 1:
                        p = 0
                        ok = 0
                    if ok == 1:
                        self._board.move(direction)
                        print(str(self._board))
                else:
                    print('Not a valid command!')

        print(str(self._board))
        print('You lost! Better luck next time!')
