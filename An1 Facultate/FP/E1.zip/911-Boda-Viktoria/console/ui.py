class Ui:

    def __init__(self, game):
        self._game = game
        self._direction_snake = 'up'
        self._game_over = False

    @staticmethod
    def strip_command(command):
        parts = command.strip().split(' ', 1)
        return parts[0], parts[1:]

    def move_ui(self, command_params):
        if len(command_params) == 0:
            number_of_steps = 1
        else:
            if not str(command_params[0]).isdecimal():
                raise ValueError("The parameter should be a number!")
            number_of_steps = int(command_params[0])
        if self._game.move_snake(number_of_steps, self._direction_snake) is False:
            self._game_over = True

    def up_ui(self, command_params):
        if len(command_params) != 0:
            raise ValueError("Wrong input!")
        if self._direction_snake != 'up' and self._direction_snake != 'down':
            self._direction_snake = 'up'
            self._game.move_up()
        else:
            raise ValueError("The snake cannot rotate 180 degrees.")

    def down_ui(self, command_params):
        if len(command_params) != 0:
            raise ValueError("Wrong input!")
        if self._direction_snake != 'down' and self._direction_snake != 'up':
            self._direction_snake = 'down'
            self._game.move_down()
        else:
            raise ValueError("The snake cannot rotate 180 degrees.")

    def left_ui(self, command_params):
        if len(command_params) != 0:
            raise ValueError("Wrong input!")
        if self._direction_snake != 'left' and self._direction_snake != 'right':
            self._direction_snake = 'left'
            self._game.move_left()
        else:
            raise ValueError("The snake cannot rotate 180 degrees.")

    def right_ui(self, command_params):
        if len(command_params) != 0:
            raise ValueError("Wrong input!")
        if self._direction_snake != 'right' and self._direction_snake != 'left':
            self._direction_snake = 'right'
            self._game.move_right()
        else:
            raise ValueError("The snake cannot rotate 180 degrees.")

    def place_snake_ui(self):
        self._game.place_snake()

    def place_apples_ui(self):
        self._game.place_apples()

    def start(self):
        command_dict = {'move': self.move_ui, 'up': self.up_ui, 'down': self.down_ui,
                        'right': self.right_ui, 'left': self.left_ui}
        self.place_snake_ui()
        try:
            self.place_apples_ui()
        except ValueError as ve:
            print(str(ve))
        while not self._game_over:
            print(self._game.return_board)
            command = input("Command >")
            command_word, command_parameters = self.strip_command(command)
            if command_word in command_dict:
                try:
                    command_dict[command_word](command_parameters)
                    if self._game_over is True:
                        print("The game is over!")
                except ValueError as ve:
                    print(str(ve))

