"""
Module for managing settings for the application.
"""


class SettingsExceptions(Exception):
    def _init_(self, msg):
        self._msg = msg


class Settings:
    """
    A class that loads data from settings.properties
    and gives information about settings.
    """
    def __init__(self):
        self.settings_dictionary = {}
        self._load()

    def _load(self):
        settings_file = open("settings.properties", 'rt')
        lines = settings_file.readlines()
        settings_file.close()
        self.settings_dictionary = {}
        for line in lines:
            line = line.split('=')
            line[0] = line[0].strip('\n "')
            line[1] = line[1].strip('\n "')
            self.settings_dictionary[line[0]] = line[1]

    def settings(self, setting):
        if setting in self.settings_dictionary:
            return self.settings_dictionary[setting]
        raise SettingsExceptions('No such settings!')
