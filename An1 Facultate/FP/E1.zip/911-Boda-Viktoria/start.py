from console.ui import Ui
from service.board import Board
from service.game import Game
from settings import Settings

settings_class = Settings()
DIM = settings_class.settings("DIM")
apple_count = settings_class.settings("apple_count")

board = Board(DIM, apple_count)

game = Game(board)

ui = Ui(game)

ui.start()

