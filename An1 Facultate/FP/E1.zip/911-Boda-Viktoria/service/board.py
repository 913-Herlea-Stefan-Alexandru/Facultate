from texttable import Texttable


class Board:

    def __init__(self, DIM, apple_count):
        self._rows = int(DIM)
        self._columns = int(DIM)
        self._apple_number = int(apple_count)
        self._board = [[None for j in range(self._columns)] for i in range(self._rows)]

    @property
    def rows(self):
        return self._rows

    @rows.setter
    def rows(self, value):
        self._rows= value

    @property
    def columns(self):
        return self._columns

    @columns.setter
    def columns(self, value):
        self._columns = value

    @property
    def board(self):
        return self._board

    @board.setter
    def board(self, value):
        self._board = value

    def move(self, point, symbol):
        self._board[int(point.x)][int(point.y)] = symbol

    def __str__(self):
        t = Texttable()
        for row in range(self._rows):
            row_data = []
            for index in self._board[row]:
                if index == '*':
                    row_data.append('*')
                if index == '+':
                    row_data.append('+')
                if index == '.':
                    row_data.append('.')
                elif index is None or index == 'None':
                    row_data.append(' ')
            t.add_row(row_data)
        return t.draw()

