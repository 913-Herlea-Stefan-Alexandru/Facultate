import copy
import random

from entity.point import Point


class Game:
    def __init__(self, board):
        self._board = board
        self.head_snake = Point(None, None)
        self.snake_end = Point(None, None)
        self.snake_length = 3
        self.snake_points = []

    @property
    def return_board(self):
        return self._board

    def is_the_place_empty(self, row, column):
        if row < 0 or row >= self._board.rows or column < 0 or column >= self._board.columns:
            return True
        if self._board.board[row][column] is None:
            return True
        return False

    def show_available_places(self):
        available_places_for_apples = []
        for row in range(self._board.rows):
            for column in range(self._board.columns):
                if self.is_the_place_empty(row, column):
                    available_places_for_apples.append(Point(row, column))
        return available_places_for_apples

    def place_snake(self):
        row_snake_first_plus = self._board.rows // 2
        column_snake_first_plus = self._board.columns // 2
        self._board.move(Point(row_snake_first_plus, column_snake_first_plus), '+')
        self._board.move(Point(row_snake_first_plus + 1, column_snake_first_plus), '+')
        self._board.move(Point(row_snake_first_plus - 1, column_snake_first_plus), '*')
        self.snake_points.append(Point(row_snake_first_plus - 1, column_snake_first_plus))
        self.snake_points.append(Point(row_snake_first_plus, column_snake_first_plus))
        self.snake_points.append(Point(row_snake_first_plus + 1, column_snake_first_plus))
        self.head_snake = Point(row_snake_first_plus - 1, column_snake_first_plus)
        self.snake_end = Point(row_snake_first_plus+1, column_snake_first_plus)

    def place_apples(self):
        if self._board._apple_number >= self._board.rows * self._board.columns - 3:
            raise ValueError("Too many apples!")
        available_places_for_apples = self.show_available_places()
        nr_of_apples_placed = 0
        while nr_of_apples_placed < self._board._apple_number:
            random_place = random.choice(available_places_for_apples)
            if self.are_their_neighbors_apple_free(random_place) and \
                    self.is_the_place_empty(random_place.x, random_place.y) :
                nr_of_apples_placed += 1
                self._board.move(random_place, '.')

    def are_their_neighbors_apple_free(self, random_place):
        if not self.is_the_place_empty(random_place.x, random_place.y - 1):
            return False
        if not self.is_the_place_empty(random_place.x, random_place.y + 1):
            return False
        if not self.is_the_place_empty(random_place.x - 1, random_place.y):
            return False
        if not self.is_the_place_empty(random_place.x - 1, random_place.y - 1):
            return False
        if not self.is_the_place_empty(random_place.x - 1, random_place.y + 1):
            return False
        if not self.is_the_place_empty(random_place.x + 1, random_place.y):
            return False
        if not self.is_the_place_empty(random_place.x + 1, random_place.y - 1):
            return False
        if not self.is_the_place_empty(random_place.x + 1, random_place.y + 1):
            return False
        return True

    def place_random_apple(self):
        available_places_for_apples = self.show_available_places()
        nr_of_apples_placed = 0
        while nr_of_apples_placed < 1:
            random_place = random.choice(available_places_for_apples)
            if self.are_their_neighbors_apple_free(random_place) and \
                    self.is_the_place_empty(random_place.x, random_place.y) :
                nr_of_apples_placed += 1
                self._board.move(random_place, '.')

    def is_it_a_hit(self, point):
        if self._board.board[int(point.x)][int(point.y)] == '.':
            self.place_random_apple()
            self.snake_length += 1
            return True
        return False

    def move_snake(self, number_of_steps, direction):
        if direction == 'up':
            for do_it in range(number_of_steps):
                if self.is_it_game_over(Point(self.head_snake.x - 1, self.head_snake.y)) is True:
                    return False
                if self.is_it_a_hit(Point(self.head_snake.x - 1, self.head_snake.y)) is False:
                    self.head_snake = Point(self.head_snake.x - 1, self.head_snake.y)
                    self.snake_end = self.snake_points[-1]
                    aux_list = []
                    aux_list.append(self.head_snake)
                    for i in range(len(self.snake_points)-1):
                        aux_list.append(self.snake_points[i])
                    self.snake_points = copy.deepcopy(aux_list)

                    self._board.move(self.snake_points[0], '*')
                    for point in range(1, len(self.snake_points)):
                        self._board.move(self.snake_points[point], '+')
                    self._board.move(self.snake_end, None)
                else:
                    self.head_snake = Point(self.head_snake.x - 1, self.head_snake.y)
                    self.snake_end = self.snake_points[-1]
                    aux_list = []
                    aux_list.append(self.head_snake)
                    for i in range(len(self.snake_points) - 1) :
                        aux_list.append(self.snake_points[i])
                    self.snake_points = copy.deepcopy(aux_list)

                    self._board.move(self.snake_points[0], '*')
                    for point in range(1, len(self.snake_points)) :
                        self._board.move(self.snake_points[point], '+')
                    self.snake_points.append(self.snake_end)
        if direction == 'down':
            for do_it in range(number_of_steps):
                if self.is_it_game_over(Point(self.head_snake.x + 1, self.head_snake.y)) is True:
                    return False
                if self.is_it_a_hit(Point(self.head_snake.x + 1, self.head_snake.y)) is False:
                    self.head_snake = Point(self.head_snake.x + 1, self.head_snake.y)
                    self.snake_end = self.snake_points[-1]
                    aux_list = []
                    aux_list.append(self.head_snake)
                    for i in range(len(self.snake_points)-1):
                        aux_list.append(self.snake_points[i])
                    self.snake_points = copy.deepcopy(aux_list)

                    self._board.move(self.snake_points[0], '*')
                    for point in range(1, len(self.snake_points)):
                        self._board.move(self.snake_points[point], '+')
                    self._board.move(self.snake_end, None)
                else:
                    self.head_snake = Point(self.head_snake.x + 1, self.head_snake.y)
                    self.snake_end = self.snake_points[-1]
                    aux_list = []
                    aux_list.append(self.head_snake)
                    for i in range(len(self.snake_points) - 1) :
                        aux_list.append(self.snake_points[i])
                    self.snake_points = copy.deepcopy(aux_list)

                    self._board.move(self.snake_points[0], '*')
                    for point in range(1, len(self.snake_points)) :
                        self._board.move(self.snake_points[point], '+')
                    self.snake_points.append(self.snake_end)
        if direction == 'right':
            for do_it in range(number_of_steps):
                if self.is_it_game_over(Point(self.head_snake.x, self.head_snake.y + 1)) is True:
                    return False
                if self.is_it_a_hit(Point(self.head_snake.x, self.head_snake.y + 1)) is False:
                    self.head_snake = Point(self.head_snake.x, self.head_snake.y + 1)
                    self.snake_end = self.snake_points[-1]
                    aux_list = []
                    aux_list.append(self.head_snake)
                    for i in range(len(self.snake_points)-1):
                        aux_list.append(self.snake_points[i])
                    self.snake_points = copy.deepcopy(aux_list)

                    self._board.move(self.snake_points[0], '*')
                    for point in range(1, len(self.snake_points)):
                        self._board.move(self.snake_points[point], '+')
                    self._board.move(self.snake_end, None)
                else:
                    self.head_snake = Point(self.head_snake.x, self.head_snake.y + 1)
                    self.snake_end = self.snake_points[-1]
                    aux_list = []
                    aux_list.append(self.head_snake)
                    for i in range(len(self.snake_points) - 1) :
                        aux_list.append(self.snake_points[i])
                    self.snake_points = copy.deepcopy(aux_list)

                    self._board.move(self.snake_points[0], '*')
                    for point in range(1, len(self.snake_points)) :
                        self._board.move(self.snake_points[point], '+')
                    self.snake_points.append(self.snake_end)
        if direction == 'left':
            for do_it in range(number_of_steps):
                if self.is_it_game_over(Point(self.head_snake.x, self.head_snake.y - 1)) is True:
                    return False
                if self.is_it_a_hit(Point(self.head_snake.x, self.head_snake.y - 1)) is False:
                    self.head_snake = Point(self.head_snake.x, self.head_snake.y - 1)
                    self.snake_end = self.snake_points[-1]
                    aux_list = []
                    aux_list.append(self.head_snake)
                    for i in range(len(self.snake_points)-1):
                        aux_list.append(self.snake_points[i])
                    self.snake_points = copy.deepcopy(aux_list)

                    self._board.move(self.snake_points[0], '*')
                    for point in range(1, len(self.snake_points)):
                        self._board.move(self.snake_points[point], '+')
                    self._board.move(self.snake_end, None)
                else:
                    self.head_snake = Point(self.head_snake.x, self.head_snake.y - 1)
                    self.snake_end = self.snake_points[-1]
                    aux_list = []
                    aux_list.append(self.head_snake)
                    for i in range(len(self.snake_points) - 1) :
                        aux_list.append(self.snake_points[i])
                    self.snake_points = copy.deepcopy(aux_list)

                    self._board.move(self.snake_points[0], '*')
                    for point in range(1, len(self.snake_points)) :
                        self._board.move(self.snake_points[point], '+')
                    self.snake_points.append(self.snake_end)
        return True

    def move_up(self):
        self.move_snake(1, 'up')

    def move_down(self):
        self.move_snake(1, 'down')

    def move_left(self):
        self.move_snake(1, 'left')

    def move_right(self):
        self.move_snake(1, 'right')

    def is_it_game_over(self, point):
        if point.x < 0 or point.y < 0 or point.x >= self._board.rows or point.y >= self._board.columns:
            return True
        if self._board.board[int(point.x)][int(point.y)] == '*' or self._board.board[int(point.x)][int(point.y)] == '+':
            return True
        return False
