from copy import deepcopy
import random


class Spot:
    """
    This is the class for every square in the board
    """
    def __init__(self, marked=False, char='o'):
        self.marked = marked
        self.char = char

    def __repr__(self):
        return str( self )

    def __str__(self):
        if self.char != 'o':
            return self.char
        return str(int(self.marked))

    def mark_spot(self):
        self.marked = True

    def clear_spot(self):
        self.marked = False

    def get_state(self):
        return self.marked


class Snake:
    def __init__(self, n):
        self.n = n
        self.coords = [(n//2-1, n//2), (n//2, n//2), (n//2+1, n//2)]
        self.dead = False
        self.last_tail = (0, 0)

    def add_tuple(self, t1, t2):
        return (t1[0] + t2[0], t1[1] + t2[1])

    def add_tail(self):
        self.coords.append(self.last_tail)

    def is_dead(self):
        return self.dead

    def get_head(self):
        return self.coords[0]

    def move(self, dx, dy):
        """
        Makes a move depending on the direction.
        This only moves the snake one position.
        :param dx: row
        :param dy: column
        :return:
        """
        if self.dead:
            return
        if dx != 0:
            for i in range(1, dx+1):
                newhead = self.add_tuple(self.coords[0], (1, 0))
                # if the snake wants to move outside the matrix or wants to move in a square where its body is => death
                if newhead in self.coords or self.outside_matrix(newhead):
                    self.dead = True
                    return
                self.coords = [newhead] + self.coords
                self.last_tail = self.coords.pop()
            for i in range(-1, dx-1, -1):
                newhead = self.add_tuple(self.coords[0], (-1, 0))
                if newhead in self.coords or self.outside_matrix(newhead):
                    self.dead = True
                    return
                self.coords = [newhead] + self.coords
                self.last_tail = self.coords.pop()

        if dy != 0:
            for i in range(1, dy+1):
                newhead = self.add_tuple(self.coords[0], (0, 1))
                if newhead in self.coords or self.outside_matrix(newhead):
                    self.dead = True
                    return
                self.coords = [newhead] + self.coords
                self.last_tail = self.coords.pop()
            for i in range(-1, dy-1, -1):
                newhead = self.add_tuple(self.coords[0], (0, -1))
                if newhead in self.coords or self.outside_matrix(newhead):
                    self.dead = True
                    return
                self.coords = [newhead] + self.coords
                self.last_tail = self.coords.pop()


    def outside_matrix(self, x):
        """
        Is the snake is outside the matrix, it is dead...
        :param x:
        :return:
        """
        return x[0] < 0 or x[0] >= self.n or x[1] < 0 or x[1] >= self.n

    def get_snake(self):
        return deepcopy(self.coords)


class Board:
    def __init__(self, n, apple_count):
        self.dimx = n
        self.matrix = self.new_board()
        self.apple_count = apple_count
        self.snake = Snake(n)
        self.place_apples(self.apple_count)

    def new_board(self):
        """
        Create the empty board
        :return:
        """
        matrix = []
        for i in range(0, self.dimx):
            row = []
            for j in range(0, self.dimx):
                row.append(Spot())
            matrix.append( row )
        return matrix


    def inside_matrix(self, x, y):
        return x >= 0 and x < 8 and y >= 0 and y < 8


    def get_spot(self, x, y):
        if self.inside_matrix(x, y):
            return self.matrix[ x ][ y ] or Spot(self.is_snake(x, y))
        raise ValueError('coordinates outside board')

    def is_apple(self, x, y):
        """
        Checks if a spot is an apple (spot value = true)
        :param x:
        :param y:
        :return:
        """
        if self.inside_matrix(x, y):
            return self.matrix[ x ][ y ].marked
        raise ValueError('coordinates outside board')

    def is_snake(self, x, y):
        """
        Checks if a spot is part of the snake (belongs to the coords of the snake)
        :param x:
        :param y:
        :return:
        """
        if (x, y) in self.snake.coords:
            return True
        if not self.inside_matrix(x, y):
            raise ValueError('coordinates outside board')

    def place_apples(self, n):
        """
        This function places apples randomly on the board
        :param n: how many apples we want to place
        :return:
        """
        available = []
        for i in range(0, self.dimx):
            for j in range(0, self.dimx):
                if self.get_spot(i,j).marked == False:
                    available.append((i, j))

        for i in range(n):
            move = random.choice(available)
            self.mark_spot(move[0], move[1])


    def mark_spot(self, x, y):
        if self.inside_matrix(x, y):
            spot = self.get_spot(x, y)
            spot.mark_spot()
        else:
            raise ValueError('coordinates outside board')

    def clear_spot(self, x, y):
        if self.inside_matrix(x, y):
            spot = self.get_spot(x, y)
            spot.clear_spot()
        else:
            raise ValueError('coordinates outside board')


    def make_move(self, x, y):
        self.snake.move(x, y)

        # checks if the snake ate an apple; if so, the tail's length increases and another apple is places

        head = self.snake.get_head()
        if self.is_apple(head[0], head[1]):
            self.snake.add_tail()
            self.clear_spot(head[0], head[1])
            self.place_apples(1)


    def get_board(self):
        new_board = deepcopy(self.matrix)
        for i in range(0, self.dimx):
            for j in range(0, self.dimx):
                if (i,j) in self.snake.coords:
                    new_board[i][j] = Spot(False, 'b')     # body of the snake
        head = self.snake.coords[0]
        new_board[head[0]][head[1]] = Spot(False, 'h')     # head of the snake
        return new_board

