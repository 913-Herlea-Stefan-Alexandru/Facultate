from Service import *
from domain import *
from texttable import *

class UI:

    def __init__(self, service):
        self.serv = service

    def print_board(self):
        t = Texttable()
        board = self.serv.get_board()
        for line in board:
            row = []
            for spot in line:
                if spot.marked == True:
                    row.append('.')
                elif str(spot) == 'h':
                    row.append('*')
                elif str(spot) == 'b':
                    row.append('+')
                else:
                    row.append(' ')
            t.add_row(row)
        print(t.draw())
        print()

    def print_commands(self):
        print('This is what you can do:')
        print('- move [n]')
        print('- up')
        print('- down')
        print('- right')
        print('- left')
        print('- exit')

    def get_command(self):
        cmd = input('> ')
        cmd = cmd.strip().split()
        return cmd

    def parse_move(self, params):
        """
        Moves the snake <params> positions in the last direction that was given (implicitly up)
        :param params:
        :return:
        """
        if len(params) == 0:
            self.serv.repeat_move(1)
        else:
            x = int(params[ 0 ])
            self.serv.repeat_move(x)

    def parse_up(self, params):
        """
        this function move snakes one position up
        => row - 1
        => same column
        :param params:
        :return:
        """
        try:
            self.serv.make_move(-1, 0)
        except ValueError as ve:
            print(ve)

    def parse_down(self, params):
        """
        this function move snakes down one position
        => row + 1
        => same column
        :param params:
        :return:
        """
        try:
            self.serv.make_move(1, 0)
        except ValueError as ve:
            print(ve)

    def parse_right(self, params):
        """
        this function move snakes to the right
        => same row
        => column + 1
        :param params:
        :return:
        """
        try:
            self.serv.make_move(0, 1)
        except ValueError as ve:
            print(ve)

    def parse_left(self, params):
        """
        this function move snakes to the left
        => same row
        => column - 1
        :param params:
        :return:
        """
        try:
            self.serv.make_move(0, -1)
        except ValueError as ve:
            print(ve)


    def loop(self):
        if self.serv.game_over():
            self.print_board()
            print("Game over!")
            return

        self.print_board()
        cmd = self.get_command()
        if len(cmd) > 0:
            if cmd[ 0 ] == 'move':
                self.parse_move(cmd[1:])
            elif cmd[ 0 ] == 'up':
                self.parse_up(cmd[1:])
            elif cmd[ 0 ] == 'down':
                self.parse_down(cmd[1:])
            elif cmd[ 0 ] == 'left':
                self.parse_left(cmd[1:])
            elif cmd[ 0 ] == 'right':
                self.parse_right(cmd[1:])
            elif cmd[ 0 ] == 'exit':
                return
            else:
                print('Invalid command')
        else:
            print('Empty command')
        self.loop()

    def start(self):
        print("Hello!")
        print("This is snake")
        self.print_commands()
        self.loop()
