from Service import Service
from domain import Board
from ui import UI

f = open("settings.txt", 'r')
line = f.readline().strip().split()

serv = Service(Board(int(line[0]), int(line[1])))
ui = UI(serv)
ui.start()