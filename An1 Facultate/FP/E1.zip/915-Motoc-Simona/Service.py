from domain import *

class Service:

    def __init__(self, board):
        self.board = board
        self.last_move = (-1, 0)

    def game_over(self):
        return self.board.snake.dead

    def make_move(self, x, y):
        """
        We use this function for the commands <up><down><left><right>
        The move is only made once, depending on where we want the snake to go
        :param x:
        :param y:
        :return:
        """
        if self.add_tuple(self.last_move, (x, y)) == (0, 0):
            raise ValueError("You cannot go from up to down/ right to left")

        self.board.make_move(x, y)
        if x>0:
            self.last_move = (1, 0)
        if x<0:
            self.last_move = (-1, 0)
        if y>0:
            self.last_move = (0, 1)
        if y<0:
            self.last_move = (0, -1)

    def add_tuple(self, t1, t2):
        return (t1[0] + t2[0], t1[1] + t2[1])

    def repeat_move(self, count):
        """
        We use this function for the command <move [n]>
            - makes a move as many times as the user said.
            - the direction is the one that was previously given or up implicitly
        :param count: the param from the <move> function (n)
        :return:
        """
        for i in range(count):
            self.make_move(self.last_move[0], self.last_move[1])

    def get_board(self):
        return self.board.get_board()
