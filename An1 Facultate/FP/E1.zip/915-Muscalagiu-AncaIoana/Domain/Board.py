import random
import texttable
from Domain.Validators import RangeError, PlaceError
class Board:
    def __init__(self, dim,apple_count, move_validator):
        self._dim = dim
        self._apple_count = apple_count
        self._validator = move_validator
        self._direction = [-1,0]
        self.create_board()

    def create_board(self):
        """
            This function creates the initial board by placing the snake and ' ' in the empty squares and records
        the positions of all elements of the snake.
        """
        self._board = [[] for i in range(self._dim)]
        for row in range(len(self._board)):
            for column in range(self._dim):
                self._board[row].append(' ')

        middle = self._dim //2
        self._board[middle-1][middle] = '*'
        self._snake_head = [middle-1,middle]
        self._board[middle][middle] = '+'
        self._board[middle+1][middle] = '+'
        self._snake = [[middle-1,middle],[middle,middle],[middle+1,middle]]

    def place_apple(self):
        """"
          This function places the initial apples on the board randomly doing the following: it takes random values
        for row and column and tries to see if it is a valid place for placing an apple. The function stops when all
        the apples are placed or if there are no more available empty squares.
        """
        num_apples = self._apple_count
        while num_apples > 0 and self.check_board_full() == False:
            try:
                row = random.randint(0, self._dim)
                column = random.randint(0, self._dim)
                if self.get_square(row,column) != ' ':
                    raise PlaceError
                self._validator.validate_place_apple(row, column, self)
                self.mark_square(row, column, '.')
                num_apples -= 1

            except RangeError as re:
                pass
            except PlaceError as pe:
                pass

    def place_another_apple(self):
        """
            This function replaces the apple that was eating using the same strategy as we did in the beginning.

        """
        placed = False
        while not placed and self.check_board_full() == False:
            try:
                row = random.randint(0, self._dim)
                column = random.randint(0, self._dim)
                if self.get_square(row,column) != ' ':
                    raise PlaceError
                self._validator.validate_place_apple(row, column, self)
                self.mark_square(row, column, '.')
                placed = True
            except RangeError as re:
                pass
            except PlaceError as pe:
                pass

    def mark_square(self,row,column,value):
        self._board[row][column]  = value

    def get_square(self, row, column):
        if row < 0 or row > self._dim -1 or column < 0 or column > self._dim - 1:
            raise RangeError
        return self._board[row][column]

    def get_board_to_table(self):
        """
            This function returns the board in a texttable format in order to be printed
        :return: table -texttable object
        """
        table = texttable.Texttable()
        for index in range(self._dim):
            table.add_row(self._board[index])
        return table

    def get_direction(self):
        return self._direction

    def change_direction(self,direction):
        """
            This function changes the direction of the snake with the new one and moves it in that direction by 1
        :param direction: the new direction
        :return: game_not_over - True -> the game continues
                               - False -> the game is over, the player lost
        """
        self._direction = direction
        game_not_over = self.move_snake(1)
        return game_not_over



    def move_snake(self,num_squares):
        """
            This function moves the snake num_square squares in a certain direction by marking the required
        squares on the board and updating the list that contains the coordinated of the segments of the snake.
        :param num_squares: the number of squares that the snake is about to be moved
        :return: False - the player lost (the snake hits one of its segments of the edge of the board)
                 True - the game continues and the move was successfully made
        """
        row = self._snake[0][0]
        column = self._snake[0][1]
        for index in range(num_squares):
            try:
                row += self._direction[0]
                column += self._direction[1]
                tail_row = self._snake[-1][0]
                tail_column = self._snake[-1][1]
                self.mark_square(tail_row,tail_column,' ')
                value = self.get_square(row, column)
                if value == '+':
                    return False


                for index in range(len(self._snake)-1,0,-1):
                    self._snake[index][0] = self._snake[index-1][0]
                    self._snake[index][1] = self._snake[index-1][1]

                self._snake[0][0] = row
                self._snake[0][1] = column

                if value == '.':
                    self._snake.append([tail_row, tail_column])
                    self.mark_square(tail_row,tail_column,'+')
                    self.place_another_apple()

                self.mark_square(row,column,'*')
                self.mark_square(self._snake[1][0],self._snake[1][1],'+')
                self.mark_square(self._snake[-1][0],self._snake[-1][1],'+')


            except RangeError as re:
                return False
        return True

    def check_board_full(self):
        """
           This function check if there are no spaces avaialble for the apples to be put on the board
        :return: False - there are spaces left for apples
                 True - there are no spaces left for the apples to be put
        """
        for row in range(self._dim):
            for col in range(self._dim):
                if self.get_square(row,col) == ' ':
                    try:
                        self._validator.validate_place_apple(row, col, self)
                        return False
                    except RangeError as re:
                        pass
                    except PlaceError as pe:
                        pass
        return True


