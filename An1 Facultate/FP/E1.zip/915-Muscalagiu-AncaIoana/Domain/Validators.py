class RangeError(Exception):
    pass

class PlaceError(Exception):
    pass

class InputError(Exception):
    pass

class MoveError(Exception):
    pass

class Validator:
    @staticmethod
    def validate_place_apple(row,column,board):
        """
          This function validates the placing of an apple to nit pe adjacent to any other apples or to not ocupy the
        initial squares of the snake. For each checking if the squared checked does not have all the neighbours we
        just throw a RangeError Exception and catch it so we can go check the next neighbour.
        :param row: the row the apple is about to be places
        :param column: the column the apple is about to be placed
        :param board: the board on which the apples is placed
        :raises PlaceError - the apple cannot pe placed there
        """
        try:
            if board.get_square(row, column) != ' ':
                raise PlaceError
        except RangeError as re:
            pass

        try:
            if board.get_square(row - 1, column) != ' ':
                raise PlaceError
        except RangeError as re:
            pass

        try:
            if board.get_square(row + 1, column) != ' ':
                raise PlaceError
        except RangeError as re:
            pass

        try:
            if board.get_square(row, column - 1) != ' ':
                raise PlaceError
        except RangeError as re:
            pass

        try:
            if board.get_square(row, column + 1) != ' ':
                raise PlaceError
        except RangeError as re:
            pass



