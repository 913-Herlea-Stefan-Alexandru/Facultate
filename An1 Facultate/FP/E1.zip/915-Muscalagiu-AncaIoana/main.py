from Domain.Validators import Validator
from Services.Game import Game
from Domain.Board import Board
from Ui.ui import Ui
from settings import Settings

settings = Settings('settings.properties')
dim,num_apples = settings.read_file()
validator = Validator()
board = Board(dim,num_apples,validator)
game = Game(board)
ui = Ui(game)
ui.start()

