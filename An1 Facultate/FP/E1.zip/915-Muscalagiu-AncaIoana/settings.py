class Settings:
    def __init__(self, file_name):
        self._file_name = file_name

    def read_file(self):
        config_settings = []
        try:
            f_settings = open(self._file_name)
            lines = f_settings.readlines()
            for line in lines:
                line = line.strip('\n')
                line = line.split('=')
                for part in line:
                    part = part.strip()
                if line[1][0] == '"':
                    line[1] = line[1][1:-1]
                config_settings.append(int(line[1]))
            f_settings.close()
        except IOError:
            print('Error reading settings file')
        return config_settings[:]

    def get_config_settings(self):
        config_settings = self.read_file()
        dim = config_settings[0]
        num_apples = config_settings[1]
        return dim,num_apples

