from Domain.Validators import MoveError
class Game:
    def __init__(self,board):
        self._board = board


    def initialise_board(self):
        """
            This function initilises the board by placing the snake in the middle and placing the apples
        """
        self._board.place_apple()

    def get_board(self):
        return self._board.get_board_to_table()

    def move_command(self,num_squares):
        """
            This function moves the snake on the board with num_squares number of squares
        :param num_squares: the number of squares that the snake is moved
        :return:
        """
        game_not_over = self._board.move_snake(num_squares)
        return game_not_over

    def change_direction(self,string_direction):

        if string_direction == 'up':
            direction = [-1,0]
        if string_direction == 'down':
            direction = [1,0]
        if string_direction == 'left':
            direction = [0,-1]
        if string_direction == 'right':
            direction = [0,1]

        old_direction = self._board.get_direction()
        if direction[0] == old_direction[0] and direction[1] == old_direction[1]:
            return True
        if old_direction[0] == direction[0] and old_direction[1] == -direction[1]:
            raise MoveError('You cannot change the direction to 180 degrees')
        if old_direction[1] == direction[1] and old_direction[0] == -direction[0]:
            raise MoveError('You cannot change the direction to 180 degrees')


        game_not_over = self._board.change_direction(direction)
        return game_not_over


