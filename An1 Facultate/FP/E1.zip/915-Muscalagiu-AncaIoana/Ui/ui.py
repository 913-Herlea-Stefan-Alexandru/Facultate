from Domain.Validators import InputError,RangeError,MoveError
class Ui:
    def __init__(self,game):
        self._game = game

        self._options = {'move': [self.ui_move_command,'<move [n]>'],
                         'up' : [self.ui_change_direction_command,'<up>'],
                         'down' : [self.ui_change_direction_command,'<down>'],
                         'left': [self.ui_change_direction_command,'<left>'],
                         'right': [self.ui_change_direction_command,'<right>']
                        }

    def print_board(self):
        table = self._game.get_board()
        print(table.draw())

    def print_options(self):
        for key in self._options.keys():
            print (f'{key} - {self._options[key][1]}')

    def get_command_and_args(self,command):
        parts = command.split(' ')
        if len(parts) > 2 :
            raise InputError('This is an invalid command')
        if parts[0] not in self._options.keys():
            raise InputError('This is an invalid command')
        if len(parts) == 1 :
            if command == 'move':
                return parts[0], 1
            else:
                return parts[0],parts[0]
        if len(parts) == 2:
            try:
                if parts[0] !='move':
                    raise InputError('Invalid change direction command')
                parts[1] = int(parts[1])
            except ValueError as ve:
                raise InputError('Invalid move command')
            return parts[0],parts[1]

    def ui_move_command(self,number_squares):
        game_not_over = self._game.move_command(number_squares)
        return game_not_over

    def ui_change_direction_command(self,direction):
        game_not_over = self._game.change_direction(direction)
        return game_not_over

    def start(self):
        self._game.initialise_board()
        while True:
            try:
                self.print_board()
                self.print_options()
                command = input('Please insert the command you want to give:')
                command.strip()
                command,args = self.get_command_and_args(command)
                game_not_over = self._options[command][0](args)
                if game_not_over == False:
                    print('Game over')
                    return
            except InputError as ie:
                print(str(ie))
            except RangeError as re:
                print(str(re))
            except MoveError as me:
                print(str(me))








