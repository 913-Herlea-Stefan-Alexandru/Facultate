from console import UI
from service import Service
from domain import Table
from settings import Settings


if __name__=="__main__":
    # here I take attribues from settings file
    settings = Settings('settings.properties')
    DIM = int(settings.get_dimension())
    apple_count = int(settings.get_apples())

    table = Table(DIM, apple_count)
    service = Service(table)
    console = UI(service)

    # run the game
    console.run()