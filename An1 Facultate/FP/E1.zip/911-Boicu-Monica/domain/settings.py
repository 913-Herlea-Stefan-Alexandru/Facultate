class Settings:

    def __init__(self, filename='settings.properties'):
        self._filename = filename
        self._settings = {}
        self._load_properties()

    @property
    def dim(self):
        return self._settings['dim']

    @property
    def apple_count(self):
        return self._settings['apple_count']

    def _load_properties(self):
        f = open(self._filename, 'rt')
        lines = f.readlines()
        f.close()
        for line in lines:
            tokens = line.split('=')
            self._settings[tokens[0].lower()] = int(tokens[1])

#
# settings = Settings()
# print(settings.dim)
# print(settings.apple_count)
