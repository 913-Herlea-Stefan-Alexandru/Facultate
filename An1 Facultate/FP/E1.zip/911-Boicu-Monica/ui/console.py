from service.snake_game import SnakeGame
from domain.settings import Settings
from service.snake_game import SnakeException


class Ui:

    def __init__(self, snake_game):
        """
        :type snake_game: SnakeGame
        """
        self._snake_game = snake_game

    @property
    def snake_game(self):
        return self._snake_game

    def start(self):
        finished = False
        can_move = True
        command_dict = {'move': self._move, 'left': self._change_direct, 'right': self._change_direct,
                        'up': self._change_direct, 'down': self._change_direct}
        while not finished:
            print(self._snake_game.game_area)
            if can_move:
                try:
                    command = input("command> ")
                    command_word, command_param = self.split_command(command)
                    if command_word in command_dict:
                        game_over = command_dict[command_word](command_word, command_param)
                        if game_over:
                            print("Game over!")
                            return None
                    else:
                        print('Invalid command.')
                except SnakeException as e:
                    print(str(e))
                except ValueError as ve:
                    print(str(ve))
                except Exception as ex:
                    print('Ooops! Kind of unexpected: ' + str(ex))

    @staticmethod
    def split_command(command):
        tokens = command.strip().split(' ')
        tokens[0] = tokens[0].strip().lower()
        return tokens[0], '' if len(tokens) == 1 else tokens[1].strip()

    def _move(self, command_word, param):
        if param == '':
            return self._snake_game.move()
        else:
            return self._snake_game.move(int(param))

    def _change_direct(self, command_word, param):
        if param != '':
            raise ValueError('Invalid command! No params expected for changing direction.')
        change_dict = {'up': 1, 'down': -1, 'left': -2, 'right': 2}
        return self._snake_game.change_direction(change_dict[command_word])


ui = Ui(SnakeGame(Settings()))
ui.start()
