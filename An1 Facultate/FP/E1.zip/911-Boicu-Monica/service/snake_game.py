from texttable import Texttable
from domain.settings import Settings

import random

class GameArea:

    def __init__(self, settings):
        self._dim = settings.dim
        self._apple_count = settings.apple_count
        self._data = [[None for j in range(self._dim)] for i in range(self._dim)]

    @property
    def dim(self):
        return self._dim

    @property
    def apple_count(self):
        return self._apple_count

    def is_free(self, row, col):
        return self._data[row][col] is None

    def set_cel(self, row, col, symbol):
        self._data[row][col] = symbol

    def get_cel(self, row, col):
        return self._data[row][col]

    def __str__(self):
        table = Texttable()
        for row in range(self._dim):
            row_cells = []
            for value in self._data[row]:
                if value is None:
                    row_cells.append(' ')
                else:
                    row_cells.append(value)
            table.add_row(row_cells)
        return table.draw()


class ApplePlacementStrategy:

    def __init__(self, game_area):
        self._game_area = game_area

    def place_apples(self, apple_count):
        for i in range(apple_count):
            self._place_apple()

    def _place_apple(self):
        valid_apple_pos = []

        for row in range(self._game_area.dim):
            for col in range(self._game_area.dim):
                if self._game_area.is_free(row, col) and self._is_valid_apple_placement(row, col):
                    valid_apple_pos.append((row, col))
        placement = random.choice(valid_apple_pos)
        return self._game_area.set_cel(placement[0], placement[1], '.')

    def _is_valid_apple_placement(self, row, col):
        dim = self._game_area.dim
        if (row - 1 >= 0 and self._is_apple(row - 1, col)) \
                or (row + 1 <= dim - 1 and self._is_apple(row + 1, col)) \
                or (col - 1 >= 0 and self._is_apple(row, col - 1)) \
                or (col + 1 <= dim - 1 and self._is_apple(row, col + 1)):
            return False
        return True

    def _is_apple(self, row, col):
        return self._game_area.get_cel(row, col) == '.'


class SnakeException(Exception):

    def __init__(self, message):
        self._message = message

    @property
    def message(self):
        return self._message

    def __str__(self):
        return self._message


class SnakeGame:

    def __init__(self, settings):
        self._game_area = GameArea(settings)
        self._apple_strategy = ApplePlacementStrategy(self._game_area)
        self._set_init_state()

    @property
    def game_area(self):
        return self._game_area

    @property
    def direction(self):
        return self._direction

    def start(self):
        self._set_init_state()

    def _set_init_state(self):
        self._set_start_snake()
        self._place_start_apples()

    def _set_start_snake(self):
        self._direction = 1
        center = self._game_area.dim // 2
        self._set_head(center - 1, center)
        self._set_snake_segment(center, center)
        self._set_snake_segment(center + 1, center)

        self._head_row = center - 1
        self._head_col = center

    def _place_start_apples(self):
        self._apple_strategy.place_apples(self.game_area.apple_count)

    def _place_apples(self, count):
        self._apple_strategy.place_apples(count)

    def _set_head(self, row, column):
        self._set_cel(row, column, '*')

    def _set_snake_segment(self, row, column):
        self._set_cel(row, column, '+')

    def _set_apple(self, row, column):
        self._set_cel(row, column, '.')

    def _set_cel(self, row, column, symbol):
        self._game_area.set_cel(row, column, symbol)

    def move(self, squares=1):
        """
        :return: True is game ended, False otherwise
        """
        return self._move_ends_game(squares)

    def change_direction(self, new_direction):
        """
        :return: True is game ended, False otherwise
        """
        if new_direction not in [1, -1, 2, -2]:
            raise SnakeException("Invalid direction.")
        if self._is_180_change(new_direction):
            raise SnakeException("Cannot change direction to 180 degrees.")
        return False

    def _is_180_change(self, direction):
        return self._direction * -1 == direction

    def _move_ends_game(self, squares):
        dim = self._game_area.dim
        if (self._direction == 1 and self._head_row - squares < 0) \
                or (self._direction == -1 and self._head_row + squares >= dim) \
                or (self._direction == -2 and self._head_col - squares < 0) \
                or (self._direction == 2 and self._head_col + squares >= dim):
            return True
        if self._direction == 1:
            new_row = self._head_row - squares
            new_col = self._head_col
        elif self._direction == -1:
            new_row = self._head_row + squares
            new_col = self._head_col
        elif self._direction == 2:
            new_row = self._head_row
            new_col = self._head_col + squares
        else:
            new_row = self._head_row
            new_col = self._head_col - squares

        if self._game_area.get_cel(new_row, new_col) == "+":
            return True
        self._game_area.set_cel(self._head_row, self._head_col, None)
        self._head_row = new_row
        self._head_col = new_col
        self._game_area.set_cel(self._head_row, self._head_col, '*')

        return False

# game = SnakeGame(Settings())
# print(game.game_area)
