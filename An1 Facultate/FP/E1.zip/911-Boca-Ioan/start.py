from domain.board import SnakeField, SnakeError
from domain.snake import Snake
from services.game_service import GameService


def split_command(command):
    """
    Divide user command into command word and command params
    :param command: user command
    :return: command word, params
    """
    tokens = command.strip().split(' ', 1)
    # convert command word to lowercase
    tokens[0] = tokens[0].strip().lower()
    # Always returns a double-tuple
    return tokens[0], '' if len(tokens) == 1 else tokens[1].strip()


def run():
    try:
        f = open("settings.txt", "r")
        line = f.readline().strip()
        line = line.split(";")
        dim = int(line[0])
        apple_count = int(line[1])
    except IOError as e:
        """
            #Here we 'log' the error, and throw it to the outer layers
        """
        print("An error occured - " + str(e))
        raise e

    board = SnakeField(dim, dim)
    snake = Snake(dim)
    game_service = GameService(board, dim, snake, apple_count)
    game_service.place_snake()
    game_service.place_apples()
    print(board)

    command_dict = {'move': game_service.move_snake}
    command_dict_without = {'up': game_service.up_snake, 'right': game_service.right_snake,
                            'down': game_service.down_snake, 'left': game_service.left_snake}
    are_we_done_yet = False

    while not are_we_done_yet:
        command = input("command>")
        command_word, command_params = split_command(command)
        if command_word in command_dict:
            try:
                command_dict[command_word](command_params)
            except ValueError as ve:
                print(str(ve))
            except SnakeError as se:
                print(str(se))
        elif command_word in command_dict_without:
            try:
                command_dict_without[command_word]()
            except SnakeError as se:
                print(str(se))
        elif command == 'exit':
            are_we_done_yet = True
        else:
            print('bad command')
        print(board)

run()