class Snake:
    def __init__(self, dim):
        # [ row, col, dir ]
        self._head = [dim//2 - 1, dim//2, 'up']
        self._tail = [dim//2 + 1, dim//2, 'up']
        # all the snake ' + '
        self._snake_trail = [[dim//2 + 1, dim//2],[dim//2, dim//2]]
        
    @property
    def head(self):
        return self._head
    
    @property
    def tail(self):
        return self._tail

    @property
    def snake_trail(self):
        return self._snake_trail


