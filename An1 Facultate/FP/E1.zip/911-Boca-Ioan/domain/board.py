from texttable import Texttable


class SnakeError(Exception):
    def __init__(self, value):
        self._value = value

    def __str__(self):
        return self._value


class SnakeField:
    def __init__(self, rows, cols):
        """
        This function initializes the board for the game
        """
        self._rows = rows
        self._cols = cols
        self._data = [[" " for col in range(1, self._cols + 1)] for row in range(1, self._rows + 1)]

    @property
    def data(self):
        return self._data

    def __str__(self):
        t = Texttable()

        # Add each table row
        for row in range(self._rows):
            data = []
            for val in self._data[row][:]:
                data.append(val)
            t.add_row(data)
        return t.draw()

