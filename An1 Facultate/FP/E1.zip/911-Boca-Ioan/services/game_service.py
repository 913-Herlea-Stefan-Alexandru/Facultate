from random import randint
from domain.board import SnakeError

class GameError(Exception):
    def __init__(self, value):
        self._value = value

    def __str__(self):
        return self._value


class GameService:
    def __init__(self, board, dim, snake, apple_count):
        self._board = board.data
        self._dim = dim
        self._snake = snake
        self._apple_count = apple_count

    def place_snake(self):
        head = self._snake.head
        head_x = head[0]
        head_y = head[1]
        self._board[head_x][head_y] = '*'

        trail = self._snake.snake_trail
        for square in trail:
            x = square[0]
            y = square[1]
            self._board[x][y] = '+'

    @staticmethod
    def square_is_on_board(dim, x, y):
        if x < 0 or x >= dim:
            return False
        if y < 0 or y >= dim:
            return False
        return True

    def place_apples(self):
        apples = 0
        while apples <= self._apple_count:
            x = randint(1, self._dim-2)
            y = randint(1, self._dim-2)
            if self._board[x][y] == " ":
                if self._board[x-1][y] != "." and self._board[x+1][y] != '.' and self._board[x][y-1] != "." and self._board[x][y+1] != ".":
                    self._board[x][y] = '.'
                    apples += 1

    def place_one_apple(self):
        apple_placed = False
        while not apple_placed:
            x = randint(1, self._dim - 2)
            y = randint(1, self._dim - 2)
            if self._board[x][y] == " ":
                if self._board[x - 1][y] != "." and self._board[x + 1][y] != '.' and self._board[x][y - 1] != "." and \
                        self._board[x][y + 1] != ".":
                    self._board[x][y] = '.'
                    apple_placed = True

    def move_snake(self, steps):
        if steps == '':
            steps = 1
        else:
            steps = int(steps)
        for index in range(1, steps + 1):
            head_x = self._snake.head[0]
            head_y = self._snake.head[1]
            dir = self._snake.head[2]

            if dir == 'up':
                if head_x == 0 or self._board[head_x-1][head_y] == '+':
                    raise GameError("Game Over")
                else:
                    if self._board[head_x-1][head_y] == '.':
                        self._board[head_x][head_y] = '+'
                        self._snake.snake_trail.append([head_x, head_y])
                        GameService.place_one_apple(self)
                    else:
                        self._board[head_x][head_y] = '+'
                        tail_coords = self._snake.snake_trail[0]
                        self._board[tail_coords[0]][tail_coords[1]] = " "
                        self._snake.snake_trail.pop(0)
                        self._snake.snake_trail.append([head_x, head_y])

                    head_x -= 1
                    self._board[head_x][head_y] = '*'
                    self._snake.head[0] = head_x
                    self._snake.head[1] = head_y
            if dir == 'down':
                if head_x == self._dim - 1 or self._board[head_x+1][head_y] == '+':
                    raise GameError("Game Over")
                else:
                    if self._board[head_x+1][head_y] == '.':
                        self._board[head_x][head_y] = '+'
                        self._snake.snake_trail.append([head_x, head_y])
                        GameService.place_one_apple(self)
                    else:
                        self._board[head_x][head_y] = '+'
                        tail_coords = self._snake.snake_trail[0]
                        self._board[tail_coords[0]][tail_coords[1]] = " "
                        self._snake.snake_trail.pop(0)
                        self._snake.snake_trail.append([head_x, head_y])

                    head_x += 1
                    self._board[head_x][head_y] = '*'
                    self._snake.head[0] = head_x
                    self._snake.head[1] = head_y
            if dir == 'right':
                if head_y == self._dim - 1 or self._board[head_x][head_y+1] == '+':
                    raise GameError("Game Over")
                else:
                    if self._board[head_x][head_y+1] == '.':
                        self._board[head_x][head_y] = '+'
                        self._snake.snake_trail.append([head_x, head_y])
                        GameService.place_one_apple(self)
                    else:
                        self._board[head_x][head_y] = '+'
                        tail_coords = self._snake.snake_trail[0]
                        self._board[tail_coords[0]][tail_coords[1]] = " "
                        self._snake.snake_trail.pop(0)
                        self._snake.snake_trail.append([head_x, head_y])
                    head_y += 1
                    self._board[head_x][head_y] = '*'
                    self._snake.head[0] = head_x
                    self._snake.head[1] = head_y
            if dir == 'left':
                if head_y == 0 or self._board[head_x][head_y-1] == '+':
                    raise GameError("Game Over")
                else:
                    if self._board[head_x][head_y-1] == '.':
                        self._board[head_x][head_y] = '+'
                        self._snake.snake_trail.append([head_x, head_y])
                        GameService.place_one_apple(self)
                    else:
                        self._board[head_x][head_y] = '+'
                        tail_coords = self._snake.snake_trail[0]
                        self._board[tail_coords[0]][tail_coords[1]] = " "
                        self._snake.snake_trail.pop(0)
                        self._snake.snake_trail.append([head_x, head_y])
                    head_y -= 1
                    self._board[head_x][head_y] = '*'
                    self._snake.head[0] = head_x
                    self._snake.head[1] = head_y

    def up_snake(self):
        head_x = self._snake.head[0]
        head_y = self._snake.head[1]
        snake_dir = self._snake.head[2]
        if snake_dir == 'down':
            raise SnakeError("Can't change direction 180 degrees.")
        if snake_dir != 'up':
            if head_x == 0 or self._board[head_x - 1][head_y] == '+':
                raise GameError("Game Over")
            else:
                if self._board[head_x - 1][head_y] == '.':
                    self._board[head_x][head_y] = '+'
                    self._snake.snake_trail.append([head_x, head_y])
                    GameService.place_one_apple(self)
                else:
                    self._board[head_x][head_y] = '+'
                    tail_coords = self._snake.snake_trail[0]
                    self._board[tail_coords[0]][tail_coords[1]] = " "
                    self._snake.snake_trail.pop(0)
                    self._snake.snake_trail.append([head_x, head_y])

                head_x -= 1
                self._board[head_x][head_y] = '*'
                self._snake.head[0] = head_x
                self._snake.head[1] = head_y
                self._snake.head[2] = 'up'

    def right_snake(self):
        head_x = self._snake.head[0]
        head_y = self._snake.head[1]
        snake_dir = self._snake.head[2]
        if snake_dir == 'left':
            raise SnakeError("Can't change direction 180 degrees.")
        if snake_dir != 'right':
            if head_y == self._dim - 1 or self._board[head_x][head_y + 1] == '+':
                raise GameError("Game Over")
            else:
                if self._board[head_x][head_y + 1] == '.':
                    self._board[head_x][head_y] = '+'
                    self._snake.snake_trail.append([head_x, head_y])
                    GameService.place_one_apple(self)
                else:
                    self._board[head_x][head_y] = '+'
                    tail_coords = self._snake.snake_trail[0]
                    self._board[tail_coords[0]][tail_coords[1]] = " "
                    self._snake.snake_trail.pop(0)
                    self._snake.snake_trail.append([head_x, head_y])
                head_y += 1
                self._board[head_x][head_y] = '*'
                self._snake.head[0] = head_x
                self._snake.head[1] = head_y
                self._snake.head[2] = 'right'

    def down_snake(self):
        head_x = self._snake.head[0]
        head_y = self._snake.head[1]
        snake_dir = self._snake.head[2]
        if snake_dir == 'up':
            raise SnakeError("Can't change direction 180 degrees.")
        if snake_dir != 'down':
            if head_x == self._dim -1 or self._board[head_x + 1][head_y] == '+':
                raise GameError("Game Over")
            else:
                if self._board[head_x + 1][head_y] == '.':
                    self._board[head_x][head_y] = '+'
                    self._snake.snake_trail.append([head_x, head_y])
                    GameService.place_one_apple(self)
                else:
                    self._board[head_x][head_y] = '+'
                    tail_coords = self._snake.snake_trail[0]
                    self._board[tail_coords[0]][tail_coords[1]] = " "
                    self._snake.snake_trail.pop(0)
                    self._snake.snake_trail.append([head_x, head_y])
                head_x += 1
                self._board[head_x][head_y] = '*'
                self._snake.head[0] = head_x
                self._snake.head[1] = head_y
                self._snake.head[2] = 'down'

    def left_snake(self):
        head_x = self._snake.head[0]
        head_y = self._snake.head[1]
        snake_dir = self._snake.head[2]
        if snake_dir == 'right':
            raise SnakeError("Can't change direction 180 degrees.")
        if snake_dir != 'left':
            if head_y == 0 or self._board[head_x][head_y - 1] == '+':
                raise GameError("Game Over")
            else:
                if self._board[head_x][head_y - 1] == '.':
                    self._board[head_x][head_y] = '+'
                    self._snake.snake_trail.append([head_x, head_y])
                    GameService.place_one_apple(self)
                else:
                    self._board[head_x][head_y] = '+'
                    tail_coords = self._snake.snake_trail[0]
                    self._board[tail_coords[0]][tail_coords[1]] = " "
                    self._snake.snake_trail.pop(0)
                    self._snake.snake_trail.append([head_x, head_y])
                head_y -= 1
                self._board[head_x][head_y] = '*'
                self._snake.head[0] = head_x
                self._snake.head[1] = head_y
                self._snake.head[2] = 'left'
