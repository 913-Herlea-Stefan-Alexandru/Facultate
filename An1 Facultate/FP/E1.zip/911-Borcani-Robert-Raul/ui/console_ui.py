"""
This module manages the console UI.
"""
from service.game_service import GameServiceError


class ConsoleUI:
    def __init__(self, game_service):
        """
        Initializes the UI and prints the initial board.
        :param game_service: A GameService object required for the game
        """
        self._game_service = game_service

    def start(self):
        """
        Starts the game.
        :return: -
        """
        self.print_board()
        game_over = False
        directions_dictionary = {'up': self._game_service.change_direction_up,
                                 'down': self._game_service.change_direction_down,
                                 'left': self._game_service.change_direction_left,
                                 'right': self._game_service.change_direction_right}

        while not game_over:
            command = input("Enter your command: ")
            try:
                command_text, command_parameters = command.strip().split(' ', 1)
            except ValueError:
                command_text = command.strip()
                command_parameters = ''

            if command_text == 'move':
                game_over = self.move_command_ui(command_parameters)
            elif command_text in directions_dictionary:
                try:
                    directions_dictionary[command_text]()
                    game_over = self.move_command_ui(command_parameters)
                except GameServiceError as game_service_error:
                    print(str(game_service_error))
            else:
                print("Invalid command!")

    def move_command_ui(self, command_parameters):
        """
        Processes a move command and checks if the game is over after the move
        :param command_parameters: The parameters of the command
        :return: True if the game is over, False otherwise
        """
        try:
            move_count = int(command_parameters)
        except ValueError:
            move_count = 1
        result = self._game_service.move_snake(move_count)
        if result is not None:
            print(result)
            game_over = True
        else:
            self.print_board()
            game_over = False
        return game_over

    def print_board(self):
        """
        Prints the board on the screen
        :return: -
        """
        print(self._game_service.get_string_board())
