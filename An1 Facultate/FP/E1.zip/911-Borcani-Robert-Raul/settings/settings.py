"""
Module for managing settings of the game.
"""


class SettingsError(Exception):
    def __init__(self, message):
        self._message = message

    def __str__(self):
        return self._message


class Settings:
    """
    A class that loads data from settings.properties
    and gives information about settings.
    """

    def __init__(self):
        """
        Once created, an instance will automatically load
        the settings for the program
        """
        self.settings_dict = {}
        self.load_settings()

    def load_settings(self):
        """
        Loads the settings from settings.properties.
        """
        file = open('../settings.properties', 'rt')
        lines = file.readlines()
        file.close()

        self.settings_dict = {}
        for line in lines:
            items = line.split('=')
            if len(items) != 2:
                raise SettingsError('Invalid settings!')
            items[0] = items[0].strip('\n "')
            items[1] = items[1].strip('\n "')
            self.settings_dict[items[0]] = items[1]

    def get_setting(self, setting):
        if setting in self.settings_dict:
            return self.settings_dict[setting]
        raise SettingsError('No such setting found!')
