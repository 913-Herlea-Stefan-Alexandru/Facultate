"""
This module contains the necessary classes that describe a cell on the board
"""
import enum


class CellState(enum.Enum):
    FREE = 0
    APPLE = 1
    BODY_SEGMENT = 2
    HEAD = 3


class Cell:
    def __init__(self):
        """
        Creates a new free square
        """
        self._state = CellState.FREE

    def change_state(self, new_state):
        """
        Changes the state of the square to given new_state.
        :param new_state: A SquareState.
        :return: -
        """
        self._state = new_state

    def get_state(self):
        """
        Gets the state of the square.
        :return: A SquareState object.
        """
        return self._state

    def __str__(self):
        if self._state == CellState.FREE:
            return ' '
        if self._state == CellState.APPLE:
            return '.'
        if self._state == CellState.BODY_SEGMENT:
            return '+'
        if self._state == CellState.HEAD:
            return '*'
