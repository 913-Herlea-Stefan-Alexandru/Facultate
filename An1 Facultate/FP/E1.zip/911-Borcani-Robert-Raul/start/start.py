from board.board import Board
from service.game_service import GameService
from settings.settings import Settings
from ui.console_ui import ConsoleUI


class Game:
    """
    This class contains functionalities regarding the settings and the start of the game.
    """
    def __init__(self):
        settings = Settings()

        board_dimension = int(settings.get_setting('board_dimension'))
        apple_count = int(settings.get_setting('apple_count'))

        self._board = Board(board_dimension)
        self._game_service = GameService(self._board, apple_count)
        self._ui = ConsoleUI(self._game_service)

    def start_game(self):
        self._ui.start()


game = Game()
game.start_game()
