"""
This module contains basic functionalities that are related to a board
"""
import texttable

from domain.cell import Cell


class BoardError(Exception):
    def __init__(self, msg):
        self._msg = msg

    def __str__(self):
        return self._msg


class Board:
    """
    Describes a board for the Snake game
    """
    def __init__(self, board_dimension):
        """
        Creates a new instance of a n*m Board, with all squares empty
        :param number_of_rows: The number of rows of the board
        :param number_of_columns: The number of columns of the board
        """
        self._board = []
        self._board_dimension = board_dimension

        for row in range(board_dimension):
            self._board.append([])
            for cols in range(board_dimension):
                self._board[-1].append(Cell())

    def modify_cell_state(self, row, col, state):
        """
        Modifies the state of the cell at [row, col]
        :param row: The row where the cell is
        :param col: The column where the cell is
        :param state: The new state of the cell
        :return: -
        Raises BoardError if square [row, col] does not exist
        """
        if row < 0 or row >= self._board_dimension or col < 0 or col >= self._board_dimension:
            raise BoardError("Invalid coordinates")
        self._board[row][col].change_state(state)

    def get_cell_state(self, row, col):
        """
        Gets the current state of a cell
        :param row: The row of the cell
        :param col: The column of the cell
        :return: A SquareState object describing the state of the cell at [row, col]
        Raises BoardError if square [row, col] does not exist
        """
        if row < 0 or row >= self._board_dimension or col < 0 or col >= self._board_dimension:
            raise BoardError("Invalid coordinates")
        return self._board[row][col].get_state()

    def get_board_dimension(self):
        """
        Gets the board dimension.
        :return: The dimension of the board.
        """
        return self._board_dimension

    def __str__(self):
        table = texttable.Texttable()

        for row in range(self._board_dimension):
            current_row = []
            for column in range(self._board_dimension):
                current_row.append(str(self._board[row][column]))
            table.add_row(current_row)

        return table.draw()
