"""
This module contains code related to functionalities of the game.
"""
import enum
from random import randrange

from domain.cell import CellState


class GameServiceError(Exception):
    def __init__(self, message):
        self._message = message

    def __str__(self):
        return self._message


class SnakeDirection(enum.Enum):
    UP = 0
    DOWN = 1
    LEFT = 2
    RIGHT = 3


class GameService:
    def __init__(self, board, apple_count):
        """
        Initializes the game service: places the snake and the apples on the board.
        :param board: A Board object
        :param apple_count: The number of apples that will be placed on the board
        """
        self._board = board
        self._board_dimension = self._board.get_board_dimension()
        self._apple_count = apple_count
        self._body_positions = []
        self._head_position = None
        self._place_snake()
        self._snake_direction = SnakeDirection.UP
        self._place_apples()

    def move_snake(self, number_of_positions):
        """
        Moves the snake in the current direction number_of_position positions.
        :param number_of_positions: The number of positions for the snake to move
        :return: If after some of these moves, the game is over, returns a message regarding how and why the game
                 ended. Otherwise, returns None
        """
        for move_index in range(number_of_positions):
            try:
                self._move_one_position()
            except GameServiceError as gs:
                return "Game over! " + str(gs)
        return None

    def change_direction_up(self):
        """
        Changes the direction up. The previous direction must not be down.
        :return:
        Raises GameServiceError if the previous direction was down
        """
        if self._snake_direction == SnakeDirection.DOWN:
            raise GameServiceError("Can't change from down to up!")
        if self._snake_direction == SnakeDirection.UP:
            raise GameServiceError("Snake is already going up!")
        self._snake_direction = SnakeDirection.UP

    def change_direction_down(self):
        """
        Changes the direction down. The previous direction must not be up.
        :return:
        Raises GameServiceError if the previous direction was up
        """
        if self._snake_direction == SnakeDirection.UP:
            raise GameServiceError("Can't change from up to down!")
        if self._snake_direction == SnakeDirection.DOWN:
            raise GameServiceError("Snake is already going down!")
        self._snake_direction = SnakeDirection.DOWN

    def change_direction_left(self):
        """
        Changes the direction left. The previous direction must not be right.
        :return:
        Raises GameServiceError if the previous direction was right
        """
        if self._snake_direction == SnakeDirection.RIGHT:
            raise GameServiceError("Can't change from right to left!")
        if self._snake_direction == SnakeDirection.LEFT:
            raise GameServiceError("Snake is already going left!")
        self._snake_direction = SnakeDirection.LEFT

    def change_direction_right(self):
        """
        Changes the direction right. The previous direction must not be left.
        :return:
        Raises GameServiceError if the previous direction was left
        """
        if self._snake_direction == SnakeDirection.LEFT:
            raise GameServiceError("Can't change from left to right!")
        if self._snake_direction == SnakeDirection.RIGHT:
            raise GameServiceError("Snake is already going right!")
        self._snake_direction = SnakeDirection.RIGHT

    def _move_one_position(self):
        """
        Moves one position in the current direction.
        :return: -
        Raises GameServiceError if the game is over.
        """
        previous_head_row = self._head_position[0]
        previous_head_column = self._head_position[1]
        next_snake_row, next_snake_column = self._get_next_head_position()
        last_body_segment_row = self._body_positions[0][0]
        last_body_segment_column = self._body_positions[0][1]

        if self._board.get_cell_state(next_snake_row, next_snake_column) == CellState.FREE\
                or next_snake_row == last_body_segment_row and next_snake_column == last_body_segment_column:
            # Apply changes to the board
            self._board.modify_cell_state(last_body_segment_row, last_body_segment_column, CellState.FREE)
            self._board.modify_cell_state(next_snake_row, next_snake_column, CellState.HEAD)
            self._board.modify_cell_state(previous_head_row, previous_head_column, CellState.BODY_SEGMENT)

            # Update self._body_positions and self._head_position
            self._body_positions.append(self._head_position)
            self._body_positions = self._body_positions[1:]         # Delete the last snake segment
            self._head_position = (next_snake_row, next_snake_column)
        elif self._board.get_cell_state(next_snake_row, next_snake_column) == CellState.APPLE:
            # Apply changes to the board
            self._board.modify_cell_state(next_snake_row, next_snake_column, CellState.HEAD)
            self._board.modify_cell_state(previous_head_row, previous_head_column, CellState.BODY_SEGMENT)

            # Update self._body_positions and self._head_position
            self._body_positions.append(self._head_position)
            self._head_position = (next_snake_row, next_snake_column)

            # Add a new apple on the board
            self._place_one_apple()
        else:       # in this case, it's game over because the snake hit itself
            raise GameServiceError("The snake hit itself!")

    def _get_next_head_position(self):
        """
        Gets the position of the head for the next move
        :return: A tuple containing the position of the head after 1 move
        Raises GameServiceError if snake hits a wall
        """
        row = self._head_position[0]
        column = self._head_position[1]
        wall = ''       # Which wall the snake might hit
        if self._snake_direction == SnakeDirection.UP:
            row -= 1
            wall = 'top'
        if self._snake_direction == SnakeDirection.DOWN:
            row += 1
            wall = 'bottom'
        if self._snake_direction == SnakeDirection.LEFT:
            column -= 1
            wall = 'left'
        if self._snake_direction == SnakeDirection.RIGHT:
            column += 1
            wall = 'right'

        if self._out_of_board(row, column):
            raise GameServiceError(f"Snake hit the {wall} wall")

        return row, column

    def _place_snake(self):
        """
        Places the snake on the board
        :return: -
        """
        column = self._board_dimension // 2
        head_row = self._board_dimension // 2 - 1

        # Place the head
        self._board.modify_cell_state(head_row, column, CellState.HEAD)
        self._head_position = (head_row, column)

        # On the next 2 rows, place 2 snake body segments
        self._board.modify_cell_state(head_row + 1, column, CellState.BODY_SEGMENT)
        self._board.modify_cell_state(head_row + 2, column, CellState.BODY_SEGMENT)
        self._body_positions.append((head_row + 2, column))
        self._body_positions.append((head_row + 1, column))

    def _place_apples(self):
        """
        Places all the apples on the board
        :return: -
        """
        for apple_index in range(self._apple_count):
            self._place_one_apple()

    def _place_one_apple(self):
        """
        Randomly places one apple one the board if that is possible.
        :return: -
        """
        if not self._space_for_new_apple():
            return

        apple_placed = False
        while not apple_placed:
            row = randrange(0, self._board_dimension)
            column = randrange(0, self._board_dimension)
            if self._board.get_cell_state(row, column) != CellState.FREE:
                continue
            if self._adjacent_apple(row, column):
                continue

            self._board.modify_cell_state(row, column, CellState.APPLE)
            apple_placed = True

    def _space_for_new_apple(self):
        """
        Checks if there is space left on the board to place new apples.
        :return: True if there exists at least one cell where an apple can be placed.
        """
        for row in range(self._board_dimension):
            for column in range(self._board_dimension):
                if self._board.get_cell_state(row, column) != CellState.FREE:
                    continue
                if self._adjacent_apple(row, column):
                    continue
                return True
        return False

    def _adjacent_apple(self, row, column):
        """
        Checks if there is an adjacent apple relative to position [row, column]
        :param row: The row on the board
        :param column: The column on the board
        :return: True if any adjacent apple is found
        """
        # Check for apples in all of the four directions (UP, DOWN, LEFT, RIGHT)
        if not self._out_of_board(row - 1, column) and self._board.get_cell_state(row - 1, column) == CellState.APPLE:
            return True
        if not self._out_of_board(row + 1, column) and self._board.get_cell_state(row + 1, column) == CellState.APPLE:
            return True
        if not self._out_of_board(row, column - 1) and self._board.get_cell_state(row, column - 1) == CellState.APPLE:
            return True
        if not self._out_of_board(row, column + 1) and self._board.get_cell_state(row, column + 1) == CellState.APPLE:
            return True
        return False

    def _out_of_board(self, row, column):
        """
        Checks if position given by [row, column] is out of the board
        :param row: The row on the board
        :param column: The column on the board
        :return: True if the position if out of board, False otherwise
        """
        if row < 0 or row >= self._board_dimension:
            return True
        if column < 0 or column >= self._board_dimension:
            return True
        return False

    def get_string_board(self):
        """
        Gets a string representing the board
        :return: A string representing the board
        """
        return str(self._board)
