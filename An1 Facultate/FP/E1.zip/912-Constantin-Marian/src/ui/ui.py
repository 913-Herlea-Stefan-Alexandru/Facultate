class UIException(Exception):
    pass


class UI:
    def __init__(self, game):
        self._game = game

    def process_command(self, cmd_name, cmd_params=''):
        cmd_name = cmd_name.strip()
        cmd_params = cmd_params.strip()
        if cmd_params == '':
            if cmd_name.lower() in ["up", "down", "left", "right"]:
                self._game.change_direction(cmd_name.lower())
            elif cmd_name.lower() == "move":
                self._game.move(1)
            else:
                print("Invalid command!")
        else:
            if cmd_name.lower() == "move":
                try:
                    cmd_params = int(cmd_params)
                except Exception:
                    raise UIException("The parameter cannot be converted to an integer value!")
                self._game.move(cmd_params)
            else:
                print("Invalid command!")

    def start(self):
        done = False
        while not done:
            print(self._game)
            cmd = input("Command:")
            try:
                cmd = cmd.strip().split()
                if len(cmd) > 2:
                    print("Too many parameters!")
                elif len(cmd) == 0:
                    print("Invalid command!")
                else:
                    self.process_command(*cmd)
            except Exception as err:
                print(str(err))
            if self._game.is_game_over() is True:
                done = True
                print(self._game)
                print("Game over!")
