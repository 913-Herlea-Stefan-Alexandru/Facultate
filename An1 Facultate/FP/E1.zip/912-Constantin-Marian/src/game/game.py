import random


class GameException(Exception):
    pass


class Game:
    def __init__(self, board, apple_count):
        self._board = board
        self._snake = []
        self._snake_dir = "up"
        self._game_over = False
        self.generate_snake()
        self.generate_apples(apple_count)

    def generate_snake(self):
        middle = len(self._board) // 2
        self._board.place(middle, middle, '+')
        self._board.place(middle + 1, middle, '+')
        self._board.place(middle - 1, middle, '*')
        self._snake = [[middle + 1, middle], [middle, middle], [middle - 1, middle]]

    def generate_apples(self, apple_count):
        empty = self._board.get_empty()
        random.shuffle(empty)
        placed = 0
        for i in range(len(empty)):
            if placed == apple_count:
                return
            valid = True
            neighbours = self._board.get_neighbours(*empty[i])
            for nb in neighbours:
                if self._board.get_symbol(*nb) == '.':
                    valid = False
                    break
            if valid is False:
                continue
            self._board.place(empty[i][0], empty[i][1], '.')
            placed += 1

    def simple_move(self):
        apple = 0
        direction = [0, 0]
        if self._snake_dir == "up":
            direction = [-1, 0]
        elif self._snake_dir == "down":
            direction = [1, 0]
        elif self._snake_dir == "left":
            direction = [0, -1]
        elif self._snake_dir == "right":
            direction = [0, 1]

        next_square = [self._snake[-1][0] + direction[0], self._snake[-1][1] + direction[1]]

        if self._board.in_bounds(*next_square) is False:
            return False, apple

        symbol = self._board.get_symbol(*next_square)

        if symbol == ' ':
            self._board.place(*next_square, '*')
            self._board.place(*self._snake[-1], '+')
            self._snake.append(next_square)
            self._board.place(*self._snake[0], ' ')
            self._snake = self._snake[1:]
        elif symbol == '.':
            self._board.place(*next_square, '*')
            self._board.place(*self._snake[-1], '+')
            self._snake.append(next_square)
            apple = 1
        elif symbol == '+':
            if next_square[0] == self._snake[0][0] and next_square[1] == self._snake[0][1]:
                self._board.place(*next_square, '*')
                self._board.place(*self._snake[-1], '+')
                self._snake.append(next_square)
                self._snake = self._snake[1:]
            else:
                return False, apple
        else:
            return False, apple
        return True, apple

    def move(self, steps):
        apples_to_generate = 0
        for i in range(steps):
            valid_move, apple = self.simple_move()
            self._game_over = not valid_move
            if self._game_over is True:
                return
            apples_to_generate += apple
        self.generate_apples(apples_to_generate)

    def is_game_over(self):
        return self._game_over

    def change_direction(self, new_direction):
        if self._snake_dir == "left" and new_direction == "right":
            raise GameException("The snake cannot make a 180 degree turn!")
        if self._snake_dir == "right" and new_direction == "left":
            raise GameException("The snake cannot make a 180 degree turn!")
        if self._snake_dir == "up" and new_direction == "down":
            raise GameException("The snake cannot make a 180 degree turn!")
        if self._snake_dir == "down" and new_direction == "up":
            raise GameException("The snake cannot make a 180 degree turn!")

        if self._snake_dir == new_direction:
            return

        self._snake_dir = new_direction
        self.move(1)

    def __str__(self):
        return str(self._board)
