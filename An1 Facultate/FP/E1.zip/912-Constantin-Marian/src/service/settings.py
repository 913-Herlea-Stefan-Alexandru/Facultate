class Settings:
    def __init__(self):
        self._dict = {}

    def parse(self, text_file):
        f = open(text_file)
        lines = f.readlines()
        f.close()

        for line in lines:
            line = line.split('=')
            self._dict[line[0].strip()] = line[1].strip()

    def get(self, key):
        if key not in self._dict:
            return None

        return self._dict[key]

    def __getitem__(self, item):
        return self.get(item)
