from texttable import Texttable


class Board:
    def __init__(self, dim):
        self._data = [[' ' for j in range(dim)] for i in range(dim)]
        self._dim = dim

    def is_empty(self, row, col):
        if self._data[row][col] == ' ':
            return True
        return False

    def get_empty(self):
        empty = []
        for i in range(self._dim):
            for j in range(self._dim):
                if self.is_empty(i, j) is True:
                    empty.append((i, j))
        return empty

    def place(self, row, col, symbol):
        self._data[row][col] = symbol

    def get_symbol(self, row, col):
        return self._data[row][col]

    def __len__(self):
        return self._dim

    def __str__(self):
        table = Texttable()
        for i in range(self._dim):
            row = []
            for symbol in self._data[i]:
                row.append(symbol)

            table.add_row(row)

        return table.draw()

    def in_bounds(self, row, col):
        if row < 0 or col < 0 or row >= self._dim or col >= self._dim:
            return False
        return True

    def get_neighbours(self, row, col):
        neighbours = []
        if self.in_bounds(row + 1, col):
            neighbours.append([row + 1, col])
        if self.in_bounds(row - 1, col):
            neighbours.append([row - 1, col])
        if self.in_bounds(row, col + 1):
            neighbours.append([row, col + 1])
        if self.in_bounds(row, col - 1):
            neighbours.append([row, col - 1])

        return neighbours
