from board.board import Board
from game.game import Game
from service.settings import Settings
from ui.ui import UI


if __name__ == "__main__":
    settings = Settings()
    settings.parse("settings.properties")
    board = Board(int(settings["DIM"]))
    game = Game(board, int(settings["apple_count"]))
    ui = UI(game)
    ui.start()
