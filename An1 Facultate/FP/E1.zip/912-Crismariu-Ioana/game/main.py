from game.ui import Console
from game.strategy import Game
game = Game("settings.properties")
console = Console(game)
console.console()