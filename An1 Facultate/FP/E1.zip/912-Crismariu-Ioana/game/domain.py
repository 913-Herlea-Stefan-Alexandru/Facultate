from texttable import *
class Board:
    def __init__(self, dim):
        self._dim = dim
        self._data = [[None for i in range(self._dim)] for j in range(self._dim)]

    def move(self, x, y, symbol):
        self._data[x][y] = symbol

    def free(self,x, y):
        return self._data[x][y] == None

    def get_row(self, x):
        return self._data[x]

    def get_col(self, y):
        return [row[y] for row in self._data]

    def get_free_spots(self):
        free_spots = []
        for x in range(1,self._dim-1):
            for y in range(1,self._dim-1):
                if self.free(x,y):
                    free_spots.append((x,y))
        return free_spots

    def get_snake_head(self):
        for i in range(self._dim):
            for j in range(self._dim):
                if self._data[i][j] == '*':
                    return (i,j)

    def get_snake_lenght(self):
        lenght = 0
        for i in range(self._dim):
            for j in range(self._dim):
                if self._data[i][j] == '+':
                    lenght += 1
        return lenght

    def is_apple(self,x, y):
        return self._data[x][y] == '.'



    def free_adjacent_squares(self, x, y):
        return self._data[x+1][y] == None and self._data[x-1][y] == None and self._data[x][y+1] == None and self._data[x][y-1] == None



    @property
    def dim(self):
        return int(self._dim)

    def __str__(self):
        t = Texttable()
        header = [' ']
        for h in range(self._dim):
            header.append(chr(65 + h))
        t.header(header)
        for row in range(self._dim):
            data = []
            for val in self._data[row]:
                if val == None:
                    data.append(' ')
                elif val == '*':
                    data.append('*')
                elif val == '+':
                    data.append('+')
                elif val == '.':
                    data.append('.')
            t.add_row([row] + data)
        return t.draw()
