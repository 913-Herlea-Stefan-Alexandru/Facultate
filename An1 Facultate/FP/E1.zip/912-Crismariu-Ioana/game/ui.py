from game.strategy import Game
class Console:
    def __init__(self, game):
        self._game = game

    def console(self):
        finished = False
        self._game.start()
        try:
            while not finished:
                    print(self._game.board)
                    inp = input("command>")
                    command_word, command_params = self.split_command(inp)
                    if command_word == 'move':
                        self.move_ui(command_params)
                    elif command_word == 'up' or command_word == 'right' or command_word == 'left' or command_word == 'down':
                        self.change_dir_ui(command_word)
                    elif command_word == 'exit':
                        finished = True
                    else:
                        print("Bad command!")
        except Exception as e:
            print(str(e))


    def split_command(self, inp):
        command = inp.strip().lower().split(' ')
        if len(command) == 2:
            return command[0].strip(), int(command[1].strip())
        elif len(command) ==1:
            return command[0].strip(), ' '

    def move_ui(self, command_params):
        if command_params == ' ':
            self._game.move_forward()
        else:
            self._game.move_multiple(command_params)


    def change_dir_ui(self, command_word):
        self._game.change_dir(command_word)

