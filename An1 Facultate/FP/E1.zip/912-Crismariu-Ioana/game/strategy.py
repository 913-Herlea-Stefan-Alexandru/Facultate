import random
from game.domain import Board
class Game:
    def __init__(self, file_name):
        self._file_name = file_name
        self._dimension, self._apples = self._load()
        self._board = Board(int(self._dimension))
        self._direction = 'up'


    def _load(self):
        f = open(self._file_name, 'rt')
        lines = f.readlines()
        f.close()
        dictionary = {}
        for line in lines:
            line = line.split('=')
            dictionary[line[0].strip()] = line[1].strip().strip('\n')
        if len(dictionary) < 2:
            return None, None
        return dictionary['dim'], dictionary['apple_count']

    @property
    def board(self):
        return self._board

    def start(self):
        middle = self._board.dim // 2
        self._board.move(middle, middle, '+')
        self._board.move(middle+1, middle, '+')
        self._board.move(middle-1, middle, '*')
        self.place_apples(int(self._apples))


    def place_apples(self, nr):
        while nr > 0:
            places_to_choose_from = self._board.get_free_spots()
            position = random.choice(places_to_choose_from)
            if self._board.free_adjacent_squares(position[0], position[1]):
                self._board.move(position[0], position[1], '.')
                nr = nr-1

    def move_forward(self):
        self._dimension = int(self._dimension)
        head = self._board.get_snake_head()
        if head[0] == 0 or head[1] == 0 or head[0] == self._dimension - 1 or head[1] == self._dimension - 1:
            raise ValueError("Game Over!")
        lenght = self._board.get_snake_lenght()
        if self._board.is_apple(head[0]-1, head[1]):
            self.place_apples(1)
            lenght += 1
        self._board.move(head[0] - 1, head[1], '*')
        for i in range(0, lenght):
            self._board.move(head[0] + i, head[1], "+")
        self._board.move(head[0] + lenght, head[1], None)


    def move_multiple(self, command_params):
        nr = int(command_params)
        while nr > 0:
            self.move_forward()
            nr -= 1

    def change_dir(self, direction):
        self._dimension = int(self._dimension)
        self.move_forward()
        head = self._board.get_snake_head()
        if direction == 'left':
            self._board.move(head[0], head[1], None)
            self._board.move(head[0]+1, head[1]+1, "*")
        elif direction == 'right':
            self._board.move(head[0], head[1], None)
            self._board.move(head[0] + 1, head[1] - 1, "*")










