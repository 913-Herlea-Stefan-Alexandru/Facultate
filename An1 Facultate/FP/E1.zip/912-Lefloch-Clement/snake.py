class snake:
    def __init__(self):
        self.size=2
        self.positions=[]
        self.orientation= "up"