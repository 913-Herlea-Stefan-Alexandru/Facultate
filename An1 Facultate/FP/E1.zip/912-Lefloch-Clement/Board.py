from random import randrange

from texttable import Texttable

from snake import snake


class Board:

    def __init__(self,file_name):
        self._snake=snake()
        self._file_name=file_name
        self.load_file()
        self._apples=0
        self._dim=1
        self.load_file()
        self._data=[]
        basic_row=[]
        n=self._dim
        while n>0:
            basic_row.append(0)
            n-=1
        n = self._dim
        while n > 0:
            self._data.append(basic_row[:])
            n-=1
        self.place_snake()
        self.place_apple()

    @property
    def snake(self):
        return self._snake

    def __str__(self):
        t=Texttable()
        header=[]
        for i in range (self._dim):
            header.append('#')
        t.header(header)
        for row in range(self._dim):
            row_data = []

            for index in self._data[row]:
                if index == 0:
                    row_data.append(' ')
                elif index == 1:
                    row_data.append('.')
                elif index == 2:
                    row_data.append('*')
                elif index == 3:
                    row_data.append('+')
            t.add_row(row_data)
        return t.draw()

    def load_file(self):
        try:
            f = open(self._file_name, "r")
            line = f.readline().strip()

            while len(line) > 0:
                line = line.split(":")
                if line[0]=="apples":
                    self._apples=int(line[1])

                if line[0]=="dimension":
                    self._dim=int(line[1])

                line = f.readline().strip()
            f.close()
        except IOError as e:
            """
                Here we 'log' the error, and throw it to the outer layers 
            """
            raise e
    @property
    def dim(self):
        return self._dim

    def place_board(self,array,value):
        self._data[array[0]][array[1]]=value

    def place_snake(self):
        self._snake.positions=[[self.dim // 2 - 1, self.dim // 2],[self.dim//2,self.dim//2],[self.dim//2+1,self.dim//2]]
        #(self._snake.positions)
        self.place_board(self._snake.positions[0],2)
        for i in range(1,len(self._snake.positions)):
            self.place_board(self._snake.positions[i],3)

    def place_apple(self):
        n=0
        #print(self._apples)
        while(n<self._apples):
            i=randrange(self._dim)
            j=randrange(self._dim)
            #print(i,j,self._data[i][j]==0)
            if (self._data[i][j]==0):

                if (j == 0 and i == 0):
                    if self._data[i][j+1]!=1 and self._data[i+1][j]!=1:
                        self.place_board([i, j], 1)
                        n += 1


                elif (j == self.dim - 1 and i == 0):
                    if self._data[i + 1][j] != 1 and self._data[i][j-1]!=1:
                        self.place_board([i, j], 1)
                        n += 1

                elif (j == self.dim - 1 and i == self.dim - 1):
                    if self._data[i-1][j]!=1 and self._data[i][j-1]!=1:
                        self.place_board([i, j], 1)
                        n += 1

                elif (j == 0 and i == self.dim - 1):
                    if self._data[i][j+1]!=1 and self._data[i-1][j]!=1:
                        self.place_board([i, j], 1)
                        n += 1

                elif(i==0):
                    if self._data[i + 1][j] != 1 and self._data[i][j + 1] != 1 and self._data[i][j - 1] != 1:
                        self.place_board([i, j], 1)
                        n += 1

                elif(j==0):
                    if self._data[i-1][j]!=1 and self._data[i+1][j]!=1 and self._data[i][j+1]!=1:
                        self.place_board([i, j], 1)
                        n += 1

                elif(i==self.dim-1):
                    if self._data[i-1][j]!=1 and self._data[i][j+1]!=1 and self._data[i][j-1]!=1:
                        self.place_board([i, j], 1)
                        n += 1

                elif (j == self.dim - 1):
                    if self._data[i-1][j]!=1 and self._data[i+1][j]!=1 and self._data[i][j-1]!=1:
                        self.place_board([i, j], 1)
                        n += 1

                else :
                    if self._data[i-1][j]!=1 and self._data[i+1][j]!=1 and self._data[i][j+1]!=1 and self._data[i][j-1]!=1:
                        self.place_board([i,j],1)
                        n+=1


    def mov(self):
        if self._snake.orientation=="up":
            next_postion=[self._snake.positions[0][0]-1,self._snake.positions[0][1]]
        if self._snake.orientation=="down":
            next_postion = [self._snake.positions[0][0]+1, self._snake.positions[0][1] ]
        if self._snake.orientation=="left":
            next_postion = [self._snake.positions[0][0], self._snake.positions[0][1]-1]
        if self._snake.orientation=="right":
            next_postion = [self._snake.positions[0][0], self._snake.positions[0][1]+1]

        #print(next_postion)
        for i in range(len(self._snake.positions)):
            self.place_board(self._snake.positions[i],0)

        if self._data [next_postion[0]][next_postion[1]]==1:

            copy_position=self._snake.positions[:]
            self._snake.size+=1



        else:
            copy_position = self._snake.positions[:-1]
            print(copy_position)
        #print(copy_position)
        self._snake.positions.clear()
        self._snake.positions.append(next_postion)
        for i in range(len(copy_position)):
            self._snake.positions.append(copy_position[i])
        #print(self._snake.positions)
        self.place_board(self._snake.positions[0],2)
        for i in range(1,len(self._snake.positions)):
            self.place_board(self._snake.positions[i],3)
