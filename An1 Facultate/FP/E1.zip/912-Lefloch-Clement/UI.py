from Board import Board


class UI:

    def start(self):
        self.b=Board("information.txt")
        Over=False
        while Over==False:
            print(self.b)
            command=input()
            command=command.split(" ")
            possibility={"move":self.move,"right":self.right,"left":self.left,"up":self.up,"down":self.down}

            if command[0] in possibility:
                possibility[command[0]]()


    def move(self):
        self.b.mov()
    def left(self):
        if(self.b.snake.orientation!="left" and self.b.snake.orientation!="right"):
            self.b.snake.orientation="left"
            self.b.mov()

    def right(self):
        if (self.b.snake.orientation != "left" and self.b.snake.orientation != "right"):
            self.b.snake.orientation = "right"
            self.b.mov()
    def up(self):
        if (self.b.snake.orientation != "up" and self.b.snake.orientation != "down"):
            self.b.snake.orientation = "up"
            self.b.mov()
    def down(self):
        if (self.b.snake.orientation != "up" and self.b.snake.orientation != "down"):
            self.b.snake.orientation = "down"
            self.b.mov()


a=UI()
a.start()
