


class Snake:
    def __init__(self):
        pass