
from board import Board
from game import Game
from ui_console.ui import Console


import configparser

if __name__ == '__main__':


    cfg =  configparser.ConfigParser()

    cfg.read('settings.properties')
    m_dict = dict(cfg.items('DEFAULT'))
    DIM = m_dict['dim'].strip()
    apple_count = m_dict['apple_count'].strip()



    #print(cfg)
    #print(DIM)
    #print(apple_count)

    board = Board(DIM,apple_count)
    game = Game(board)
    #game.snake_init()
    #game.init_random_apples()

    console = Console(game)
    console.start()




    #print(board.apple_count)

