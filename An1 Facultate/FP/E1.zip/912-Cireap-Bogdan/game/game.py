
from board import Board
import random



class Game:
    def __init__(self,board):
        self.board = board
        self.loose = False

    def snake_init(self):
        """
        the initial position for the snake. the game will always start with the snake in the middle and its tail
        pointing down
        :return:
        """
        dimension = int(self.board.dimension)

        self.board.data[dimension//2][dimension//2] = "*"
        self.board.data[dimension // 2 + 1][dimension // 2] = "+"
        self.board.data[dimension // 2 + 2][dimension // 2] = "+"






    def add_apple(self,row,col):
        """
        this verifies that there is no part of the snake or apple in a position and if it s not
        it adds an apple
        :param row:
        :param col:
        :return:
        """
        if self.board.data[row][col] != "." and self.board.data[row][col] != "+" and self.board.data[row][col] != "*":
            if self.board.data[row+1][col] != "." and self.board.data[row-1][col] != "." and self.board.data[row][col+1] != "." and self.board.data[row][col-1] != ".":
                self.board.data[row][col] = "."



    def init_random_apples(self):
        """
        this function randomly pics coordinates untill it gets valid ones. when it gets valid coordinates
        it will place an apple

        :return:
        """
        i = 0
        while i <= self.board.apple_count:
            row = random.randint(1,self.board.dimension-2)
            col = random.randint(1,self.board.dimension-2)

            self.add_apple(row,col)

            if self.board.data[row][col] == ".":
                i += 1


    def get_snake_head(self):
        dimension = int(self.board.dimension)
        for i in range(dimension):
            for j in range(dimension):
                if self.board.data[i][j] == "*":
                    return i,j

    def get_snake_direction(self):
        """
        verifies in which way the tail goes
        :return:
        """

        row,col = self.get_snake_head()
        try:
            if self.board.data[row][col+1] =="+":
                return row,col+1

            if self.board.data[row][col-1] =="+":
                return row,col-1

            if self.board.data[row+1][col] =="+":
                return row,col+1

            if self.board.data[row-1][col+1] =="+":
                return row,col+1
        except IndexError:
            pass




    def snake_move_in_direction(self, value):
        """
        this should move in the direction is currently facing
        also it should return False if the snake is out of bounds ( row <0 or row >4 sau col <0 or col >4)
        it also should return False if the snake hits a box that is already it s body
        :param value:
        :return:
        """
        head_r,head_c = self.get_snake_head()

        body_r,body_c = self.get_snake_direction()

        if head_r == body_r: # if the head and the body are on the same row we have a horizontal value
            #now check if it s left or right
            if body_c +1 == head_c: #this means the snake is going right
                if head_c + value > self.board.dimension:
                    self.loose = True  # if we go outside the border we loose
                else:

                    # if we are still inside the border
                    # the coordinate + value will get the head and the body
                    #first clear the snake
                    self.board.data[head_r][head_c] = " "
                    self.board.data[body_r][body_c] = " "
                    self.board.data[body_r][body_c-1] = " "

                    # now we move the snake in the desired direction
                    self.board.data[head_r][head_c+value] = "*"
                    self.board.data[body_r][body_c+value] = "+"
                    self.board.data[body_r][body_c - 1+value] = "+"





            elif body_c-1 == head_c: # this means the snake is going left
                if head_c - value < 0 :
                    self.loose = True  # if we go outside the border we loose
                else:

                    # if we are still inside the border
                    # the coordinate + value will get the head and the body
                    #first clear the snake
                    self.board.data[head_r][head_c] = " "
                    self.board.data[body_r][body_c] = " "
                    self.board.data[body_r][body_c+1] = " "

                    # now we move the snake in the desired direction
                    self.board.data[head_r][head_c-value] = "*"
                    self.board.data[body_r][body_c-value] = "+"
                    self.board.data[body_r][body_c + 1-value] = "+"



        if head_c == body_c: # if the head and the body are on the same row we have a vertical value
            if body_r +1 == head_r: # this means the snake is going down
                if head_r + value > self.board.dimension:
                    self.loose = True  # if we go outside the border we loose
                else:

                    # if we are still inside the border
                    # the coordinate + value will get the head and the body
                    # first clear the snake
                    self.board.data[head_r][head_c] = " "
                    self.board.data[body_r][body_c] = " "
                    self.board.data[body_r-1][body_c] = " "

                    # now we move the snake in the desired direction
                    self.board.data[head_r+value][head_c] = "*"
                    self.board.data[body_r+value][body_c] = "+"
                    self.board.data[body_r-1+value][body_c] = "+"

            elif body_r -1 == head_r: # this means the snek is going up
                if head_r - value < 0:
                    self.loose = True  # if we go outside the border we loose
                else:

                    # if we are still inside the border
                    # the coordinate + value will get the head and the body
                    # first clear the snake
                    self.board.data[head_r][head_c] = " "
                    self.board.data[body_r][body_c] = " "
                    self.board.data[body_r + 1][body_c] = " "

                    # now we move the snake in the desired direction
                    self.board.data[head_r - value][head_c] = "*"
                    self.board.data[body_r - value][body_c] = "+"
                    self.board.data[body_r + 1 - value][body_c] = "+"



    def snake_directions(self, direction):
        """
        this should just change the direction of the snake change the direction of the snake
        i will simply move the head to the desired direction and move the tail by 1 square so it s adiacent to the head
        :return:
        """
        # firstly check that the direction is not 180 degrees
        if direction == "up":
            pass
        if direction == "down":
            pass
        if direction == "left":
            pass
        if direction == "right":
            pass



        pass


    def snake_ate(self):
        """
        what should i do if it eats
        :return:
        """
        pass

