


class Console:
    def __init__(self,game):
        self.game = game



    def start(self):
        finished = False

        self.game.snake_init()
        self.game.init_random_apples()
        print(self.game.board.__str__())
        # here will be the main game loop

        while finished == False:
            """
            here i will get the input from the player as well as see if the movement made it so that the snake goes
            out of the bounds
            
            """
            value = int(input("how many tiles do you want to move in the current direction?:"))
            if value < 1 :
                print("try a natural number")
            else:
                self.game.snake_move_in_direction(value)



            print(self.game.board.__str__())
            if self.game.loose == True:
                finished = True
                print("you hit a wall")

