from texttable import Texttable



class Board:
    """
    this class will be responsible for keeping the board. updating it and drawing it.
    """
    def __init__(self,DIM,count):
        self.dim = int(DIM) # get the dimension of the board so we can draw it
        self.data = [[" " for j in range(int(self.dim))] for i in range(int(self.dim))]
        self.apple_count = int(count)



    @property
    def dimension(self):
        return self.dim
    # gets the dimension

    def get(self,row,col):
        """
        gets the data in the specificated row and column. it can be none snake head snake body or apple
        :param row:
        :param col:
        :return:
        """
        return self.data[row][col]

    def is_free(self,row,col):
        """
        verifies if a cell is free
        :param row:
        :param col:
        :return:
        """
        return self.get(row,col) == None

    def __str__(self):
        """
        this function prints the board
        :return:
        """

        board = Texttable()

        for row_index, row in enumerate(self.data):
            row_text = row

            board.add_row(row_text)


        return board.draw()






"""
board = Board()

print(board.__str__())
"""

