from texttable import Texttable

from game import MoveException


class UI:
    def __init__(self, game_service):
        self.game_service = game_service

    def print_menu(self):
        print("1.Move the snake using the command move [n], where n is the number of squares.")
        print("2.Modify the direction: up | right | down | left")
        print("3.Exit using the command exit.")

    def start_game(self):
        print("Welcome to Snake! What to you want to do?")
        board = self.game_service.initialise_board()
        text = Texttable()
        done = False
        direction = "up"
        snake_position = board.snake_position
        while not done:
            try:
                for row_index in range(board.dimension):
                    data = []
                    for column_index in range(board.dimension):
                        if board.matrix[row_index][column_index] == 0:
                            data.append(' ')
                        elif board.matrix[row_index][column_index] == 1:
                            data.append('*')
                        elif board.matrix[row_index][column_index] == 2:
                            data.append('+')
                        elif board.matrix[row_index][column_index] == -1:
                            data.append('.')
                    text.add_row(data)
                print(text.draw())
                text.reset()
                self.print_menu()
                user_command = str(input("Enter a command: "))
                space_or_not = user_command.find(" ")
                if space_or_not == -1:
                    if user_command == "move":
                        self.game_service.move(board, direction, snake_position, 1)
                    elif user_command == "up" or user_command == "down" or user_command == "right" or user_command == "left":
                        if direction == "up" and user_command == "down":
                            raise MoveException("Invalid move!")
                        elif direction == "down" and user_command == "up":
                            raise MoveException("Invalid move!")
                        elif direction == "left" and user_command == "right":
                            raise MoveException("Invalid move!")
                        elif direction == "right" and user_command == "left":
                            raise MoveException("Invalid move!")
                        else:
                            direction = user_command
                            snake_position = self.game_service.move(board, direction, snake_position, 1)
                    elif user_command == "exit":
                        done = True
                    else:
                        print("Invalid command!")
                else:
                    user_command = user_command.split()
                    if user_command[0] == "move":
                        if user_command[1].isnumeric():
                            snake_position = self.game_service.move(board, direction, snake_position, int(user_command[1]))
                        else:
                            print("Invalid number of cells!")
                    else:
                        print("Invalid command!")
                if self.game_service.game_over(board):
                    done = True
            except MoveException as me:
                print(str(me))





