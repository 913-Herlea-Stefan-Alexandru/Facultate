from domain import Board


class MoveException(Exception):
    def __init__(self, msg=''):
        self._msg = msg

    def __str__(self):
        return self._msg


class PlayGame:
    def initialise_board(self):
        with open("settings.txt", "r") as file:
            dimension = file.readline()
            dimension = dimension.split("=")
            dimension = int(dimension[1])

            apple_count = file.readline()
            apple_count = apple_count.split("=")
            apple_count = int(apple_count[1])

            board = Board(dimension, apple_count)
        return board

    def move(self, board, direction, snake_position, number_of_squares):
        if direction == "up":
            apple_eaten = False
            if board.matrix[snake_position[0][0] + 1 + number_of_squares][snake_position[0][1]] == -1:
                apple_eaten = True
                board.matrix[snake_position[0][0] + 1 + number_of_squares][snake_position[0][1]] = 1
                board.matrix[snake_position[0][0]][snake_position[0][1]] = 2
                board.matrix[snake_position[board.snake_length - number_of_squares][0]][snake_position[board.snake_length - 1][1]] = 1
                board.snake_length += 1
                new_snake_position = [[snake_position[0][0] + number_of_squares, snake_position[0][1]],
                                      [snake_position[0][0], snake_position[0][1]],
                                      [snake_position[board.snake_length - number_of_squares][0], snake_position[board.snake_length - 1][1]]]
            else:
                board.matrix[snake_position[0][0] + 1 + number_of_squares][snake_position[0][1]] = 1
                board.matrix[snake_position[0][0]][snake_position[0][1]] = 2
                board.matrix[snake_position[board.snake_length - number_of_squares][0]][snake_position[board.snake_length - 1][1]] = 0
                new_snake_position = [[snake_position[0][0] + number_of_squares, snake_position[0][1]],
                                      [snake_position[0][0], snake_position[0][1]],
                                      [snake_position[board.snake_length - number_of_squares][0], snake_position[board.snake_length - 1][1]]]
            return new_snake_position, apple_eaten
        if direction == "down":
            board.matrix[int(snake_position[0][0]) + int(number_of_squares)][int(snake_position[0][1])] = 2
            board.matrix[int(snake_position[0][0])][int(snake_position[0][1])] = 1
            board.matrix[snake_position[int(board.snake_length) - int(number_of_squares)][0]][
                snake_position[board.snake_length - 1][1]] = 0
            new_snake_position = [[snake_position[0][0] + number_of_squares, snake_position[0][1]],
                                  [snake_position[0][0], snake_position[0][1]],
                                  [snake_position[board.snake_length - number_of_squares][0],
                                   snake_position[board.snake_length - 1][1]]]
            return new_snake_position
        if direction == "left":
            board.matrix[snake_position[0][0] + int(number_of_squares)][snake_position[0][1]] = 2
            board.matrix[int(snake_position[0][0])][int(snake_position[0][1])] = 1
            board.matrix[snake_position[int(board.snake_length) - int(number_of_squares)][0]][snake_position[board.snake_length - 1][1]] = 0
            new_snake_position = [[snake_position[0][0] + number_of_squares, snake_position[0][1]],
                                  [snake_position[0][0], snake_position[0][1]],
                                  [snake_position[board.snake_length - number_of_squares][0],
                                   snake_position[board.snake_length - 1][1]]]
            return new_snake_position
        if direction == "right":
            board.matrix[int(snake_position[0][0]) + int(number_of_squares)][int(snake_position[0][1])] = 2
            board.matrix[int(snake_position[0][0])][int(snake_position[0][1])] = 1
            board.matrix[snake_position[int(board.snake_length) - int(number_of_squares)][0]][
                snake_position[board.snake_length - 1][1]] = 0
            new_snake_position = [[snake_position[0][0] + number_of_squares, snake_position[0][1]],
                                  [snake_position[0][0], snake_position[0][1]],
                                  [snake_position[board.snake_length - number_of_squares][0],
                                   snake_position[board.snake_length - 1][1]]]
            return new_snake_position

    def game_over(self, snake_position):
        return False
