from game import PlayGame
from ui import UI

game_service = PlayGame()
ui = UI(game_service)
ui.start_game()