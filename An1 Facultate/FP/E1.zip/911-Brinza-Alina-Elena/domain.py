import random


class Board:
    def __init__(self, dimension, apple_count):
        self.dimension = dimension
        self.apple_count = apple_count
        self.matrix = [[0 for x in range(dimension)] for y in range(dimension)]
        self.snake_position = self.put_snake()
        self.put_apples()
        self.snake_length = self.length_of_snake()

    def put_snake(self):
        middle_row = self.dimension // 2
        middle_column = self.dimension // 2
        self.matrix[middle_row-1][middle_column] = 1
        self.matrix[middle_row][middle_column] = 2
        self.matrix[middle_row+1][middle_column] = 2
        return [[middle_row - 1, middle_column], [middle_row, middle_column], [middle_row+1, middle_column]]

    def put_apples(self):
        list_of_available_positions = []
        for row in range(self.dimension):
            for column in range(self.dimension):
                if self.matrix[row][column] == 0:
                    list_of_available_positions.append((row, column))

        number_of_apples = self.apple_count
        while number_of_apples > 0:
            position = random.choice(list_of_available_positions)
            if self.matrix[position[0]][position[1]] != 2 and self.matrix[position[0]][position[1]] != 1:
                if position[0] == 0:
                    if position[1] == 0:
                        if self.matrix[position[0]][position[1]+1] != -1 and self.matrix[position[0]+1][position[1]] != -1:
                            list_of_available_positions.remove(position)
                            self.matrix[position[0]][position[1]] = -1
                            number_of_apples = number_of_apples - 1
                    elif position[1] == 6:
                        if self.matrix[position[0]][position[1] - 1] != -1 and self.matrix[position[0] + 1][position[1]] != -1:
                            list_of_available_positions.remove(position)
                            self.matrix[position[0]][position[1]] = -1
                            number_of_apples = number_of_apples - 1
                    else:
                        if self.matrix[position[0]][position[1] - 1] != -1 and self.matrix[position[0] + 1][position[1]] != -1 and self.matrix[position[0]][position[1] + 1]:
                            list_of_available_positions.remove(position)
                            self.matrix[position[0]][position[1]] = -1
                            number_of_apples = number_of_apples - 1
                elif position[0] == 6:
                    if position[1] == 0:
                        if self.matrix[position[0]][position[1]+1] != -1 and self.matrix[position[0]-1][position[1]] != -1:
                            list_of_available_positions.remove(position)
                            self.matrix[position[0]][position[1]] = -1
                            number_of_apples = number_of_apples - 1
                    elif position[1] == 6:
                        if self.matrix[position[0]][position[1]-1] != -1 and self.matrix[position[0]-1][position[1]] != -1:
                            list_of_available_positions.remove(position)
                            self.matrix[position[0]][position[1]] = -1
                            number_of_apples = number_of_apples - 1
                    else:
                        if self.matrix[position[0]][position[1] - 1] != -1 and self.matrix[position[0] - 1][position[1]] != -1 and self.matrix[position[0]][position[1] - 1] != -1:
                            list_of_available_positions.remove(position)
                            self.matrix[position[0]][position[1]] = -1
                            number_of_apples = number_of_apples - 1
                else:
                    if position[1] == 0:
                        if self.matrix[position[0]-1][position[1]] != -1 and self.matrix[position[0]+1][position[1]] != -1 and self.matrix[position[0]][position[1]+1] != -1:
                            list_of_available_positions.remove(position)
                            self.matrix[position[0]][position[1]] = -1
                            number_of_apples = number_of_apples - 1
                    elif position[1] == 6:
                        if self.matrix[position[0]-1][position[1]] != -1 and self.matrix[position[0]+1][position[1]] != -1 and self.matrix[position[0]][position[1]-1] != -1:
                            list_of_available_positions.remove(position)
                            self.matrix[position[0]][position[1]] = -1
                            number_of_apples = number_of_apples - 1
                    else:
                        if self.matrix[position[0]-1][position[1]] != -1 and self.matrix[position[0]+1][position[1]] != -1 and self.matrix[position[0]][position[1]-1] != -1 and self.matrix[position[0]][position[1]+1] != -1:
                            list_of_available_positions.remove(position)
                            self.matrix[position[0]][position[1]] = -1
                            number_of_apples = number_of_apples - 1

    def length_of_snake(self):
        length = 0
        for row in range(self.dimension):
            for column in range(self.dimension):
                if self.matrix[row][column] == 1 or self.matrix[row][column] == 2:
                    length += 1
        return length


