"""
This module boots my game up
"""
from entity.domain import GameBoard
from service.functionalities import Functionalities
from ui.UI import UserInterface

with open("settings.properties", "r") as f:
    dimension = f.readline()
    dimension = dimension.split()
    dimension = dimension[2]
    dimension = int(dimension)

    apple_count = f.readline()
    apple_count = apple_count.split()
    apple_count = apple_count[2]
    apple_count = int(apple_count)

entity = GameBoard(dimension, apple_count)
entity.snake_starting_position()
entity.place_random_apples()
service = Functionalities(entity)
UI = UserInterface(service)
UI.start()
