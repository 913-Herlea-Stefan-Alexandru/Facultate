"""
Domain module
"""
import random
from texttable import Texttable


class GameError(Exception):
    def __init__(self, message):
        self._message = message


class GameBoard:
    """
    Here I will create the board needed for snake
    """
    def __init__(self, dimension, apple_count):
        self._rows = dimension
        self._columns = dimension
        self._apples = apple_count
        self._board = [[' ' for column in range(self._columns + 1)] for row in range(self._rows + 1)]

    def snake_starting_position(self):
        starting_position = self._rows // 2
        self._board[starting_position-1][starting_position] = '*'
        self._board[starting_position][starting_position] = '+'
        self._board[starting_position+1][starting_position] = '+'

    def place_random_apples(self):
        apples_placed = 0
        while apples_placed < self._apples:
            row = random.randint(0, self._rows)
            column = random.randint(0, self._columns)
            ok = 1
            if self._board[row][column] == '.' or self._board[row][column] == '*' or self._board[row][column] == '+':
                ok = 0
            else:
                for rows in range(row-1, row+2):
                    for columns in range(column-1, column+2):
                        if 0 <= rows <= self._rows and 0 <= columns <= self._columns:
                            if self._board[rows][columns] != " " or (self._board[rows][columns-1] != " " and self._board[rows][columns+1] != " " and self._board[rows][columns] != " " and self._board[rows][columns] != " "):
                                ok = 0
                                break
            if ok == 1:
                self._board[row][column] = '.'
                apples_placed += 1

    def __str__(self):
        table = Texttable()
        for row in range(self._rows):
            data = []

            for val in self._board[row][0:-1]:
                data.append(str(val))
            table.add_row(data)
        return table.draw()

"""
o = GameBoard()
o.snake_starting_position()
print(str(o))
"""