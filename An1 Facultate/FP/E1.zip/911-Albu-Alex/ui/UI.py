"""
This module is where I store all my UI related functions
"""
from entity.domain import GameError


class UserInterface:
    def __init__(self, service):
        self._functionalities = service
        self._player_moves = []

    def move_snake_in_same_direction_ui(self, number_of_squares_moved):
        self._functionalities.move_snake_in_same_direction(number_of_squares_moved, self._player_moves)
        self.print_board_ui()

    def move_snake_in_other_direction_ui(self, direction):
        self._functionalities.move_snake_in_other_direction(direction, self._player_moves)
        self._player_moves.append(direction)
        self.print_board_ui()

    def print_board_ui(self):
        board = self._functionalities.print_board()
        print(board)

    def start(self):
        self.print_board_ui()
        command_dictionary = {"move": self.move_snake_in_same_direction_ui, "up": self.move_snake_in_other_direction_ui,
                              "down": self.move_snake_in_other_direction_ui, "right": self.move_snake_in_other_direction_ui,
                              "left": self.move_snake_in_other_direction_ui}
        done = False
        while not done:
            command = input("command> ")
            command = command.lower()
            command_word, command_parameters = self._functionalities.split_command(command)
            if command_parameters == "":
                command_parameters = command_word
            if command_word in command_dictionary:
                try:
                    command_dictionary[command_word](command_parameters)
                except GameError:
                    done = True
                    print("Game over!")
            elif command_word == "exit" or command_word == "quit" or command_word == "0":
                done = True
            else:
                print("Invalid command!")
