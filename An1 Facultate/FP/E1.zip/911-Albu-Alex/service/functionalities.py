"""
This module is where I store all my functions needed for the game
"""
import random

from entity.domain import GameError


class Functionalities:
    def __init__(self, domain):
        self._entity = domain

    def print_board(self):
        return self._entity.__str__()

    def add_new_apple(self):
        done = False
        while not done:
            row = random.randint(0, self._entity._rows)
            column = random.randint(0, self._entity._columns)
            ok = 1
            if self._entity._board[row][column] != ' ':
                ok = 0
            for rows in range(row-1, row+2):
                for columns in range(column-1, column+2):
                    if 0 <= rows <= self._entity._rows and 0 <= columns <= self._entity._columns:
                        if self._entity._board[rows][columns] != " " or (self._entity._board[rows][columns-1] != " " and self._entity._board[rows][columns+1] != " " and self._entity._board[rows][columns] != " " and self._entity._board[rows][columns] != " "):
                            ok = 0
                            break
            if ok == 1:
                self._entity._board[row][column] = '.'
                done = True

    @staticmethod
    def split_command(command):
        instructions = command.strip().split(" ", 1)
        instructions[0] = instructions[0].strip().lower()
        return instructions[0], "" if len(instructions) == 1 else instructions[1].strip()

    def find_snake_head(self):
        for row in range(self._entity._rows+1):
            for column in range(self._entity._columns+1):
                if self._entity._board[row][column] == '*':
                    return [row, column]

    def find_snake_body(self):
        snake_body = []
        for row in range(self._entity._rows+1):
            for column in range(self._entity._columns+1):
                if self._entity._board[row][column] == '+':
                    snake_body.append([row, column])

        return snake_body

    def move_snake_in_same_direction(self, number_of_squares_moved, player_moves):
        direction = player_moves[-1]
        iterations = int(number_of_squares_moved)
        for square in range(iterations):
            snake_head = self.find_snake_head()
            if direction == "up":
                if snake_head[0] == 0:
                    raise GameError("Game over!")
            elif direction == "down":
                if snake_head[0] == self._entity._rows-1:
                    raise GameError("Game over!")
            elif direction == "right":
                if snake_head[1] == self._entity._columns-1:
                    raise GameError("Game over!")
            elif direction == "left":
                if snake_head[1] == 0:
                    raise GameError("Game over!")
            self.move_snake_by_one(direction)

    def move_snake_in_other_direction(self, direction, player_moves):
        if len(player_moves) >= 1:
            if (player_moves[-1] == "down" and direction == "up") or (player_moves[-1] == "up" and direction == "down") \
                or (player_moves[-1] == "right" and direction == "left") or (player_moves[-1] == "left" and direction == "right"):
                raise GameError("Game over!")
            if direction == player_moves[-1]:
                return
        snake_head = self.find_snake_head()
        if direction == "up":
            if snake_head[0] == 0:
                raise GameError("Game over!")
        elif direction == "down":
            if snake_head[0] == self._entity._rows-1:
                raise GameError("Game over!")
        elif direction == "right":
            if snake_head[1] == self._entity._columns-1:
                raise GameError("Game over!")
        elif direction == "left":
            if snake_head[1] == 0:
                raise GameError("Game over!")

        self.move_snake_by_one(direction)

    def move_snake_by_one(self, direction):
        snake_head = self.find_snake_head()
        if direction == "up":
            if self._entity._board[snake_head[0]-1][snake_head[1]] == '.':
                self.add_new_apple()
            self._entity._board[snake_head[0]-1][snake_head[1]] = '*'
            self._entity._board[snake_head[0]][snake_head[1]] = ' '
        elif direction == "down":
            if self._entity._board[snake_head[0]+1][snake_head[1]] == '.':
                self.add_new_apple()
            self._entity._board[snake_head[0]+1][snake_head[1]] = '*'
            self._entity._board[snake_head[0]][snake_head[1]] = ' '
        elif direction == "right":
            if self._entity._board[snake_head[0]][snake_head[1]+1] == '.':
                self.add_new_apple()
            self._entity._board[snake_head[0]][snake_head[1]+1] = '*'
            self._entity._board[snake_head[0]][snake_head[1]] = ' '
        elif direction == "left":
            if self._entity._board[snake_head[0]][snake_head[1]-1] == '.':
                self.add_new_apple()
            self._entity._board[snake_head[0]][snake_head[1]-1] = '*'
            self._entity._board[snake_head[0]][snake_head[1]] = ' '
