class Board:
    def __init__(self, dim, apples):
        self._DIM = dim
        self._apple_count = apples
        self._matrix = [["" for _ in range(self._DIM)] for _ in range(self._DIM)]
        self._apples = []
        self._snake_head = []
        self._snake_coord = []
        self.place_snake()
        self.place_apples()

    def place_snake(self):
        middle = self._DIM//2
        self._matrix[middle][middle] = "+"
        self._matrix[middle - 1][middle] = "*"
        self._matrix[middle + 1][middle] = "+"
        self._snake_head.append([middle - 1, middle])
        self._snake_coord.append([middle, middle])
        self._snake_coord.append([middle + 1, middle])

    def apple_condition(self, directions, pos_i, pos_j):
        ok = False
        nr = 0
        while not ok:
            for d in directions:
                new_line_i = pos_i + d[0]
                new_line_j = pos_j + d[1]
                if -1 >= new_line_i or new_line_i >= self._DIM:
                    continue
                elif -1 >= new_line_j or new_line_j >= self._DIM:
                    continue
                elif self._matrix[new_line_i][new_line_j] == "." or self._matrix[new_line_i][new_line_j] == "+"\
                        or self._matrix[new_line_i][new_line_j] == "*":
                    nr += 1
                    ok = True
            if nr==0 and not ok:
                break

        return not ok

    def place_apples(self):
        from random import randrange
        pos_i = []
        pos_j = []
        for _ in range(self._apple_count+1):
            pos_i.append(randrange(self._DIM))
            pos_j.append(randrange(self._DIM))
        directions = [[-1, 0],[-1,1],[0,1],[1, 1],[1,0],[1,-1],[0,-1],[-1,-1]]
        for k in range(self._apple_count):
            while self._matrix[pos_i[k]][pos_j[k]] != "":
                pos_i[k] = randrange(self._DIM)
                pos_j[k] = randrange(self._DIM)
            while not self.apple_condition(directions, pos_i[k], pos_j[k]):
                pos_i[k] = randrange(self._DIM)
                pos_j[k] = randrange(self._DIM)
            self._matrix[pos_i[k]][pos_j[k]] = "."

        for k in range(self._apple_count):
            mini_list = [pos_i[k], pos_j[k]]
            self._apples.append(mini_list)


    def get_board(self):
        return self._matrix

    def get_snake_head(self):
        return self._snake_head

    def get_snake_body(self):
        return self._snake_coord

    def set_snake_head(self, value):
        self._snake_head = value

    def set_snake_body(self, value):
        self._snake_coord = value

    def set_body_part(self, index, value):
        self._snake_coord[index] = value

    def update_matrix(self):
        for i in range(self._DIM):
            for j in range(self._DIM):
                if self._matrix[i][j] == "*" or self._matrix[i][j] == "+":
                    self._matrix[i][j] = ""

        self._matrix[self._snake_head[0][0]][self._snake_head[0][1]] = "*"

        for elem in self._snake_coord:
            self._matrix[elem[0]][elem[1]] = "+"

