class Snake:
    def __init__(self):
        self._length = 3
        self._direction = "UP"
        self._head = []
        self._body = []

    def get_head(self):
        return self._head

    def get_body(self):
        return self._body

    def set_head(self, value):
        self._head = value

    def set_body(self, value):
        self._body = value

    def move_head(self, steps, dir):
        while steps:
            self._head[0][0] += dir[0]
            self._head[0][1] += dir[1]
            steps -= 1

    def move_body(self, steps, dir):
        for elem in self._body:
            copy = steps
            while copy:
                elem[0] += dir[0]
                elem[1] += dir[1]
                copy -= 1