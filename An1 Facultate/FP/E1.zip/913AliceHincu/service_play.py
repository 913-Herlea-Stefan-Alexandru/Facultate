class GameOverException(Exception):
    def __init__(self, msg):
        super().__init__(msg)


class Game:
    def __init__(self, snake, board, dim):
        self._snake = snake
        self._board = board
        self._DIM = dim
        self._snake.set_head(self._board.get_snake_head())
        self._snake.set_body(self._board.get_snake_body())
        self._direction = {"UP": [-1, 0], "DOWN": [1, 0],"LEFT": [0, -1],"RIGHT": [0, 1]}
        self._actual_dir = "UP"
        self._last_dir = []

        self._actual_steps = 0
        self._last_coord = []

    def move(self, steps):
        steps = int(steps)
        self._actual_steps += steps

        for _ in range(steps):

            aux = [self._board.get_snake_head()[0][0], self._board.get_snake_head()[0][1]]
            aux2 = 0
            index = 0
            for elem in self._board.get_snake_body():
                aux2 = elem
                self._board.set_body_part(index, aux)
                index += 1
                aux = aux2
            self._last_coord = aux
            self.check_for_apple(self._snake.get_head(), self._direction[self._actual_dir])
            self._snake.move_head(1, self._direction[self._actual_dir])
            self._board.set_snake_head(self._snake.get_head())

        if self._snake.get_head()[0][0] <= -1 or self._snake.get_head()[0][0] > self._DIM:
            raise GameOverException("You lost! You hit a wall")
        elif self._snake.get_head()[0][1] <= -1 or self._snake.get_head()[0][1] > self._DIM:
            raise GameOverException("You lost! You hit a wall")
        elif self._board.get_board()[self._snake.get_head()[0][0]][self._snake.get_head()[0][1]] == "+":
            raise GameOverException("You lost! You hit yourself")
        else:
            self._board.update_matrix()

    def change_direction(self, value):
        self._last_dir = self._actual_dir
        self._actual_steps = 0
        self._actual_dir = value

    def check_direction(self, dir):
        if dir == "DOWN" and self._actual_dir == "UP":
            return False
        if dir == "UP" and self._actual_dir == "DOWN":
            return False
        if dir == "LEFT" and self._actual_dir == "RIGHT":
            return False
        if dir == "RIGHT" and self._actual_dir == "LEFT":
            return False
        return True

    def check_for_apple(self, snake_head, dir):
        apple = [0,0]
        apple[0] = snake_head[0][0] + dir[0]
        apple[1] = snake_head[0][1] + dir[1]
        if self._board.get_board()[apple[0]][apple[1]] == ".":
            self._snake.set_body(self._board.get_snake_body().append(self._last_coord))

