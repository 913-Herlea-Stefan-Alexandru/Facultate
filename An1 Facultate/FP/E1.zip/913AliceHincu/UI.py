from texttable import Texttable
from domain.Board import Board
from domain.Snake import Snake
from service_play import Game, GameOverException


class ConsoleException(Exception):
    def __init__(self, msg):
        super().__init__(msg)


class Console:
    def __init__(self):
        self.main_message()
        self._unicorns_exist = True
        with open("board.txt", "r") as file:
            lines = [data for data in file.read().split('\n')]
            self._DIM = int(lines[0])
            self._apple_count = int(lines[1])

        self._board = Board(self._DIM, self._apple_count)
        self._snake = Snake()
        self.snake_length = 3
        self._apple_pos = []
        self._game = Game(self._snake, self._board, self._DIM)

        self.main_loop()

    def main_message(self):
        print("~Welcome! Please be aware that the input from the file and console should be valid~"
              "~Now you can start playing~")

    def main_loop(self):
        while self._unicorns_exist:
            self.print_board()
            command = input(">command: ")
            try:
                self.handle_command(command)
                pass
            except ConsoleException as e:
                print(e)

    def handle_command(self, command: str):
        if command == "LEFT" or command == "RIGHT" or command == "UP" or command == "DOWN":
            if self._game.check_direction(command):
                self._game.change_direction(command)
            else:
                print("You can't turn 180 degrees")
        elif command == "move":
            try:
                self._game.move(1)
            except GameOverException as er:
                self._unicorns_exist = False
                print(er)
        else:
            command = command.strip().split()
            steps = int(command[1])
            try:
                self._game.move(steps)
            except GameOverException as er:
                self._unicorns_exist = False
                print(er)

    def print_board(self):
        print(
            "✨ Board ✨"
        )
        table = Texttable()
        table.set_cols_align(["c"]*self._DIM)
        table.set_cols_valign(["m"]*self._DIM)
        for line in self._board.get_board():
            table.add_row(line)
        print(table.draw())

        print(
            "✨ Play ✨"
        )