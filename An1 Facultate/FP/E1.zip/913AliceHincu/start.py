from UI import Console

console = Console()