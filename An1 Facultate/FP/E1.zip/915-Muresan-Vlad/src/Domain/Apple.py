class Apple:
    def __init__(self, coordinates):
        self.__coordinates = coordinates

    def get_x(self):
        return self.__coordinates[0]

    def get_y(self):
        return self.__coordinates[1]

    def adjacent(self, other):
        if self.__coordinates[0] == other.__coordinates[0]:
            if self.__coordinates[1] - 1 == other.__coordinates[1]:
                return True
            elif self.__coordinates[1] + 1 == other.__coordinates[1]:
                return True

        if self.__coordinates[1] == other.__coordinates[1]:
            if self.__coordinates[0] - 1 == other.__coordinates[0]:
                return True
            elif self.__coordinates[0] + 1 == other.__coordinates[0]:
                return True

        return False

    def __eq__(self, other):
        return self.__coordinates == other.__coordinates and not self.adjacent(other)

    def __str__(self):
        return str(self.__coordinates[0]) + " " + str(self.__coordinates[1])