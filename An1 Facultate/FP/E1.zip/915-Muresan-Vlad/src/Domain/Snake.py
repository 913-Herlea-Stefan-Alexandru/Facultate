class Snake:
    def __init__(self):
        self.__length = 3
        self.__head = ()
        self.__coordinates = []
        self.__direction = "up"

    def get_length(self):
        return self.__length

    def inc_length(self):
        self.__length += 1

    def get_head(self):
        return self.__head

    def set_head(self, coordinates):
        self.__head = coordinates

    def get_coordinates(self):
        return self.__coordinates[:]

    def set_coordinates(self, coordinates):
        self.__coordinates.clear()
        self.__coordinates = coordinates

    def get_direction(self):
        return self.__direction

    def set_direction(self, new_direction):
        self.__direction = new_direction

    def in_snake_coordinates(self, coordinates):
        for snake_coordinate in self.__coordinates:
            if coordinates == snake_coordinate:
                return True
        return False