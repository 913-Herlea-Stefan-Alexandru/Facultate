from texttable import Texttable
from Domain.Snake import Snake


class Board:
    def __init__(self, dim, apple_count):
        self.__rows = dim
        self.__columns = dim
        self.__apple_count = apple_count
        self.__apples = [] * apple_count
        self.__snake = Snake()

    def init_snake(self):
        snake_coordinates = list()
        snake_head = (self.__rows//2 - 1, self.__columns//2)
        self.__snake.set_head(snake_head)
        snake_coordinates.append(snake_head)
        snake_coordinates.append((snake_head[0] + 1, snake_head[1]))
        snake_coordinates.append((snake_head[0] + 2, snake_head[1]))
        self.__snake.set_coordinates(snake_coordinates)

    def get_dim(self):
        return self.__rows

    def get_apples(self):
        return self.__apples[:]

    def get_snake(self):
        return self.__snake

    def get_snake_head(self):
        return self.__snake.get_head()

    def get_snake_coord(self):
        return self.__snake.get_coordinates()

    def set_new_snake_coord(self, coordinates):
        self.__snake.set_coordinates(coordinates)

    def set_new_head(self, new_head):
        self.__snake.set_head(new_head)

    def get_apple_count(self):
        return self.__apple_count

    def get_direction(self):
        return self.__snake.get_direction()

    def set_direction(self, direction):
        self.__snake.set_direction(direction)

    def add_apple(self, apple):
        if apple not in self.__apples:
            self.__apples.append(apple)
        else:
            return None

    def __str__(self):
        t = Texttable()

        snake_coordinates = self.__snake.get_coordinates()
        snake_head = self.__snake.get_head()

        for index in range(self.__rows):
            row_data = [' '] * self.__columns
            for apple in self.__apples:
                if apple.get_x() == index:
                    row_data[apple.get_y()] = '.'

            for coordinates in snake_coordinates:
                if coordinates[0] == index:
                    if coordinates == snake_head:
                        row_data[coordinates[1]] = '*'
                    else:
                        row_data[coordinates[1]] = '+'

            t.add_row(row_data)

        return t.draw()