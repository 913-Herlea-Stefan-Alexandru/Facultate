from Erorrs.Exceptions import DirectionError


class UI:
    def __init__(self, game):
        self.__game = game
        self.__directions = ["up", "down", "right", "left"]

    def print_start_screen(self):
        print("Snake")
        print("Play snake using the following commands:\n"
              "`move [n]`. This moves the snake `n` squares, in the direction it is currently facing\n"
              "`up | right | down | left` changes the snake's direction accordingly and moves the snake by 1 in the new"
              " direction\n")

    def print_board(self):
        print(self.__game.get_board())

    def move_ui(self, token):
        while token != 0:
            self.__game.snake_move()
            token -= 1

        self.print_board()

    def change_direction_ui(self, token):
        self.__game.set_direction(token)
        self.move_ui(1)

    def run(self):
        self.print_start_screen()
        self.print_board()
        print("\nEnter a command to start the game: ")
        while True and self.__game.get_game_state() == "playing":
            try:
                cmd = input(">>>").strip()
                if cmd == "":
                    continue
                else:
                    cmd = cmd.split(" ")
                    if cmd[0].lower() == "move":
                        if len(cmd) == 1:
                            self.move_ui(1)
                        elif len(cmd) == 2:
                            self.move_ui(int(cmd[1]))
                        else:
                            print("Too many parameters for move command! Try again")
                    elif cmd[0].lower() in self.__directions:
                        self.change_direction_ui(cmd[0])
                    else:
                        print("Bad command! Try Again")
            except ValueError as ve:
                print("Invalid input string! Try again")
            except DirectionError as de:
                print(de)
        print("Game Over!")