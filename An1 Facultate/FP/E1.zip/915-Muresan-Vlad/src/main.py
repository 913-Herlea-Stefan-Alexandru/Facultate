from Settings.Settings import Settings
from Board.Board import Board
from Game.Game import Game
from Presentation.console import UI

if __name__ == '__main__':
    settings = Settings("Settings/settings.properties")
    config = settings.get_settings()

    dim = config[0]
    apple_count = config[1]

    board = Board(dim, apple_count)
    game = Game(board)

    ui = UI(game)
    ui.run()

