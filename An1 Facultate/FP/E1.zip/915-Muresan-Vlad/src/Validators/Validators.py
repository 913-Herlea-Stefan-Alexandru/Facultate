class Validators:
    def validateApple(self, apple):
        if apple