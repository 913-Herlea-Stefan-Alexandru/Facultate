from random import randint
from Domain.Apple import Apple
from Erorrs.Exceptions import DirectionError


class Game:

    def __init__(self, board):
        self.__board = board
        self.__game_state = "playing"
        self.place_snake()
        self.place_apples()

    def place_snake(self):
        self.__board.init_snake()

    def place_apples(self):
        apple_count = self.__board.get_apple_count()
        for i in range(1, apple_count):
            self.place_random_apple()

    def place_random_apple(self):
        random_x = randint(0, self.__board.get_dim())
        random_y = randint(0, self.__board.get_dim())
        new_apple = Apple((random_x, random_y))
        apples = self.__board.get_apples()
        while new_apple not in apples and not self.__board.get_snake().in_snake_coordinates((random_x,random_y)):
            random_x = randint(0, self.__board.get_dim())
            random_y = randint(0, self.__board.get_dim())
            new_apple = Apple((random_x, random_y))
        self.__board.add_apple(new_apple)

    def snake_move(self):
        direction = self.__board.get_direction()
        head = self.__board.get_snake_head()
        if direction == "up":
            new_position = (head[0] - 1, head[1])
        elif direction == "down":
            new_position = (head[0] + 1, head[1])
        elif direction == "right":
            new_position = (head[0], head[1] + 1)
        elif direction == "left":
            new_position = (head[0], head[1] - 1)

        if new_position[0] > self.__board.get_dim() or new_position[0] < 0:
            self.game_over()
            return
        elif new_position[1] > self.__board.get_dim() or new_position[1] < 0:
            self.game_over()
            return

        snake_positions = self.__board.get_snake_coord()
        tail = snake_positions[:-1]
        snake_positions = snake_positions[:-1]
        if new_position in snake_positions:
            self.game_over()
            return

        new_positions = list()
        new_positions.append(new_position)
        new_positions.extend(snake_positions)
        new_positions.append(tail)
        self.__board.set_new_snake_coord(new_positions)
        self.__board.set_new_head(new_position)

    def set_direction(self, direction):
        current_direction = self.__board.get_direction()
        if direction == "up" and current_direction == "down":
            raise DirectionError("You can't do a 180!")
        elif direction == "down" and current_direction == "up":
            raise DirectionError("You can't do a 180!")
        elif direction == "right" and current_direction == "left":
            raise DirectionError("You can't do a 180!")
        elif direction == "left" and current_direction == "right":
            raise DirectionError("You can't do a 180!")

        self.__board.set_direction(direction)

    def game_over(self):
        self.__game_state = "over"

    def get_game_state(self):
        return self.__game_state

    def get_board(self):
        return self.__board
