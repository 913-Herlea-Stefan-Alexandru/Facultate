class Settings:
    def __init__(self, file_name):
        self.__file_name = file_name
        self.__DIM = None
        self.__apple_count = None

    def read_settings(self):
        try:
            file = open(self.__file_name, "r")

            for i in range(2):
                line = file.readline().strip()
                line = line.split("=")
                if line[0].strip() == "DIM":
                    self.__DIM = int(line[1].strip())
                elif line[0].strip() == "apple_count":
                    self.__apple_count = int(line[1].strip())

            file.close()
        except IOError as ioe:
            raise IOError(ioe)

    def get_settings(self):
        self.read_settings()
        return [self.__DIM, self.__apple_count]
