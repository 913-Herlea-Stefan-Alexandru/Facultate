from src.errors.custom_errors import UserInputError, EndOfGameError


class SnakeUI:
    def __init__(self, game):
        self._game = game

    def process_command(self, split_user_command):
        if len(split_user_command) == 1 and split_user_command[0] == 'move':
            self._game.move_forward_n_times(1)

        elif len(split_user_command) == 2 and split_user_command[0] == 'move':
            try:
                self._game.move_forward_n_times(int(split_user_command[1]))
            except ValueError:
                raise UserInputError("The snake can only move forward by a positive number of tiles!")

        elif len(split_user_command) == 1:
            # Assume the command is a move direction command
            self._game.change_direction_of_snake(split_user_command[0])

        else:
            raise UserInputError("That's not a valid command!")

    def input_user_command(self):
        correct_command_entered = False
        while not correct_command_entered:
            correct_command_entered = True
            user_command = input(">>>")
            split_command = user_command.split()
            try:
                self.process_command(split_command)
            except UserInputError as uie:

                print("Error: " + str(uie) + "\nTry again:\n")
                correct_command_entered = False

    def run(self):
        game_over = False
        while not game_over:
            print(self._game)
            try:
                self.input_user_command()
            except EndOfGameError as ege:
                print("Game Over: " + str(ege))
                game_over = True
