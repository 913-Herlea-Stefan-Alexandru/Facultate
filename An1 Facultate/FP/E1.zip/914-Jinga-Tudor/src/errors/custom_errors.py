class EndOfGameError(Exception):
    pass


class UserInputError(Exception):
    pass
