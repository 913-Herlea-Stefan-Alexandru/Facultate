from src.settings.settings import Settings
from src.start.application import Application

if __name__ == "__main__":
    settings = Settings("settings.txt")
    app = Application(settings)
    app.run()
