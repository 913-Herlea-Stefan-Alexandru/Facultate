from src.service.game import Game
from src.ui.snake_ui import SnakeUI


class Application:
    def __init__(self, settings):
        self._settings = settings
        self._game = Game(self._settings.dim, self._settings.apple_count)
        self._ui = SnakeUI(self._game)

    def run(self):
        self._ui.run()
