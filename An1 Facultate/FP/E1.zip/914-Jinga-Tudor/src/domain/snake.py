class Snake:
    def __init__(self, head_line, head_column):
        head = (head_line, head_column)
        middle = (head_line + 1, head_column)
        tail = (head_line + 2, head_column)
        self.body = [tail, middle, head]
        self.direction = 0  # 0 is up, 1 is right, 2 is down, 3 is left

    def move_the_head(self, new_head_line, new_head_column, snake_grows):
        self.body.append((new_head_line, new_head_column))
        if not snake_grows:
            del self.body[0]

    def tail_position_as_a_tuple(self):
        return self.body[0]

    @property
    def head_line(self):
        return self.body[-1][0]

    @property
    def head_column(self):
        return self.body[-1][1]
