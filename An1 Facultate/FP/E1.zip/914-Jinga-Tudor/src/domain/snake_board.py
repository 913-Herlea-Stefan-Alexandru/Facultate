from random import randint

from texttable import Texttable

from src.errors.custom_errors import EndOfGameError


class Board:
    line_displacement = [-1, 0, +1, 0]
    column_displacement = [0, +1, 0, -1]

    @staticmethod
    def _generate_line(size):
        new_line = []
        for i in range(size):
            new_line.append(' ')  # Space characters represent empty spaces on the board
        return new_line

    def __init__(self, size, apple_count, snake):
        self._size = size
        self._apple_count = apple_count
        self._snake = snake

        self._board = []
        for i in range(size):
            self._board.append(Board._generate_line(size))

        self._board[self._snake.head_line + 1][self._snake.head_column] = '+'  # The mid point of the board
        self._board[self._snake.head_line + 2][self._snake.head_column] = '+'  # The tail
        self._board[self._snake.head_line][self._snake.head_column] = '*'  # The head
        for i in range(apple_count):
            self._place_apple()

    def _place_apple(self):
        not_placed_yet = True
        try_count = self._size * self._size * 10
        while not_placed_yet and try_count > 0:
            i = randint(0, self._size-1)
            j = randint(0, self._size-1)

            condition1 = (self._board[i][j] == ' ')
            condition2 = (i == 0 or self._board[i-1][j] != '.')
            condition3 = (i == self._size - 1 or self._board[i+1][j] != '.')
            condition4 = (j == 0 or self._board[i][j-1] != '.')
            condition5 = (j == self._size - 1 or self._board[i][j+1] != '.')
            if condition1 and condition2 and condition3 and condition4 and condition5:
                self._board[i][j] = '.'
                not_placed_yet = False
            try_count -= 1

    def __str__(self):
        board_text_table = Texttable()
        for line in self._board:
            board_text_table.add_row(line)
        return board_text_table.draw()

    def _validate_line_or_column(self, line_or_column):
        return 0 <= line_or_column < self._size

    def move_snake_forward(self):
        # When the snake moves forward, the head must move to either an empty tile or a til with an apple
        # If it leaves the board or hits itself, the board should "crash"
        line_to_move_to = self._snake.head_line + Board.line_displacement[self._snake.direction]
        column_to_move_to = self._snake.head_column + Board.column_displacement[self._snake.direction]

        if not self._validate_line_or_column(line_to_move_to) or not self._validate_line_or_column(column_to_move_to):
            # Snake goes outside of the board
            raise EndOfGameError("The snake has hit a wall")

        tail_end_position = self._snake.body[0]
        to_move_position = (line_to_move_to, column_to_move_to)
        if self._board[line_to_move_to][column_to_move_to] == '+' and tail_end_position != to_move_position:
            # Snake hits itself
            raise EndOfGameError("The snake has hit its tail")

        ate_an_apple = (self._board[line_to_move_to][column_to_move_to] == '.')

        # Update the board:
        if not ate_an_apple:
            tail_tuple = self._snake.tail_position_as_a_tuple()
            self._board[tail_tuple[0]][tail_tuple[1]] = ' '
        self._board[self._snake.head_line][self._snake.head_column] = '+'
        self._board[line_to_move_to][column_to_move_to] = '*'
        if ate_an_apple:
            self._place_apple()

        # Update the snake:
        self._snake.move_the_head(line_to_move_to, column_to_move_to, ate_an_apple)
