from src.domain.snake import Snake
from src.domain.snake_board import Board
from src.errors.custom_errors import UserInputError


class Game:
    def __init__(self, size, apple_count):
        self._snake = Snake(size // 2 - 1, size // 2)
        self._board = Board(size, apple_count, self._snake)

    def __str__(self):
        return str(self._board)

    directions = {'up': 0, 'right': 1, 'down': 2, 'left': 3}

    def change_direction_of_snake(self, direction_as_a_string):
        try:
            new_direction = Game.directions[direction_as_a_string]
            directions = (self._snake.direction, new_direction)
            if directions in [(0, 2), (1, 3), (2, 0), (3, 1)]:
                raise UserInputError("The snake cannot rotate 180 degrees!")
            if new_direction == self._snake.direction:
                return

            self._snake.direction = new_direction
            self._board.move_snake_forward()

        except KeyError:
            raise UserInputError("That's not a valid command!")

    def move_forward_n_times(self, times):
        if times < 1:
            raise UserInputError("The snake can only move forward by a positive number of tiles!")
        for i in range(times):
            self._board.move_snake_forward()
