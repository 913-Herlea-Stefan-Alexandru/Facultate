class Settings:
    def __init__(self, settings_file):
        self._file = settings_file
        with open(self._file, "r") as input_file:
            lines = []
            for line in input_file:
                lines.append(line)

            split_dim_line = lines[0].split()
            self._dim = int(split_dim_line[2])

            split_apple_count_line = lines[1].split()
            self._apple_count = int(split_apple_count_line[2])

    @property
    def dim(self):
        return self._dim

    @property
    def apple_count(self):
        return self._apple_count
