from domain.board import Board

class Service:

    def __init__(self, dim_, apples_):
        """
        Service constructor method.
        Sets initial direction to up.

        @param: - dim_ - Size of square board.
                  apples_ - No. of apples that need to be placed on the board. 
        """
        self._board = Board(dim_, apples_)
        self._direction = 'up'
        self._length = 3
    

    def get_drawable(self):
        """ 
        Service function that returns the whole string representaton of
        the board.
        """
        return str(self._board)


    def change_direction(self, direction_):
        """
        Direction changing service method.

        Raises DirectionException if a 180 degree turn is performed.

        If no exception is raised, the direction attribute is being changed
        to the one given as parameter.

        @param: direction_ - The given direction, it is assured by UI it can be
                             only 'up', 'left', 'down' or 'right'.
        
        @return: -
        """
        if self._direction == 'up' and direction_ == 'down':
            raise DirectionException("Invalid direction!")

        if self._direction == 'left' and direction_ == 'right':
            raise DirectionException("Invalid direction!")

        if self._direction == 'down' and direction_ == 'up':
            raise DirectionException("Invalid direction!")

        if self._direction == 'right' and direction_ == 'left':
            raise DirectionException("Invalid direction!")

        self._direction = direction_


    def move_n(self, number_of_cells):
        """
        Service function for the 'move [n]' command.

        Moves the snake upwards only, but if an apple is within the 
        trajectory, the snake size does increase.

        Moves the snake characters upwards one by one and deletes
        the bottom one, and checks whether there is '.' above '*',
        in that case no deletion of bottom '+' is required.

        @param: number_of_cells - The number of cells the snake needs to move
                                  in the current direction. Type: int
        
        Complexity: O(n)
        """

        for i in range(number_of_cells):

            apple = False
            x, y = self._board.head_coord()

            
            if x == 0:
                raise GameOverException('Game Over!')
            

            if self._board.get_cell(x-1, y) == '.':
                apple = True

            x -= 1

            self._board.set_cell(x, y, '*')
            for i in range(1, 1+self._length):
                self._board.set_cell(x+i, y, '+')

            if not apple:
                self._board.set_cell(x+self._length, y, chr(0))
            
            else:
                self._length += 1


class GameOverException(Exception):
    pass

class DirectionException(Exception):
    pass