from texttable import Texttable
import random
class Board:

    def __init__(self, dim_, apples_):
        """
        Constructor for Board class.
        
        Generates initial matrix upon instantiation.

        @param: dim_ - Size of square board.
                apples_ - No. of apples that need to be placed on the board. 
        """
        self._dim = dim_
        self._apples = apples_
        self._matrix = [[chr(0) for i in range(dim_)] for j in range(dim_)]
        self.generate_matrix()
        

    def generate_matrix(self):
        """
        Inital matrix generation method.

        Generates initial matrix:
            - Snake put in middle, '*' for head, '+' for segments.
            - Apples put randomly, no overlapping with snake and no adjacency on row and column.
        
        Complexity: BC - O(1)
                    AC - O(1)
                    WC - O(infinity)
        """

        self._matrix[int(self._dim/2)-1][int(self._dim/2)] = '*'
        self._matrix[int(self._dim/2)][int(self._dim/2)] = '+'
        self._matrix[int(self._dim/2)+1][int(self._dim/2)] = '+'

        count = 0
        while count < self._apples:
            x = random.randint(0, self._dim-2)
            y = random.randint(0, self._dim-2)

            if self._matrix[x][y] == chr(0) and self._matrix[x-1][y] == chr(0) and self._matrix[x+1][y] == chr(0) and self._matrix[x][y+1] == chr(0) and self._matrix[x][y-1] == chr(0):
                self._matrix[x][y] = '.'
                count += 1


    def set_cell(self, x, y, char):
        """
        Method that modifies a cell in the matrix at the given coordinates.
        with a given value.
        """
        self._matrix[x][y] = char


    def get_cell(self, x, y):
        """
        Method that returns the value at a given cell in the matrix.
        """
        return self._matrix[x][y]


    def head_coord(self):
        """
        Method that returns the coordinates of the head ('*' character).
        """
        for i in range(self._dim):
            for j in range(self._dim):
                if self._matrix[i][j] == '*':
                    return i, j
    

    def __str__(self):
        """
        str() operator overriding method.
        Returns the bidimensional list in a printable form via the Texttable class.
        The values of the bidimensional list are being placed in a table-like whole string.

        @param: - 
        @return: The bidimensional list in the printable format described above.
        """
        table = Texttable()
        _header = ['X' for i in range(self._dim)]
        table.header(_header)
        for i in range(self._dim):
            table.add_row(self._matrix[i][:])
        
        
        return table.draw()