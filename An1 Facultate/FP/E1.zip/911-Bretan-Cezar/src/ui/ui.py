from service.service import *
import os

class UI:

    def __init__(self):
        """
        Constructor for UI class.

        Reads the settings file, and extracts the size of the table
        and the number of apples needed to be put on it.

        Afterwards, a Service instance is made, with these two parameters.
        """
        
        file_ = open("settings.properties", "rt")

        line = file_.readline()
        dim_ = int(line.split('=', 1)[1])

        line = file_.readline()
        apples_ = int(line.split(' = ', 1)[1])

        file_.close()
        self._service = Service(dim_, apples_)


    def move_n_ui(self, number_of_cells):
        """
        UI function for 'move [n]' command.

        @param: number_of_cells

        """

        if number_of_cells == '':
            
            number_of_cells = 1

        else:

            if not number_of_cells.isdecimal():
                raise ValueError("Invalid cell number!")
            number_of_cells = int(number_of_cells)

        self._service.move_n(number_of_cells)


    def print_board(self):
        """
        UI function for board displaying.
        """
        
        print(self._service.get_drawable())


    def start(self):

        os.system('cls')

        self.print_board()
        done = False

        while not done:

            command = input("Snake>> ").strip()

            if command != 'move' and command != 'up' and command != 'left' and command != 'right' and command != 'down' and command != '':
                comm_word, comm_param = command.split(' ', 1)
            
            else:
                comm_word = command
                comm_param = ''

            if comm_word.strip() == 'move':

                try:
                    
                    self.move_n_ui(comm_param.strip())
                    os.system('cls')
                    self.print_board()

                except GameOverException as goe:

                    print(str(goe))
                    done = True

                except ValueError as ve:
                    print(str(ve))
            
            elif comm_word == 'up' or comm_word == 'left' or comm_word == 'right' or comm_word == 'down':
                
                valid = False
                while not valid:

                    try:
                        self._service.change_direction(comm_word)
                        valid = True
                    except DirectionException as de:
                        print(str(de))
                        comm_word = input("Snake>> ")
   
            else:
                print("Invalid command!")

    