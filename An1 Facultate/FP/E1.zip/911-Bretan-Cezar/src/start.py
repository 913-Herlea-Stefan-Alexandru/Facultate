from ui.ui import UI

ui = UI()
ui.start()