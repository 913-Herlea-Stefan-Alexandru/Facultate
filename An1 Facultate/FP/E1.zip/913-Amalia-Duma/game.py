from board import Board


class Game:
    def __init__(self):
        self._game = Board()

    def place_s(self):
        self._game.place_s()

    def place_a(self):
        self._game.place_a()

    def show(self):
        return self._game.show()

    def move(self):
        return self._game.move()

    def move_sq(self, n):
        return self._game.move_sq(n)

    def change_dir(self, value):
        return self._game.change_dir(value)
