from game import Game


class Ui:
    def __init__(self):
        self._game = Game()

    def start(self):
        self._game.place_s()
        self._game.place_a()
        print(self._game.show())
        done = False
        while not done:
            com = input('-> ')
            command, param = self.split_c(com)
            try:
                if command == 'move' and param == '':
                    mov = self._game.move()
                    if mov == 0:
                        print('Game over :(')
                        done = True
                    else:
                        print(self._game.show())
                elif command == 'move' and param != '':
                    mov = self._game.move_sq(int(param))
                    if mov == 0:
                        print('Game over :(')
                        done = True
                    else:
                        print(self._game.show())
                elif command == 'right' and param == '':
                    mov = self._game.change_dir(command)
                    if mov == 0:
                        print('Game over :(')
                        done = True
                    else:
                        print(self._game.show())
                elif command == 'up' and param == '':
                    mov = self._game.change_dir(command)
                    if mov == 0:
                        print('Game over :(')
                        done = True
                    else:
                        print(self._game.show())
                elif command == 'down' and param == '':
                    mov = self._game.change_dir(command)
                    if mov == 0:
                        print('Game over :(')
                        done = True
                    else:
                        print(self._game.show())
                elif command == 'left' and param == '':
                    mov = self._game.change_dir(command)
                    if mov == 0:
                        print('Game over :(')
                        done = True
                    else:
                        print(self._game.show())
                else:
                    print('Bad command')
            except Exception as ex:
                print(ex)

    def split_c(self, com):
        arg = com.strip().split(' ')
        comm = arg[0].lower().strip()
        param = arg[1] if len(arg) == 2 else ''
        return comm, param


a = Ui()
a.start()
