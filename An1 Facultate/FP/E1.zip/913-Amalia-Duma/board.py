from random import randint

from texttable import Texttable


class Board:
    def __init__(self):
        self._file = 'settings.txt'
        self._dim = 0
        self._apples = 0
        self.read_f()
        self._data = [[0 for j in range(self._dim)] for i in range(self._dim)]
        self._dir = 'up'

    def read_f(self):
        try:
            f = open(self._file, 'r')
        except IOError:
            raise Exception('Input file not found')

        line = f.readline().strip()
        attrs = line.split(";")
        self._dim = int(attrs[0])
        self._apples = int(attrs[1])
        f.close()

    def place_one_apple(self):
        i = 0
        while i <= 1:
            x = randint(0, self._dim)
            y = randint(0, self._dim)
            try:
                if (self._data[x][y] == '+') or (self._data[x][y] == '*'):
                    continue
                if (self._data[x + 1][y] == '.') or (self._data[x - 1][y] == '.') \
                        or (self._data[x][y + 1] == '.') or (self._data[x][y - 1] == '.'):
                    continue
                if self._data[x][y] == '.':
                    continue
                self._data[x][y] = '.'
                i += 1
            except:
                continue

    def move_sq(self, n):
        if self.check_lose() == 0:
            return 0
        if self._dir == 'up':
            head = self.get_head()
            tail = self.get_tail()
            if head[0] - n < 0:
                raise ValueError('Cannot move to that.')
            x = head[0]
            y = head[1]
            if self._data[x - n][y] == '.':
                self._data[x- n][y] = '*'
                for i in range(0, len(tail)):
                    self._data[x-1][y] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                self.place_one_apple()
                i = len(tail) - 1
                nr = 0
                while nr <= n-1:
                    x = tail[i][0]
                    y = tail[i][1]
                    self._data[x][y] = 0
                    nr += 1
                    i -= 1
            else:
                self._data[x- n][y] = '*'
                for i in range(0, len(tail)):
                    self._data[x-1][y] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                i = len(tail)-1
                nr = 0
                while nr <= n:
                    x = tail[i][0]
                    y = tail[i][1]
                    self._data[x][y] = 0
                    nr += 1
                    i -= 1
        if self._dir == 'left':
            head = self.get_head()
            tail = self.get_tail()
            if head[0] - n < 0:
                raise ValueError('Cannot move to that.')
            x = head[0]
            y = head[1]
            if self._data[x][y-n] == '.':
                self._data[x][y-n] = '*'
                for i in range(0, len(tail)):
                    self._data[x][y-1] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                self.place_one_apple()
                i = len(tail) - 1
                nr = 0
                while nr <= n-1:
                    x = tail[i][0]
                    y = tail[i][1]
                    self._data[x][y] = 0
                    nr += 1
                    i -= 1
            else:
                self._data[x][y-n] = '*'
                for i in range(0, len(tail)):
                    self._data[x][y-1] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                i = len(tail)-1
                nr = 0
                while nr <= n:
                    x = tail[i][0]
                    y = tail[i][1]
                    self._data[x][y] = 0
                    nr += 1
                    i -= 1
        if self._dir == 'right':
            head = self.get_head()
            tail = self.get_tail()
            if head[0] + n > self._dim:
                raise ValueError('Cannot move to that.')
            x = head[0]
            y = head[1]
            if self._data[x][y+n] == '.':
                self._data[x][y+n] = '*'
                for i in range(0, len(tail)):
                    self._data[x][y+1] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                self.place_one_apple()
                i = len(tail) - 1
                nr = 0
                while nr <= n-1:
                    x = tail[i][0]
                    y = tail[i][1]
                    self._data[x][y] = 0
                    nr += 1
                    i -= 1
            else:
                self._data[x][y+n] = '*'
                for i in range(0, len(tail)):
                    self._data[x][y+1] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                i = len(tail)-1
                nr = 0
                while nr <= n:
                    x = tail[i][0]
                    y = tail[i][1]
                    self._data[x][y] = 0
                    nr += 1
                    i -= 1
        if self._dir == 'down':
            head = self.get_head()
            tail = self.get_tail()
            if head[0] + n > self._dim:
                raise ValueError('Cannot move to that.')
            x = head[0]
            y = head[1]
            if self._data[x + n][y] == '.':
                self._data[x+ n][y] = '*'
                for i in range(0, len(tail)):
                    self._data[x+1][y] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                self.place_one_apple()
                i = len(tail) - 1
                nr = 0
                while nr <= n-1:
                    x = tail[i][0]
                    y = tail[i][1]
                    self._data[x][y] = 0
                    nr += 1
                    i -= 1
            else:
                self._data[x+ n][y] = '*'
                for i in range(0, len(tail)):
                    self._data[x+1][y] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                i = len(tail)-1
                nr = 0
                while nr <= n:
                    x = tail[i][0]
                    y = tail[i][1]
                    self._data[x][y] = 0
                    nr += 1
                    i -= 1
        return 1

    def change_dir(self, value):
        if value == 'down' and self._dir == 'up':
            raise ValueError('Invalid direction')
        if value == 'up' and self._dir == 'down':
            raise ValueError('Invalid direction')
        self._dir = value
        return self.move()

    def move(self):
        if self.check_lose() == 0:
            return 0
        if self._dir == 'up':
            head = self.get_head()
            tail = self.get_tail()
            x = head[0]
            y = head[1]
            if self._data[x-1][y] == '.':
                self._data[x-1][y] = '*'
                for i in range(0, len(tail)):
                    self._data[x][y] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                self._data[x][y] = '+'
                self.place_one_apple()
            else:
                self._data[x-1][y] = '*'
                for i in range(0, len(tail)):
                    self._data[x][y] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                self._data[x][y] = 0
        elif self._dir == 'right':
            head = self.get_head()
            tail = self.get_tail()
            x = head[0]
            y = head[1]
            if self._data[x][y+1] == '.':
                self._data[x][y + 1] = '*'
                for i in range(0, len(tail)):
                    self._data[x][y] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                self._data[x][y] = '+'
                self.place_one_apple()
            else:
                self._data[x][y+1] = '*'
                for i in range(0, len(tail)):
                    self._data[x][y] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                self._data[x][y] = 0
        elif self._dir == 'down':
            head = self.get_head()
            tail = self.get_tail()
            x = head[0]
            y = head[1]
            if self._data[x+1][y] == '.':
                self._data[x+1][y] = '*'
                for i in range(0, len(tail)):
                    self._data[x][y] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                self._data[x][y] = '+'
                self.place_one_apple()
            else:
                self._data[x+1][y] = '*'
                for i in range(0, len(tail)):
                    self._data[x][y] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                self._data[x][y] = 0
        elif self._dir == 'left':
            head = self.get_head()
            tail = self.get_tail()
            x = head[0]
            y = head[1]
            if self._data[x][y-1] == '.':
                self._data[x][y-1] = '*'
                for i in range(0, len(tail)):
                    self._data[x][y] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                self._data[x][y] = '+'
                self.place_one_apple()
            else:
                self._data[x][y-1] = '*'
                for i in range(0, len(tail)):
                    self._data[x][y] = '+'
                    x = tail[i][0]
                    y = tail[i][1]
                self._data[x][y] = 0
        return 1


    def check_lose(self):
        if self._dir == 'up':
            head = self.get_head()
            if head[0] == 0:
                return 0
            else:
                x = head[0]
                if self._data[x-1] == '+':
                    return 0
        elif self._dir == 'right':
            head = self.get_head()
            if head[1] == 6:
                return 0
            else:
                y = head[1]
                if self._data[y+1] == '+':
                    return 0
        elif self._dir == 'left':
            head = self.get_head()
            if head[1] == 0:
                return 0
            else:
                x = head[0]
                y = head[1]
                if self._data[x][y-1] == '+':
                    return 0
        elif self._dir == 'down':
            head = self.get_head()
            if head[0] == 6:
                return 0
            else:
                x = head[0]
                if self._data[x+1] == '+':
                    return 0
        return 1


    def get_head(self):
        head = []
        for i in range(0, self._dim):
            for j in range(0, self._dim):
                if self._data[i][j] == '*':
                    head.append(i)
                    head.append(j)
                    break
        return head

    def get_tail(self):
        tail = []
        for i in range(0, self._dim):
            for j in range(0, self._dim):
                if self._data[i][j] == '+':
                    tail.append([i,j])
        return tail

    def place_s(self):
        middle = self._dim // 2
        self._data[middle-1][middle] = '*'
        self._data[middle][middle] = '+'
        self._data[middle+1][middle] = '+'

    def place_a(self):
        i = 0
        while i <= self._apples:
            x = randint(0, self._dim)
            y = randint(0, self._dim)
            try:
                if (self._data[x][y] == '+') or (self._data[x][y] == '*'):
                    continue
                if (self._data[x+1][y] == '.') or (self._data[x-1][y] == '.') \
                        or (self._data[x][y+1] == '.') or (self._data[x][y-1] == '.'):
                    continue
                if self._data[x][y] == '.':
                    continue
                self._data[x][y] = '.'
                i += 1
            except:
                continue

    def show(self):
        t = Texttable()
        header = [' ']
        for i in range(0, self._dim):
            header.append(str(i))

        t.header(header)
        for row in range(0, self._dim):
            data = [str(row)]
            for item in self._data[row]:
                if item == '+' or item == '*' or item == '.':
                    data.append(item)
                elif item == 0:
                    data.append('')
            t.add_row(data)
        return t.draw()


