import configparser


class Settings:
    def __init__(self):
        self.config = configparser.RawConfigParser()
        self.initiate()
        self.dim = self.config.get('RepositorySection', 'DIM')
        self.apple_count = self.config.get('RepositorySection', 'apple_count')

    def initiate(self):
        self.config.read('settings.properties')
