import copy

from termcolor import colored
import random
from prettytable import PrettyTable


class GameService:
    def __init__(self, dim, apple_count):
        self.dim = dim
        self.apple_count = apple_count
        self.apples_placed = []
        self.board = [[0 for j in range(self.dim)] for i in range(self.dim)]
        self.apples_remained = 3
        self.snake_positions = []
        self.snake_head = []
        self.snake_tail = []
        self.direction = 0
        self.last_direction = 0

    def change_direction(self, direction):
        if direction == 0 and self.last_direction == 1:
            return False
        elif direction == 1 and self.last_direction == 0:
            return False
        elif direction == 2 and self.last_direction == 3:
            return False
        elif direction == 3 and self.last_direction == 2:
            return False
        self.direction = direction
        self.last_direction = self.direction

    def start_game(self):
        self.snake_head = [self.dim // 2 - 1, self.dim // 2]
        snake_head = self.snake_head
        self.board[snake_head[0]][snake_head[1]] = 2
        first_body = [self.dim // 2, self.dim // 2]
        self.board[first_body[0]][first_body[1]] = 1
        second_body = [self.dim // 2 + 1, self.dim // 2]
        self.board[second_body[0]][second_body[1]] = 1
        self.snake_positions.append(second_body)
        self.snake_positions.append(first_body)
        self.snake_positions.append(snake_head)
        self.snake_tail = second_body

        apples_placed = 0
        while apples_placed < self.apple_count:
            free_spots = self.free_spots()
            coords = random.choice(free_spots)
            if coords[0] == 0 and coords[1] == 0:
                if self.board[coords[0]][coords[1] + 1] == self.board[coords[0] + 1][coords[1]] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1

            elif coords[0] == self.dim - 1 and coords[1] == self.dim - 1:
                if self.board[coords[0]][coords[1] - 1] == self.board[coords[0] - 1][coords[1]] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1
            elif coords[0] == 0 and coords[1] == self.dim - 1:
                if self.board[coords[0] + 1][coords[1]] == self.board[coords[0] - 1][coords[1]] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1
            elif coords[0] == self.dim - 1 and coords[1] == 0:
                if self.board[coords[0] - 1][coords[1]] == self.board[coords[0]][coords[1] + 1] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1
            elif coords[0] == 0:
                if self.board[coords[0] - 1][coords[1]] == self.board[coords[0] + 1][coords[1]] == \
                        self.board[coords[0]][coords[1] + 1] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1
            elif coords[1] == 0:
                if self.board[coords[0]][coords[1] - 1] == self.board[coords[0]][coords[1] + 1] == \
                        self.board[coords[0] + 1][coords[1]] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1
            elif coords[0] == self.dim - 1:
                if self.board[coords[0]][coords[1] - 1] == self.board[coords[0]][coords[1] + 1] == \
                        self.board[coords[0] - 1][coords[1]] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1
            elif coords[1] == self.dim - 1:
                if self.board[coords[0]][coords[1] - 1] == self.board[coords[0] - 1][coords[1]] == \
                        self.board[coords[0] + 1][coords[1]] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1
            elif self.board[coords[0] - 1][coords[1]] == 0 and self.board[coords[0] + 1][coords[1]] == 0 and \
                    self.board[coords[0]][coords[1] - 1] == 0 and self.board[coords[0]][coords[1] + 1] == 0:
                self.board[coords[0]][coords[1]] = -1
                apples_placed += 1

        self.print_board()


    def add_new_apple(self):
        apples_placed = 0
        while apples_placed < 1:
            free_spots = self.free_spots()
            coords = random.choice(free_spots)
            if coords[0] == 0 and coords[1] == 0:
                if self.board[coords[0]][coords[1] + 1] == self.board[coords[0] + 1][coords[1]] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1

            elif coords[0] == self.dim - 1 and coords[1] == self.dim - 1:
                if self.board[coords[0]][coords[1] - 1] == self.board[coords[0] - 1][coords[1]] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1
            elif coords[0] == 0 and coords[1] == self.dim - 1:
                if self.board[coords[0] + 1][coords[1]] == self.board[coords[0] - 1][coords[1]] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1
            elif coords[0] == self.dim - 1 and coords[1] == 0:
                if self.board[coords[0] - 1][coords[1]] == self.board[coords[0]][coords[1] + 1] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1
            elif coords[0] == 0:
                if self.board[coords[0] - 1][coords[1]] == self.board[coords[0] + 1][coords[1]] == \
                        self.board[coords[0]][coords[1] + 1] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1
            elif coords[1] == 0:
                if self.board[coords[0]][coords[1] - 1] == self.board[coords[0]][coords[1] + 1] == \
                        self.board[coords[0] + 1][coords[1]] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1
            elif coords[0] == self.dim - 1:
                if self.board[coords[0]][coords[1] - 1] == self.board[coords[0]][coords[1] + 1] == \
                        self.board[coords[0] - 1][coords[1]] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1
            elif coords[1] == self.dim - 1:
                if self.board[coords[0]][coords[1] - 1] == self.board[coords[0] - 1][coords[1]] == \
                        self.board[coords[0] + 1][coords[1]] == 0:
                    self.board[coords[0]][coords[1]] = -1
                    apples_placed += 1
            elif self.board[coords[0] - 1][coords[1]] == 0 and self.board[coords[0] + 1][coords[1]] == 0 and \
                    self.board[coords[0]][coords[1] - 1] == 0 and self.board[coords[0]][coords[1] + 1] == 0:
                self.board[coords[0]][coords[1]] = -1
                apples_placed += 1

    def validate_move(self, option):
        try:
            int(option)
        except ValueError:
            return False

        if int(option) > self.dim:
            return False

        elif int(option) < 0:
            return False

        return True

    def move_more(self, number):
        for i in range(int(number)):
            if self.move_one_square() is False:
                return False
        return True

    def move_one_square(self):

        if self.direction == 0:
            if self.snake_head[0] == 0:
                return False
            elif self.board[self.snake_head[1]-1][self.snake_head[0]] == 1:
                return False

            elif self.board[self.snake_head[1]-1][self.snake_head[0]] == -1:

                x = self.snake_head[0]
                y = self.snake_head[1]
                self.board[x-1][y] = 2
                self.add_new_apple()
                self.board[self.snake_head[0]][self.snake_head[1]] = 1
                self.snake_head.clear()
                self.snake_head.append(x-1)
                self.snake_head.append(y)
                x1 = self.snake_positions[0]
                y2 = self.snake_positions[0]
                self.snake_positions[-1].clear()
                self.snake_positions[-1].append(x)
                self.snake_positions[-1].append(y-1)
                self.board[x1][y2-1] = 1
                self.snake_tail.clear()
                self.snake_tail.append(x1)
                self.snake_tail.append(y2)
            else:
                x = self.snake_head[0]
                y = self.snake_head[1]
                self.board[x-1][y] = 2
                self.board[self.snake_head[0]][self.snake_head[1]] = 1
                self.snake_head.clear()
                self.snake_head.append(x-1)
                self.snake_head.append(y)

                self.snake_positions[-1].clear()
                self.snake_positions[-1].append(x-1)
                self.snake_positions[-1].append(y)
                for i in range(1, len(self.snake_positions) - 1):
                    self.snake_positions[i].clear()
                    x3 = self.snake_positions[i+1][0]
                    x4 = self.snake_positions[i + 1][1]
                    self.snake_positions[i].append(x3)
                    self.snake_positions[i].append(x4)

                self.board[self.snake_positions[0][0]][self.snake_positions[0][1]] = 0
                del self.snake_positions[0]

        elif self.direction == 3:
            if self.snake_head[1] == 0:
                return False
            elif self.board[self.snake_head[1]-1][self.snake_head[0]] == 1:
                return False

            elif self.board[self.snake_head[1]-1][self.snake_head[0]] == -1:
                x = self.snake_head[0]
                y = self.snake_head[1]
                self.board[x][y-1] = 2
                self.add_new_apple()
                self.board[self.snake_head[0]][self.snake_head[1]] = 1
                self.snake_head.clear()
                self.snake_head.append(x-1)
                self.snake_head.append(y)
                x1 = self.snake_positions[0]
                y2 = self.snake_positions[0]
                self.snake_positions[-1].clear()
                self.snake_positions[-1].append(y-1)
                self.snake_positions[-1].append(x)
                self.board[x1][y2-1] = 1
                self.snake_tail.clear()
                self.snake_tail.append(x1)
                self.snake_tail.append(y2)
            else:
                x = self.snake_head[0]
                y = self.snake_head[1]
                self.board[x][y-1] = 2
                self.board[self.snake_head[0]][self.snake_head[1]] = 1
                self.snake_head.clear()
                self.snake_head.append(x-1)
                self.snake_head.append(y)

                self.snake_positions[-1].clear()
                self.snake_positions[-1].append(x)
                self.snake_positions[-1].append(y-1)
                for i in range(1, len(self.snake_positions) - 1):
                    self.snake_positions[i].clear()
                    self.snake_positions[i].append(self.snake_positions[i+1][0])
                    self.snake_positions[i].append(self.snake_positions[i + 1][1])

                self.board[self.snake_positions[0][0]][self.snake_positions[0][1]] = 0
                del self.snake_positions[0]


        self.print_board()



    def free_spots(self):
        free_cells = []
        for i in range(self.dim):
            for j in range(self.dim):
                if self.board[i][j] == 0:
                    free_cells.append([i, j])
        return free_cells

    def print_board(self):
        t = PrettyTable()
        string_of_letters = 'ABCDEFGHIJKLMNOPQRSTWXYZ'
        list_of_headers = []

        for i in range(self.dim):
            list_of_headers.append(colored(string_of_letters[i], 'cyan', attrs=['bold']))

        list_of_headers.append(' ')
        t.field_names = list_of_headers

        for row in range(self.dim):
            row_data = []

            for i, index in enumerate(self.board[row]):
                if index == 0:
                    row_data.append(' ')
                elif index == -1:
                    row_data.append('.')
                elif index == 2:
                    row_data.append('*')
                elif index == 1:
                    row_data.append('+')

            t.add_row(row_data + [colored(str(row), 'magenta', attrs=['bold'])])

        print(t.get_string())
