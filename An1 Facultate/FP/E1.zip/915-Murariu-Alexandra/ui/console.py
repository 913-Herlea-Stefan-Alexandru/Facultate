class UI:
    def __init__(self, game_service):
        self.game_service = game_service
        self.game_started = False

    def start(self):
        finished = False
        self.game_service.start_game()
        while finished is False:

            if self.read_command() == 0:
                finished = True

        return True

    def read_command(self):
        option_raw = input("Please input your command:\n")
        option = option_raw.split()

        if option_raw == "move":
            if self.game_service.move_one_square() is False:
                print("You lost!")
                return 0
            return


        if option_raw == "up":
            if self.game_service.change_direction(0) is False:
                print("You cannot move to 180 degrees!")
                return
            return

        if option_raw == "down":
            if self.game_service.change_direction(1) is False:
                print("You cannot move to 180 degrees!")
                return
            return

        if option_raw == "right":
            if self.game_service.change_direction(2) is False:
                print("You cannot move to 180 degrees!")
                return
            return

        if option_raw == "left":
            if self.game_service.change_direction(3) is False:
                print("You cannot move to 180 degrees!")
                return
            return

        if option[0] == "move":
            if self.game_service.validate_move(option[1]) is False:
                print("Invalid move! Please try again")
                return

            if self.game_service.move_more(option[1]) is False:
                print("You lost!")
                return 0

        else:
            print("Invalid command! Please try again..")