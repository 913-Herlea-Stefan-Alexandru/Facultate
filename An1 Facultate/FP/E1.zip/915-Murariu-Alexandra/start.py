import traceback

from service.game_service import GameService
from service.settings import Settings
from ui.console import UI

if __name__ == '__main__':
    try:
        settings = Settings()

        dim = int(settings.dim)

        apple_count = int(settings.apple_count)

        game_service = GameService(dim, apple_count)
        ui = UI(game_service)
        ui.start()

    except Exception as ex:
        print(ex)