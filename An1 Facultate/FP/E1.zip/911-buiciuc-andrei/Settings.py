from jproperties import Properties


class Settings:
    def __init__(self):
        self._configs = Properties()
        self._file_name = 'settings.properties'

        settings_file = open(self._file_name, 'rb')
        self._configs.load(settings_file)

        try:
            self._dim = self._configs.get("DIM").data
            self._apples = self._configs.get("apple_count").data
        except KeyError:
            exit(0)

    @property
    def dim(self):
        return self._dim

    @dim.setter
    def dim(self, value):
        self._dim = value

    @property
    def apples(self):
        return self._apples

    @apples.setter
    def apples(self, value):
        self._apples = value
