import random

from texttable import Texttable


class Board:
    def __init__(self, DIM, apple_count):
        self._DIM = DIM
        self._apple_count = apple_count
        self._data = [[' ' for j in range(self._DIM)] for i in range(self._DIM)]
        self.place_snake()
        self.place_apples()

    @property
    def get_dim(self):
        return self._DIM

    @property
    def get_board(self):
        return self._data

    def get_element(self, i, j):
        return self._data[i][j]

    def get_direction(self):
        head_snake = self.get_head_position()
        row = head_snake[0]
        col = head_snake[1]

        if self._data[row + 1][col] == '+':
            # up direction
            direction = 1
        elif self._data[row - 1][col] == '+':
            # down direction
            direction = 2
        elif self._data[row - 1][col] == '+':
            # right direction
            direction = 3
        else:
            direction = 4

        return direction

    def get_snake_tail(self):
        snake_tail = 0
        for i in range(self._DIM):
            for j in range(self._DIM):
                if self._data[i][j] == '+':
                    snake_tail += 1

        return snake_tail

    def get_tail_positions(self):
        positions = []
        for i in range(self._DIM):
            for j in range(self._DIM):
                if self._data[i][j] == '+':
                    positions.append([i, j])

        return positions

    def place_snake(self):
        """
        We place the snake for starting the game.
        :return:
        """
        snake_head_column = self._DIM // 2
        snake_middle_row = self._DIM // 2
        self._data[snake_middle_row - 1][snake_head_column] = '*'
        self._data[snake_middle_row][snake_head_column] = '+'
        self._data[snake_middle_row + 1][snake_head_column] = '+'

    def get_free_positions(self):
        free_positions = []
        for i in range(self._DIM):
            for j in range(self._DIM):
                if self._data[i][j] == ' ':
                    free_positions.append([i, j])

        return free_positions

    def place_apples(self):
        free_positions = self.get_free_positions()
        used_positions = []

        while self._apple_count != 0:
            apple_poz = random.choice(free_positions)
            row = apple_poz[0]
            col = apple_poz[1]
            if self._data[row][col] not in ['*', '+']:
                if apple_poz not in used_positions:
                    if (row != 0) and (col != 0) and (row != self._DIM - 1) and (col != self._DIM - 1):
                        if self._data[row - 1][col] != '.' and self._data[row + 1][col] != '.' and \
                                self._data[row][col - 1] != '.' and self._data[row][col + 1] != '.':
                            self._data[row][col] = '.'
                            used_positions.append(apple_poz)
                            self._apple_count -= 1
            # self._apple_count -= 1

    def get_head_position(self):
        for i in range(self._DIM):
            for j in range(self._DIM):
                if self._data[i][j] == '*':
                    return [i, j]

    def __str__(self):
        t = Texttable()
        for row in range(self._DIM):
            row_data = []

            for index in self._data[row]:
                row_data.append(index)
            t.add_row(row_data)

        return t.draw()
