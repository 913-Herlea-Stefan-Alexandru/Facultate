class Service:
    def __init__(self, board):
        self._board = board

    @staticmethod
    def split_command(command):
        tokens = command.strip().split(' ', 1)
        if len(tokens) == 1:
            # for start command
            tokens[0] = tokens[0].lower()
            return tokens[0], ''
        else:
            tokens[0] = tokens[0].lower()
            tokens[1] = tokens[1].lower()
            return tokens[0], '' if len(tokens) == 1 else tokens[1].strip()

    def move_snake(self, number):
        snake_head = self._board.get_head_position()
        row = snake_head[0]
        col = snake_head[1]
        direction = self._board.get_direction()
        board = self._board.get_board
        snake_raise = 0
        snake_tail = self._board.get_snake_tail()
        positions = self._board.get_tail_positions()

        if row < 0 or col < 0 or row > self._board.get_dim - 1 or col > self._board.get_dim - 1:
            return False

        while number != 0:
            board[row][col] = ' '
            if direction == 1:
                # up direction
                row = row - 1
            elif direction == 2:
                # down direction
                row = row + 1
            elif direction == 3:
                # right direction
                col = col + 1
            else:
                # left direction
                col = col - 1

            if row < 0 or col < 0 or row > self._board.get_dim - 1 or col > self._board.get_dim - 1:
                return False

            if board[row][col] == '+':
                return False

            if board[row][col] == '.':
                snake_raise += 1

            board[row][col] = '*'
            number = number - 1

        snake_tail = snake_tail + snake_raise

        # the case when the direction is 1, meaning up
        for i in range(snake_tail+1):
            board[row+1][col] = '+'
            row += 1

        cnt = 0
        for i in range(self._board.get_dim):
            if board[i][col] == '+':
                cnt = cnt + 1

            if cnt > snake_tail:
                board[i][col] = ' '
