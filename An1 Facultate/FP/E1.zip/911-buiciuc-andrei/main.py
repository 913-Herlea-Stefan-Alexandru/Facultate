from Console.UI import UI
from Domain.Board import Board
from Service.Service import Service
from Settings import Settings

settings = Settings()

DIM = int(settings.dim)
apple_count = int(settings.apples)

board = Board(DIM, apple_count)
service = Service(board)
ui = UI(board, service)
ui.start()
