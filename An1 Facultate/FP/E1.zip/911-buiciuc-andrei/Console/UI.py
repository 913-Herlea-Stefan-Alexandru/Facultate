class UI:
    def __init__(self, board, service):
        self._board = board
        self._service = service

    @staticmethod
    def welcome():
        print("Hello and welcome to Snake!")

    def split_command_ui(self, command):
        word, par = self._service.split_command(command)
        return word, par

    def move_ui(self, param):
        if param == '':
            number = 1
        else:
            number = int(param)
        cond = self._service.move_snake(number)
        if cond is False:
            print("Game Over")
            return True

        print(str(self._board))

    def up_ui(self):
        pass

    def down_ui(self):
        pass

    def right_ui(self):
        pass

    def left_ui(self):
        pass

    def start(self):
        done = False
        print(str(self._board))

        while not done:
            command = input("\nEnter a command: ")
            command_word, command_params = self.split_command_ui(command)
            if command_word in ['move', 'up', 'down', 'left', 'right']:
                try:
                    if command_word == 'move':
                        cond = self.move_ui(command_params)
                        if cond is True:
                            done = True
                    elif command_word == 'up':
                        self.up_ui()
                    elif command_word == 'down':
                        self.down_ui()
                    elif command_word == 'left':
                        self.left_ui()
                    elif command_word == 'right':
                        self.right_ui()
                except ValueError as error:
                    print(str(error))
            elif command_word == 'exit':
                done = True
            else:
                print("Bad command!")
