from board.board import Board
from service.service import Service
from ui.ui import Ui

bord=Board(5,5)

service= Service(bord)

ui = Ui(service)

ui.print_board()
ceva=bord.get_snake()
for i in ceva:
    print(i)


