import random


class Board:
    def __init__(self, dim, apple):
        self.dim = dim
        self.apple = apple
        board = []
        for i in range(dim):
            a = [['0'] * dim]
            board.append(a)
        self.board = board
        self.direction = 1
        self.snake = [[int(dim / 2 - 1), int(dim / 2)], [int(dim / 2), int(dim / 2)], [int(dim / 2 + 1), int(dim / 2)]]

    def get_board(self):
        return self.board

    def get_snake(self):
        return self.snake

    def get_direction(self):
        return self.direction

    def set_direction(self, direction):
        self.direction = direction

    def get_head_snake(self):
        return self.snake[0]

    def check_valid(self, row, collum):
        if row < 0 or row > self.dim or collum < 0 or collum > self.dim:
            return False
        if self.board[row][collum] == '.' or self.board[row][collum]:
            return True

    def check_apple(self):
        pass

    def move(self, spaces):
        dir = self.get_direction()
        head = self.get_head_snake()
        r = head[0]
        c = head[1]
        if dir == 1:
            for i in range(spaces):
                r = r - 1
                if self.check_valid(r, c):
                    self.snake.insert(0, [r, c])
                if self.check_apple(r, c) == False:
                    self.snake.pop()
        if dir == 2:
            for i in range(spaces):
                c = c + 1
                if self.check_valid(r, c):
                    self.snake.insert(0, [r, c])
                if self.check_apple(r, c) == False:
                    self.snake.pop()
        if dir == 3:
            for i in range(spaces):
                r = r + 1
                if self.check_valid(r, c):
                    self.snake.insert(0, [r, c])
                if self.check_apple(r, c) == False:
                    self.snake.pop()
        if dir == 4:
            for i in range(spaces):
                c = c - 1
                if self.check_valid(r, c):
                    self.snake.insert(0, [r, c])
                if self.check_apple(r, c) == False:
                    self.snake.pop()

    def place_apples(self):
        for i in range(self.apple):
            ok = False
            while ok is False:
                r = random.randint(0, self.dim)
                c = random.randint(0, self.dim)
                if self.board[r + 1][c] != "." and self.board[r - 1][c] != "." and \
                        self.board[r][c + 1] != "." and self.board[r][c - 1] != ".":
                    self.board[r][c] = "."
                    ok = True
