
class Ui:
    def __init__(self,service):
        self.service = service

    def print_board(self):
        board = self.service.get_player_board()
        for line in board:
            print("".join(str(line)))
        print("")