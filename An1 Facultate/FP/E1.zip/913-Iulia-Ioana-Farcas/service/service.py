
class Service:
    def __init__(self,board):
        self.board= board

    def get_player_board(self):
        return self.board.get_board()
