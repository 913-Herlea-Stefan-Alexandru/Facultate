from game.Game import Game, GameException


class Console():
    def __init__(self, game:Game):
        self.__game = game
        self.__commands = {
            "move": self.move_ui,
            "up": self.up,
            "right": self.right,
            "down": self.down,
            "left": self.left

        }
        self.done = False

    def run(self):
        while not self.done:
            try:
                self.print_board()
                cmd_line = input(">")
                cmd_line = cmd_line.strip()
                if cmd_line == "exit":
                    break
                elif cmd_line == "move":
                    self.move_ui(1)
                elif cmd_line =="up":
                    self.up()
                elif cmd_line == "right":
                    self.right()
                elif cmd_line == "down":
                    self.down()
                elif cmd_line == "left":
                    self.left()
                else:
                    cmd, args = cmd_line.split(" ", 1)
                    args = args.strip()
                    cmd = cmd.strip()
                    if cmd in self.__commands:
                        if args is not  None:
                            self.__commands[cmd](args)
            except GameException as GE:
                print(GE)
            except Exception:
                print("Bad comand!")



    def move_ui(self, step=1):
        step = int(step)
        if self.__game.move(step) == False:
            self.game_over()

    def up(self):
        if self.__game.up() == False:
            self.game_over()

    def right(self):
        if self.__game.right() == False:
            self.game_over()

    def down(self):
        if self.__game.down()== False:
            self.game_over()

    def left(self):
        if self.__game.left()== False:
            self.game_over()

    def print_board(self):
        print(self.__game.get_board())

    def game_over(self):
        print("Game over")
        self.done = True