class Settings():
    def __init__(self):
        self.__l = []
        self.read_from_file()

    def read_from_file(self):
        with open("settings.txt", "r") as f:
            lines = f.readlines()
            for line in lines:
                tokens = line.strip()
                if line != "":
                    self.__l.append(int(tokens))

    def return_value(self):
        return self.__l[0], self.__l[1]

