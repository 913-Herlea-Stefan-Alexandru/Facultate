from Settings.Settings import Settings
from UI.console import Console
from board.Board import Board
from game.Game import Game

settings = Settings()
dim, count_apple = settings.return_value()
board = Board(dim, count_apple)
game = Game(board)
console = Console(game)
console.run()