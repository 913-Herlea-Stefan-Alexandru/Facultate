"""
The ui console class
"""
from domain.Board import BoardException
from repository import GameRepository
from repository.GameRepository import GameRepositoryException
from service import GameService


class ConsoleUI:

    def __init__(self, gameService: GameService, gameRepository: GameRepository):
        self._gameService = gameService
        self._gameRepository = gameRepository

    def start(self):
        command_dict = {"right": self.move_right, "left": self.move_left, "up": self.move_up,
                        "down": self.move_down, "move": 0}

        print("Python snake game\n")
        self._gameService.create_board()
        self.print_board()

        game_over = False
        while not game_over:
            command, value = self.get_command()
            if command not in command_dict:
                print("Bad command!")
            if command == "move" and value is None:
                print("Bad command!")
            try:
                if command == 'move':
                    self.move_n_pos(value)
                else:
                    command_dict[command]()
                self.print_board()
            except BoardException:
                game_over = True
            except GameRepositoryException:
                game_over = True
            except Exception as ex:
                print(ex)
        print("Game Over!")

    def get_command(self):
        command = input("The command: ")
        command.strip()

        tokens = command.split(' ')
        if len(tokens) == 1:
            return tokens[0], None
        else:
            return tokens[0], tokens[1]

    def print_board(self):
        print(self._gameService.get_board())

    def move_right(self):
        self._gameService.move_snake_right()

    def move_left(self):
        self._gameService.move_snake_left()

    def move_up(self):
        self._gameService.move_snake_up()

    def move_down(self):
        self._gameService.move_snake_down()

    def move_n_pos(self, number):
        self._gameService.move_snake_n_pos(int(number))
