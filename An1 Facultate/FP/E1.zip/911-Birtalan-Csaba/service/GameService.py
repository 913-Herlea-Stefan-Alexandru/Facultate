"""
Game service class
"""
from repository.GameRepository import GameRepository


class GameService:

    def __init__(self, gameRepository: GameRepository):
        self._gameRepository = gameRepository

    def create_board(self):
        """
        Create the board at the beginning if the game
        :return: -
        """
        self._gameRepository.create_board()

    def get_board(self):
        """
        Gets the board
        :return: The board object
        """
        return self._gameRepository.get_board()

    def move_snake_right(self):
        """
        Move the snake to the right
        :return: -
        """

        self._gameRepository.move_snake_right()

    def move_snake_left(self):
        """
        Move the snake to the left
        :return: -
        """

        self._gameRepository.move_snake_left()

    def move_snake_up(self):
        """
        Move the snake to the up
        :return: -
        """

        self._gameRepository.move_snake_up()

    def move_snake_down(self):
        """
        Move the snake to the down
        :return: -
        """

        self._gameRepository.move_snake_down()

    def move_snake_n_pos(self, number):
        """
        Move the snake n pos
        :return: -
        """
        for index in range(number):
            self._gameRepository.move_snake_forward()
