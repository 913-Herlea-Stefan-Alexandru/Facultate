"""
The board model
"""
from texttable import Texttable


class BoardException(Exception):

    def __init__(self, message):
        self._message = message


class Board:

    def __init__(self, DIM):
        self._dim = DIM

        # Create the board
        self.board = [[' ' for i in range(DIM)] for j in range(DIM)]
        self.snake_coords = []

    @property
    def SnakeCoords(self):
        return self.snake_coords

    def get_board(self):
        return self.board

    def get_value(self, row, col):
        """
        Gets the value in the given cell
        :param row: The row
        :param col: The column
        :return: The value
        """
        return self.board[row][col]

    def set_value(self, row, col, value):
        """
        Sets a value to the board
        :param row: The row
        :param col: The column
        :param value: The value
        :return: -
        """
        if self.__check_on_board(row, col):
            self.board[row][col] = value
        else:
            raise BoardException("Coordinates are not on the board!")

    def __check_on_board(self, row, col):
        """
        Checks weather the specified cell is on the board
        :return: True if the cell is on the board, else False
        """
        if row >= 0 and row < self._dim and col >= 0 and col < self._dim:
            return True

        return False

    def __str__(self):
        table = Texttable()
        for row in self.board:
            table.add_row(row)
        return table.draw()
