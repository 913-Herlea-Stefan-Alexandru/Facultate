"""
Game repository class
"""
import random

from domain.Board import Board


class GameRepositoryException(Exception):

    def __init__(self, message):
        self._message = message


class GameRepository:

    EMPTY = ' '
    SNAKE_HEAD = '*'
    SNAKE_BODY = '+'
    APPLE = '.'

    UP = 1
    RIGHT = 2
    DOWN = 3
    LEFT = 4
    # 1 - up, 2 - right, 3 - down, 4 - left
    FACING = UP

    def __init__(self, DIM, apple_count):
        self._dim = DIM
        self._apple_count = apple_count
        self._board = Board(DIM)

    def create_board(self):
        """
        Creates the board at the start of the game
        :return: -
        """
        # Put the snake on the board
        col = self._dim // 2
        row = self._dim // 2
        self._board.set_value(row - 1, col, '*')
        self._board.SnakeCoords.append([row - 1, col])
        self._board.set_value(row, col, '+')
        self._board.SnakeCoords.append([row, col])
        self._board.set_value(row + 1, col, '+')
        self._board.SnakeCoords.append([row + 1, col])

        # Place the apples
        for index in range(self._apple_count):
            self.place_apple()

    def get_board(self):
        """
        Gets the board
        :return: The board object
        """
        return self._board

    def place_apple(self):
        """
        Place an apple on the board in a random cell
        :return: -
        """
        count = 0
        ok = False
        while not ok and count < 100:
            row = random.randint(0, self._dim - 1)
            col = random.randint(0, self._dim - 1)
            if self._board.get_value(row, col) == self.EMPTY and self.check_adjacent(row, col):
                self._board.set_value(row, col, self.APPLE)
                ok = True
            count += 1

    def check_adjacent(self, row, col):
        """
        Checks if the apple is adjacent with another value
        :param row: The row
        :param col: The column
        :return: True if it is adjacent otherwise False
        """
        ok = True
        if row + 1 < self._dim:
            if self._board.get_value(row + 1, col) == self.APPLE:
                ok = False
        if row - 1 >= 0:
            if self._board.get_value(row - 1, col) == self.APPLE:
                ok = False
        if col - 1 >= 0:
            if self._board.get_value(row, col - 1) == self.APPLE:
                ok = False
        if col + 1 < self._dim:
            if self._board.get_value(row, col + 1) == self.APPLE:
                ok = False
        return ok

    def move_snake_right(self):
        """
        Move the snake to the right
        :return: -
        :exception: If it turns 180 degrees
        """
        if self.FACING == self.LEFT:
            raise GameRepositoryException("Invalid move")

        if self.FACING != self.RIGHT:
            self.FACING = self.RIGHT
            self.move_snake_forward()

    def move_snake_left(self):
        """
        Move the snake to the left
        :return: -
        :exception: If it turns 180 degrees
        """
        if self.FACING == self.RIGHT:
            raise GameRepositoryException("Invalid move")

        if self.FACING != self.LEFT:
            self.FACING = self.LEFT
            self.move_snake_forward()

    def move_snake_up(self):
        """
        Move the snake to the up
        :return: -
        :exception: If it turns 180 degrees
        """
        if self.FACING == self.DOWN:
            raise GameRepositoryException("Invalid move")

        if self.FACING != self.UP:
            self.FACING = self.UP
            self.move_snake_forward()

    def move_snake_down(self):
        """
        Move the snake to the down
        :return: -
        :exception: If it turns 180 degrees
        """
        if self.FACING == self.UP:
            raise GameRepositoryException("Invalid move")

        if self.FACING != self.DOWN:
            self.FACING = self.DOWN
            self.move_snake_forward()

    def move_snake_forward(self):
        """
        Move the snake to the forward
        :return: -
        """

        last_row = 0
        last_col = 0

        last_row = self._board.SnakeCoords[0][0]
        last_col = self._board.SnakeCoords[0][1]

        # Move head to the direction
        if self.FACING == self.UP:
            self._board.SnakeCoords[0][0] -= 1
        elif self.FACING == self.DOWN:
            self._board.SnakeCoords[0][0] += 1
        elif self.FACING == self.RIGHT:
            self._board.SnakeCoords[0][1] += 1
        elif self.FACING == self.LEFT:
            self._board.SnakeCoords[0][1] -= 1

        row = self._board.SnakeCoords[0][0]
        col = self._board.SnakeCoords[0][1]

        if self._board.get_value(row, col) == '+':
            raise GameRepositoryException("Game Over!")

        # Grow the snake if it hits an apple
        grow = False
        if self._board.get_value(row, col) == '.':
            grow = True

        self._board.set_value(row, col, self.SNAKE_HEAD)

        # Move the body of the snake forward
        for index in range(1, len(self._board.SnakeCoords)):
            self._board.set_value(last_row, last_col,
                                  self.EMPTY)
            aux_row = self._board.SnakeCoords[index][0]
            aux_col = self._board.SnakeCoords[index][1]

            self._board.SnakeCoords[index][0] = last_row
            self._board.SnakeCoords[index][1] = last_col

            last_row = aux_row
            last_col = aux_col

            self._board.set_value(self._board.SnakeCoords[index][0], self._board.SnakeCoords[index][1],
                                  self.SNAKE_BODY)

        if not grow:
            self._board.set_value(last_row, last_col, self.EMPTY)
        else:
            self._board.SnakeCoords.append([last_row, last_col])
            self.place_apple()
