import os

from repository.GameRepository import GameRepository
from service.GameService import GameService
from ui.console import ConsoleUI


def read_settings():
    DIM = 0
    apple_count = 0

    file_name = "settings.txt"

    try:
        if os.path.getsize(file_name) == 0:
            return
        f = open(file_name, "r")
    except IOError:
        raise IOError("Settings file not found!")

    line = f.readline().strip()
    tokens = line.split('=')
    if tokens[0] == "DIM":
        DIM = int(tokens[1])

    line = f.readline().strip()
    tokens = line.split('=')
    if tokens[0] == "apple_count":
        apple_count = int(tokens[1])

    return DIM, apple_count


if __name__ == "__main__":

    # Read settings
    DIM, apple_count = read_settings()

    # create dependecies
    gameRepository = GameRepository(DIM, apple_count)
    gameService = GameService(gameRepository)
    console = ConsoleUI(gameService, gameRepository)

    # Start the game
    console.start()
