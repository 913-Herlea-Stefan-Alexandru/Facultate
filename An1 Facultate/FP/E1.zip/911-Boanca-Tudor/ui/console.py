from services.game_services import GameOverException
from domain.snake import DirectionError


class InvalidInputError(Exception):
    pass


class Console:
    def __init__(self, services):
        self.__services = services

    @staticmethod
    def split_command(command):
        parts = command.strip().split(' ', 1)
        for index in range(len(parts)):
            parts[index] = parts[index].lower()
        return parts[0], '' if len(parts) == 1 else parts[1].strip()

    def move_snake(self, distance_string):
        if distance_string == '':
            distance = 1
        else:
            try:
                distance = int(distance_string)
                if distance < 0:
                    raise InvalidInputError('The number needs to be positive!')
            except TypeError:
                raise InvalidInputError('You need to enter a positive number!')
        self.__services.move_snake(distance)

    def set_direction_up(self, *args):
        self.__services.set_direction_up()

    def set_direction_down(self, *args):
        self.__services.set_direction_down()

    def set_direction_left(self, *args):
        self.__services.set_direction_left()

    def set_direction_right(self, *args):
        self.__services.set_direction_right()

    def run_program(self):
        program_running = True
        function_dict = {
            'move': self.move_snake,
            'up': self.set_direction_up,
            'down': self.set_direction_down,
            'left': self.set_direction_left,
            'right': self.set_direction_right
        }

        while program_running:
            print(self.__services.board)
            command = input("")
            command_word, command_parameters = self.split_command(command)

            if command_word in function_dict:
                try:
                    function_dict[command_word](command_parameters)
                except InvalidInputError as inputError:
                    print(inputError)
                except GameOverException as moveException:
                    print(moveException)
                    exit()
                except DirectionError as directionException:
                    print(directionException)
            elif command_word == 'exit':
                program_running = False
            else:
                print('Bad command!')