from repository.board import Board
from services.game_services import GameServices
from ui.console import Console
from jproperties import Properties


class ProgramSettings:
    def __init__(self, file_path):
        properties = Properties()
        with open(file_path, 'rb') as configuration_file:
            properties.load(configuration_file)
        try:
            self.__dimension = int(properties['DIM'].data)
            self.__apple_count = int(properties['apple_count'].data)
        except KeyError:
            print('Configuration file format wrong!')
            exit(0)

    @property
    def board_dimension(self):
        return self.__dimension

    @property
    def apple_count(self):
        return self.__apple_count


if __name__ == '__main__':
    settings = ProgramSettings('settings.properties')

    game_board = Board(settings.board_dimension, settings.board_dimension)
    game_services = GameServices(game_board, settings.apple_count)
    ui = Console(game_services)

    ui.run_program()
