from random import randint, choice
from domain.point import BoardPoint
from domain.cell import Cell
from domain.snake import Snake


class GameException(Exception):
    pass


class GameOverException(GameException):
    pass


class GameServices:
    def __init__(self, board, apple_count):
        self.__board = board
        self.__apple_count = apple_count
        self.__current_apple_count = 0
        self.initialize_snake()
        self.place_apples()

    @property
    def board(self):
        return self.__board

    @board.setter
    def board(self, value):
        self.__board = value

    @property
    def apple_count(self):
        return self.__apple_count

    def initialize_snake(self):
        middle_coordinate = self.board.columns // 2
        self.__snake = Snake(BoardPoint(middle_coordinate - 1, middle_coordinate),
                             [BoardPoint(middle_coordinate, middle_coordinate),
                              BoardPoint(middle_coordinate + 1, middle_coordinate)])
        self.place_snake()

    def place_snake(self):
        self.check_if_snake_is_outside_bounds()
        self.__board[self.__snake.head_position.x][self.__snake.head_position.y].place_head()
        for tail_element in self.__snake.tail_positions:
            self.__board[tail_element.x][tail_element.y].place_tail()

    def check_if_snake_is_outside_bounds(self):
        if self.__snake.head_position.x < 0 or self.__snake.head_position.x > self.__board.columns - 1 or \
                self.__snake.head_position.y < 0 or self.__snake.head_position.y > self.__board.columns - 1:
            raise GameOverException('Game over! You moved outside of the bounds of the board')

    def move_snake(self, distance):
        for i in range(distance):
            final_tail_element_position = self.__snake.tail_positions[-1]
            self.__board[final_tail_element_position.x][final_tail_element_position.y].empty()
            self.__snake.move()
            if self.snake_ate_apple():
                self.__snake.grow()
                self.place_snake()
                self.respawn_apple()
            else:
                self.place_snake()

    def snake_ate_itself(self):
        for tail_element in self.__snake.tail_positions:
            if self.__snake.head_position == tail_element:
                raise GameOverException('Game over! You ate yourself')

    def snake_ate_apple(self):
        return self.__board[self.__snake.head_position.x][self.__snake.head_position.y].status == Cell.CellStatus.APPLE

    def respawn_apple(self):
        free_cells = self.get_free_cells()

        if len(free_cells) != 0:
            new_apple_point = choice(free_cells)
            self.__board[new_apple_point.x][new_apple_point.y].place_apple()
        else:
            raise GameOverException('You won!')

    def get_free_cells(self):
        free_cells = []
        for i in range(self.__board.columns):
            for j in range(self.__board.columns):
                if self.__board[i][j].status == Cell.CellStatus.EMPTY:
                    free_cells.append(BoardPoint(i, j))
        return free_cells

    def place_apples(self):
        while self.__current_apple_count < self.__apple_count:
            self.place_new_apple()

    def place_new_apple(self):
        new_apple_point = BoardPoint(randint(0, self.__board.columns - 1), randint(0, self.__board.columns - 1))
        if self.__board[new_apple_point.x][new_apple_point.y].status == Cell.CellStatus.EMPTY:
            if not self.adjacent_apples_exist(new_apple_point):
                self.__board[new_apple_point.x][new_apple_point.y].place_apple()
                self.__current_apple_count += 1

    def adjacent_apples_exist(self, new_apple_point):
        if new_apple_point.x == 0 and new_apple_point.y == 0:
            return self.__board[new_apple_point.x + 1][new_apple_point.y].status == Cell.CellStatus.APPLE or \
                   self.__board[new_apple_point.x][new_apple_point.y + 1].status == Cell.CellStatus.APPLE
        elif new_apple_point.x == 0 and new_apple_point.y == self.__board.columns - 1:
            return self.__board[new_apple_point.x + 1][new_apple_point.y].status == Cell.CellStatus.APPLE or \
                   self.__board[new_apple_point.x][new_apple_point.y - 1].status == Cell.CellStatus.APPLE
        elif new_apple_point.x == self.__board.columns - 1 and new_apple_point.y == 0:
            return self.__board[new_apple_point.x - 1][new_apple_point.y].status == Cell.CellStatus.APPLE or \
                   self.__board[new_apple_point.x][new_apple_point.y + 1].status == Cell.CellStatus.APPLE
        elif new_apple_point.x == self.__board.columns - 1 and new_apple_point.y == self.__board.columns - 1:
            return self.__board[new_apple_point.x - 1][new_apple_point.y].status == Cell.CellStatus.APPLE or \
                   self.__board[new_apple_point.x][new_apple_point.y - 1].status == Cell.CellStatus.APPLE
        elif new_apple_point.x == 0:
            return self.__board[new_apple_point.x + 1][new_apple_point.y].status == Cell.CellStatus.APPLE or \
                   self.__board[new_apple_point.x][new_apple_point.y + 1].status == Cell.CellStatus.APPLE or \
                   self.__board[new_apple_point.x][new_apple_point.y - 1].status == Cell.CellStatus.APPLE
        elif new_apple_point.x == self.__board.columns - 1:
            return self.__board[new_apple_point.x - 1][new_apple_point.y].status == Cell.CellStatus.APPLE or \
                   self.__board[new_apple_point.x][new_apple_point.y + 1].status == Cell.CellStatus.APPLE or \
                   self.__board[new_apple_point.x][new_apple_point.y - 1].status == Cell.CellStatus.APPLE
        elif new_apple_point.y == 0:
            return self.__board[new_apple_point.x - 1][new_apple_point.y].status == Cell.CellStatus.APPLE or \
                   self.__board[new_apple_point.x + 1][new_apple_point.y].status == Cell.CellStatus.APPLE or \
                   self.__board[new_apple_point.x][new_apple_point.y - 1].status == Cell.CellStatus.APPLE
        elif new_apple_point.y == self.__board.columns - 1:
            return self.__board[new_apple_point.x - 1][new_apple_point.y].status == Cell.CellStatus.APPLE or \
                   self.__board[new_apple_point.x + 1][new_apple_point.y].status == Cell.CellStatus.APPLE or \
                   self.__board[new_apple_point.x][new_apple_point.y - 1].status == Cell.CellStatus.APPLE
        else:
            return self.__board[new_apple_point.x - 1][new_apple_point.y].status == Cell.CellStatus.APPLE or \
                   self.__board[new_apple_point.x + 1][new_apple_point.y].status == Cell.CellStatus.APPLE or \
                   self.__board[new_apple_point.x][new_apple_point.y + 1].status == Cell.CellStatus.APPLE or \
                   self.__board[new_apple_point.x][new_apple_point.y - 1].status == Cell.CellStatus.APPLE

    def set_direction_up(self):
        self.__snake.change_direction_up()
        self.move_snake(1)

    def set_direction_down(self):
        self.__snake.change_direction_down()
        self.move_snake(1)

    def set_direction_left(self):
        self.__snake.change_direction_left()
        self.move_snake(1)

    def set_direction_right(self):
        self.__snake.change_direction_right()
        self.move_snake(1)
