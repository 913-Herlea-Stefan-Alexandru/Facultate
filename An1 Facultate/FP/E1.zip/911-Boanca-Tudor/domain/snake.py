from enum import IntEnum
from domain.point import BoardPoint
from copy import deepcopy


class DirectionError(Exception):
    pass


class Snake:
    class Direction(IntEnum):
        UP = 0,
        DOWN = 1,
        RIGHT = 2,
        LEFT = 3

    def __init__(self, head_position, tail_positions):
        self.__head_position = head_position
        self.__tail_positions = tail_positions
        self.__direction = self.Direction.UP
        self.__last_removed_tail_element = BoardPoint(0, 0)

    @property
    def head_position(self):
        return self.__head_position

    @head_position.setter
    def head_position(self, value):
        self.__head_position = value

    @property
    def tail_positions(self):
        return self.__tail_positions

    @tail_positions.setter
    def tail_positions(self, value):
        self.__tail_positions = value

    def change_direction_up(self):
        if self.__direction == self.Direction.UP:
            raise DirectionError('You are already facing up')
        if self.__direction == self.Direction.DOWN:
            raise DirectionError('You cannot move 180 degrees')
        self.__direction = self.Direction.UP

    def change_direction_down(self):
        if self.__direction == self.Direction.DOWN:
            raise DirectionError('You are already facing down')
        if self.__direction == self.Direction.UP:
            raise DirectionError('You cannot move 180 degrees')
        self.__direction = self.Direction.DOWN

    def change_direction_left(self):
        if self.__direction == self.Direction.LEFT:
            raise DirectionError('You are already facing left')
        if self.__direction == self.Direction.RIGHT:
            raise DirectionError('You cannot move 180 degrees')
        self.__direction = self.Direction.LEFT

    def change_direction_right(self):
        if self.__direction == self.Direction.RIGHT:
            raise DirectionError('You are already facing right')
        if self.__direction == self.Direction.LEFT:
            raise DirectionError('You cannot move 180 degrees')
        self.__direction = self.Direction.RIGHT

    def move_tail(self):
        self.__last_removed_tail_element = BoardPoint(self.__tail_positions[-1].x, self.__tail_positions[-1].y)
        for i in range(len(self.__tail_positions) - 1, 0, -1):
            self.__tail_positions[i].x = self.__tail_positions[i - 1].x
            self.__tail_positions[i].y = self.__tail_positions[i - 1].y
        self.__tail_positions[0].x = self.__head_position.x
        self.__tail_positions[0].y = self.__head_position.y

    def move(self):
        self.move_tail()
        if self.__direction == self.Direction.UP:
            self.__head_position.x -= 1

        elif self.__direction == self.Direction.DOWN:
            self.__head_position.x += 1

        elif self.__direction == self.Direction.LEFT:
            self.__head_position.y -= 1

        elif self.__direction == self.Direction.RIGHT:
            self.__head_position.y += 1

    def grow(self):
        self.__tail_positions.append(self.__last_removed_tail_element)
