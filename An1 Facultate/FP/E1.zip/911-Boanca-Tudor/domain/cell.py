from enum import IntEnum
from dataclasses import dataclass


@dataclass
class Cell:
    class CellStatus(IntEnum):
        EMPTY = 0
        SNAKE_HEAD = 1
        SNAKE_TAIL = 2
        APPLE = 3
    status: CellStatus = CellStatus.EMPTY

    def place_head(self):
        self.status = self.CellStatus.SNAKE_HEAD

    def place_tail(self):
        self.status = self.CellStatus.SNAKE_TAIL

    def place_apple(self):
        self.status = self.CellStatus.APPLE

    def empty(self):
        self.status = self.CellStatus.EMPTY

    def __str__(self):
        status_display = \
        {
            0: ' ',
            1: '*',
            2: '+',
            3: '.'
        }
        return status_display[self.status.value]
