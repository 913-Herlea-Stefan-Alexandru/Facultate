from domain.cell import Cell
from texttable import Texttable
from dataclasses import dataclass


class BoardException(Exception):
    pass


class Board:
    def __init__(self, row_count, column_count):
        self.__columns = column_count
        self.__rows = row_count
        self.__create_board()

    def __create_board(self):
        self.__board = [[Cell() for column in range(self.__columns)]
                        for row in range(self.__rows)]

    @property
    def columns(self):
        return self.__columns

    @property
    def rows(self):
        return self.__rows

    def __getitem__(self, item):
        return self.__board[item]

    def __str__(self):
        board = Texttable()

        for row in range(self.__rows):
            row_data = [self.__board[row][column] for column in range(self.__columns)]
            board.add_row(row_data)
        return board.draw()
