from src.services.game import Game

class UI:
    def __init__(self, path):
        self.game = Game(path)

    def start(self):
        done = False
        move = 1
        # print(str(self.game))
        while not done:
            try:
                print(str(self.game))
                command = input().strip()
                valid = True
                if command == 'up':
                    valid = self.game.move_up(False)
                elif command == 'down':
                    valid = self.game.move_down(False)
                elif command == 'right':
                    valid = self.game.move_right(False)
                elif command == 'left':
                    valid = self.game.move_left(False)
                elif command == 'move':
                    valid = self.game.move_direction(1)
                else:
                    command = command.split(' ')
                    if not ((command[0] == 'move') and (command[1].isdigit())):
                        raise ValueError('wrong command')
                    valid = self.game.move_direction(int(command[1]))
                if not valid:
                    done = True
            except ValueError as ve:
                print(str(ve))
        print(str(self.game))
        print('Game Over')


# asd = UI('../settings.txt')
# asd.start()