from src.services.snake import Snake
from src.entities.board import Board
import random


class Game:
    def __init__(self, path):
        self.dimension, self.apple_count = self.get_settings(path)
        self.snake = Snake()
        self.board = Board(self.dimension)
        self.initialize_snake()
        self.add_apples(self.apple_count)

    def move_up(self, repeating=True):
        """
        makes a move up
        :param repeating: should it move it already moved to this direction?
        :return:
        """
        if self.snake.direction == 'down':
            raise ValueError('a snake going down cannot immediately go up')
        if self.snake.direction == 'up' and repeating is False:
            return True
        self.snake.direction = 'up'
        head_x, head_y = self.snake.get_head_coord()
        move_x, move_y = head_x - 1, head_y
        return self.move(move_x, move_y)

    def move_down(self, repeating=True):
        """
        makes a move down
        :param repeating: should it move it already moved to this direction?
        :return:
        """
        if self.snake.direction == 'up':
            raise ValueError('a snake going up cannot immediately go down')
        if self.snake.direction == 'down' and repeating is False:
            return True
        self.snake.direction = 'down'
        head_x, head_y = self.snake.get_head_coord()
        move_x, move_y = head_x + 1, head_y
        return self.move(move_x, move_y)

    def move_left(self, repeating=True):
        """
        makes a move left
        :param repeating: should it move it already moved to this direction?
        :return:
        """
        if self.snake.direction == 'right':
            raise ValueError('a snake going right cannot immediately go left')
        if self.snake.direction == 'left' and repeating is False:
            return True
        self.snake.direction = 'left'
        head_x, head_y = self.snake.get_head_coord()
        move_x, move_y = head_x, head_y - 1
        return self.move(move_x, move_y)

    def move_right(self, repeating=True):
        """
        makes a move right
        :param repeating: should it move it already moved to this direction?
        :return:
        """
        print('tries right')
        if self.snake.direction == 'left':
            raise ValueError('a snake going left cannot immediately go right')
        print('tries right 2')
        if self.snake.direction == 'right' and repeating is False:
            return True
        print('tries right 2')
        self.snake.direction = 'right'
        head_x, head_y = self.snake.get_head_coord()
        move_x, move_y = head_x, head_y + 1
        return self.move(move_x, move_y)

    def move(self, move_x, move_y):
        """
        make a move to the given position assuming it is right
        :param move_x: x coord
        :param move_y: y coord
        :return:
        """
        if not ((0 <= move_x < self.dimension) and (0 <= move_y < self.dimension)):
            return False
        if self.board.get_char(move_x, move_y) == '.':
            self.snake.add_length()
            self.add_apples(1)
        removed_parts = self.snake.remove_old_parts()
        for x, y in removed_parts:
            self.board.remove_char(x, y)

        if self.board.get_char(move_x, move_y) == '+':
            return False

        self.move_head(move_x, move_y)
        # removed_parts = self.snake.remove_old_parts()
        # for x, y in removed_parts:
        #     self.board.remove_char(x, y)
        return True

    def move_direction(self, positions):
        """
        move a position times to the already set direction
        :param positions: number of pos to move
        :return:
        """
        valid = True
        for i in range(positions):
            if self.snake.direction == 'up':
                valid = self.move_up(True)
            elif self.snake.direction == 'down':
                valid = self.move_down(True)
            elif self.snake.direction == 'right':
                valid = self.move_right(True)
            elif self.snake.direction == 'left':
                valid = self.move_left(True)
            if not valid:
                return False
        return valid

    def initialize_snake(self):
        """
        set the snake in its initial position
        :return:
        """
        head_x = (self.dimension // 2) - 1
        head_y = (self.dimension // 2)
        self.move_head(head_x, head_y)
        self.add_body(head_x + 1, head_y, 2)
        self.add_body(head_x + 2, head_y, 3)
        self.snake.add_length(3)

    def add_apples(self, number):
        """
        randomly insert apples into a predefined number of potential positions
        This is the number of all un-adjacent cells starting from cell 0, 0
        number: number of apples to insert
        :return:
        """
        row_positions = (self.dimension // 2 + self.dimension % 2) - 1
        positions = row_positions * self.dimension - 3
        for i in range(number):
            random_position = random.randint(0, positions)
            apple_x = random_position // row_positions
            apple_y = (random_position % row_positions) * 2 - 1 - (apple_x % 2)
            while not self.board.is_empty(apple_x, apple_y):
                random_position = random.randint(0, positions)
                apple_x = random_position // row_positions
                apple_y = (random_position % row_positions) * 2 - 1 - (apple_x % 2)
            self.add_apple(apple_x, apple_y)

    def move_head(self, x, y):
        """
        set a new location for the snake head
        :param x: new head x
        :param y: new head y
        :return:
        """
        old_head_x, old_head_y = self.snake.set_new_head(x, y)
        self.board.add_char(x, y, '*')
        if (old_head_x != -1) and (old_head_y != -1):
            self.board.add_char(old_head_x, old_head_y, '+')

    def add_body(self, x, y, age=1):
        """
        adds a snake body part woth an given age
        :param x: snake x
        :param y: snake part y
        :param age: snake part age
        :return:
        """
        self.snake.add_snake_part(x, y, age)
        self.board.add_char(x, y, '+')

    def add_apple(self, x, y):
        """
        adds an apply to the given position
        :param x: apple x
        :param y: apple y
        :return:
        """
        self.board.add_char(x, y, '.')

    @staticmethod
    def get_settings(path):
        """
        leads the settings from the given path
        :param path:
        :return: board dimension and apple count
        """
        dimension, apple_count = 0, 0
        try:
            f = open(path, "r")
            line = f.readline().strip()
            while len(line) > 0:
                line = line.split('=')
                value = int(line[1])
                if line[0] == 'DIM':
                    dimension = value
                else:
                    apple_count = value
                line = f.readline().strip()
            f.close()
            return dimension, apple_count
        except IOError as e:
            raise ValueError("An error occurred when reading assignment- " + str(e))

    def __str__(self):
        return str(self.board)
