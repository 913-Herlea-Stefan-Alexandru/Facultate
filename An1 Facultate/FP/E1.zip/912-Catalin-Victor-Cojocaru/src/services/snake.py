from src.entities.snake_part import SnakePart


class Snake:
    def __init__(self):
        """
        we initialize the snake with empty data
        """
        self._snake_parts = []
        self._head_coordinates = -1, -1
        self._snake_length = 0
        self.direction = 'up'

    def add_snake_part(self, x, y, age=1):
        """
        adds snake part of a given age
        :param x: snake part x
        :param y: snake part y
        :param age: snake part age
        :return:
        """
        new_snake_part = SnakePart(x, y, age)
        self._snake_parts.append(new_snake_part)

    def get_head_coord(self):
        return self._head_coordinates

    def add_length(self, value=1):
        # print('increment length', value, self._snake_length)
        self._snake_length += value

    def set_new_head(self, x, y):
        """
        sets a new head for the snake
        :param x: head x coord
        :param y: head y coord
        :return: old head coords
        """
        old_head_x, old_head_y = self._head_coordinates
        self._head_coordinates = x, y

        new_head = SnakePart(x, y)
        self._snake_parts.append(new_head)

        return old_head_x, old_head_y

    def remove_old_parts(self):
        """
        removes parts that are to old
        :return: an list with the coordinates of the removed parts in tuples
        """
        removed_parts = []
        for snake_part in self._snake_parts:
            snake_part.age += 1
            # print(snake_part.x, snake_part.y, snake_part.age, self._snake_length)
            if snake_part.age > self._snake_length:
                removed_parts.append((snake_part.x, snake_part.y))
                self._snake_parts.remove(snake_part)
        return removed_parts
