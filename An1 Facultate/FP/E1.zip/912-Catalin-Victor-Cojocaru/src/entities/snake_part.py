class SnakePart:
    def __init__(self, x, y, age=1):
        """
        crates a snake part
        :param x: x coordinate of the snake part
        :param y: y coordinate of the snake part
        :param char: the character that will represent this part
        """
        self.x = x
        self.y = y
        # self.char = char
        self.age = age
