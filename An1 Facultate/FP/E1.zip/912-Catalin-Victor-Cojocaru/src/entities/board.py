from texttable import Texttable


class Board:
    def __init__(self, dim):
        self._board = [[' ' for x in range(dim)] for y in range(dim)]

    def add_char(self, x, y, char):
        self._board[x][y] = char

    def remove_char(self, x, y):
        self._board[x][y] = ' '

    def is_empty(self, x, y):
        return self._board[x][y] == ' '

    def get_char(self, x, y):
        return self._board[x][y]

    def __str__(self):
        """
        return a strigified version of the board using texttable
        :return:
        """
        table = Texttable()
        for row in self._board:
            table.add_row(row)
        return table.draw()
