from src.services.UI import UI

asd = UI('settings.txt')
asd.start()
