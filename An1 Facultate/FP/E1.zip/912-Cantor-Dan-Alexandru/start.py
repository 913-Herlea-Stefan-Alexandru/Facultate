from Game_UI import GameUI


def start_game():
    f = open("settings.txt", 'r')
    line = f.readline().strip()
    line = line.split(" ")
    game_ui = GameUI(int(line[0]), int(line[1]))
    game_ui.start_game()
    f.close()

start_game()