from random import randrange

from Area import GameArea
from BodyOfSnake import BodyOfSnake


class Game:
    def __init__(self, dim, nr_of_apples):
        self.area = GameArea(dim, nr_of_apples)
        self.is_game_over = False
        self.snake_len = 2
        self.current_dir = [-1, 0]
        self.snake_head_poz = BodyOfSnake(dim // 2, dim // 2 + 1)
        self.body_of_snake = [BodyOfSnake(0, 0) for i in range(2)]
        self.initialise_body_of_snake()

    def initialise_body_of_snake(self):
        self.body_of_snake[0] = BodyOfSnake(self.area.dim // 2 + 1, self.area.dim // 2 + 1)
        self.body_of_snake[1] = BodyOfSnake(self.area.dim // 2 + 2, self.area.dim // 2 + 1)

    def update_area(self):
        found = False
        for i in range(1, self.area.dim + 1):
            for j in range(1, self.area.dim + 1):
                found = False
                if i == self.snake_head_poz.actual_line and j == self.snake_head_poz.actual_column:
                    found = True
                    self.area.modify_cell(i, j, "*")
                for body in self.body_of_snake:
                    if i == body.actual_line and j == body.actual_column:
                        self.area.modify_cell(i, j, "+")
                        found = True
                        break
                if found == False and (self.area.get_cell(i, j) == "*" or self.area.get_cell(i, j) == "+"):
                    self.area.modify_cell(i, j, None)

    def place_new_apple(self):
        nr_of_placed_apples = 0
        contor_empty_spaces = 0
        for i in range(1, self.area.dim):
            for j in range(1, self.area.dim):
                if self.area.get_cell(i, j) is None:
                    contor_empty_spaces += 1
        if contor_empty_spaces == 0:
            return
        while nr_of_placed_apples < 1:
            i = randrange(1, self.area.dim + 1)
            j = randrange(1, self.area.dim + 1)
            if self.area.get_cell(i, j) is None and self.area.get_cell(i - 1, j) != "." and self.area.get_cell(i + 1, j) != "." \
                    and self.area.get_cell(i, j - 1) != "." and self.area.get_cell(i, j + 1) != ".":
                self.area.modify_cell(i, j, ".")
                nr_of_placed_apples += 1

    def move_command(self, direction):
        current_i_of_head = self.snake_head_poz.actual_line
        current_j_of_head = self.snake_head_poz.actual_column
        current_i_of_head += direction[0]
        current_j_of_head += direction[1]
        if current_i_of_head < 1 or current_j_of_head < 1 or current_i_of_head > self.area.dim or current_j_of_head > self.area.dim:
            self.is_game_over = True
            return
        if self.area.get_cell(current_i_of_head, current_j_of_head) == "+":
            self.is_game_over = True
            return
        if self.area.get_cell(current_i_of_head, current_j_of_head) == ".":
            self.body_of_snake.append(BodyOfSnake(0, 0))
            self.place_new_apple()

        body_index = len(self.body_of_snake) - 1
        while body_index != 0:
            self.body_of_snake[body_index].actual_line = self.body_of_snake[body_index - 1].actual_line
            self.body_of_snake[body_index].actual_column = self.body_of_snake[body_index - 1].actual_column
            body_index -= 1
        self.body_of_snake[0].actual_line = self.snake_head_poz.actual_line
        self.body_of_snake[0].actual_column = self.snake_head_poz.actual_column
        self.snake_head_poz.actual_line = current_i_of_head
        self.snake_head_poz.actual_column = current_j_of_head
        self.update_area()

    def change_direction(self, direction):
        if direction == self.current_dir:
            return
        if direction[0] + self.current_dir[0] == 0 and direction[1] + self.current_dir[1] == 0:
            raise ValueError("You can't choose the opposite direction!")
        current_i_of_head = self.snake_head_poz.actual_line
        current_j_of_head = self.snake_head_poz.actual_column
        current_i_of_head += direction[0]
        current_j_of_head += direction[1]
        if current_i_of_head < 1 or current_j_of_head < 1 or current_i_of_head > self.area.dim or current_j_of_head > self.area.dim:
            self.is_game_over = True
            return
        if self.area.get_cell(current_i_of_head, current_j_of_head) == "+":
            self.is_game_over = True
            return
        if self.area.get_cell(current_i_of_head, current_j_of_head) == ".":
            self.body_of_snake.append(BodyOfSnake(0, 0))

        body_index = len(self.body_of_snake) - 1
        while body_index != 0:
            self.body_of_snake[body_index].actual_line = self.body_of_snake[body_index - 1].actual_line
            self.body_of_snake[body_index].actual_column = self.body_of_snake[body_index - 1].actual_column
            body_index -= 1
        self.body_of_snake[0].actual_line = self.snake_head_poz.actual_line
        self.body_of_snake[0].actual_column = self.snake_head_poz.actual_column
        self.snake_head_poz.actual_line = current_i_of_head
        self.snake_head_poz.actual_column = current_j_of_head
        self.update_area()
        self.current_dir = direction

    def __str__(self):
        return str(self.area)











