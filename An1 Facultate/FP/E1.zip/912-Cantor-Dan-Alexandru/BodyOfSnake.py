

class BodyOfSnake:
    def __init__(self, line, column):
        self.actual_line = line
        self.actual_column = column