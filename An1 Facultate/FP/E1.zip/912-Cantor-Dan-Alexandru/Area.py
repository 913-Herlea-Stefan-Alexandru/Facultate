from random import randrange

from texttable import Texttable


class GameArea():
    def __init__(self, dim, nr_of_apples):
        self.table = [[None for i in range(dim + 2)] for j in range(dim + 2)]
        self.dim = dim
        self.nr_of_appels = nr_of_apples
        self.place_apples()
        self.place_snake()

    def place_apples(self):
        nr_of_placed_apples = 0
        while nr_of_placed_apples < self.nr_of_appels:
            i = randrange(1, self.dim + 1)
            j = randrange(1, self.dim + 1)
            if self.table[i][j] is None and self.table[i - 1][j] is None and self.table[i + 1][j] is None and self.table[i][j - 1] is None and self.table[i][j + 1] is None:
                self.table[i][j] = "."
                nr_of_placed_apples += 1

    def place_snake(self):
        self.table[self.dim // 2][self.dim // 2 + 1] = "*"
        self.table[self.dim // 2 + 1][self.dim // 2 + 1] = "+"
        self.table[self.dim // 2 + 2][self.dim // 2 + 1] = "+"

    def __str__(self):
        printable = Texttable()
        for i in range(1, self.dim + 1):
            row = []
            for j in range (1, self.dim + 1):
                if self.table[i][j] is None:
                    row.append(" ")
                else:
                    row.append((self.table[i][j]))
            printable.add_row(row)
        return printable.draw()

    def modify_cell(self, row, column, symbol):
        if not symbol in ['*', '+', '.', None]:
            raise ValueError("Wrong Symbol!")

        #if row < 1 or row > self.dim or column < 1 or column > self.dim:
         #   raise ValueError("Wrong row/column!")

        self.table[row][column] = symbol

    def get_cell(self, row, column):
        # if row < 1 or row > self.dim or column < 1 or column > self.dim:
        #     raise ValueError("Wrong row/column!")
        return self.table[row][column]