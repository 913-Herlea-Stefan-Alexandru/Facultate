from Game import Game


class GameUI:
    def __init__(self, dim, nr_of_apple):
        self.game = Game(dim, nr_of_apple)

    @staticmethod
    def print_menu():
        print("Available commands:")
        print ("move [n]. This moves the snake n squares, in the direction it is currently facing. " +
               "move with no parameters moves the snake by 1 square")
        print ("up | right | down | left changes the snake's direction accordingly. Trying to change the snake's" +
               " direction by 180 degrees will result in an error message (a snake going up cannot immediately go down)." +
               " Entering the direction the snake is currently heading for does nothing")

    def move_snake(self, nr_of_moves):
        for i in range(nr_of_moves):
            if self.game.is_game_over:
                return
            self.game.move_command(self.game.current_dir)

    def change_direction(self, direction):
        self.game.change_direction(direction)

    def start_game(self):
        set_of_commands = {"move": self.move_snake, "change": self.change_direction}
        while not self.game.is_game_over:
            print(self.game)
            self.print_menu()
            try:
                command = input("Your command: ")
                parameters = command.split(" ", maxsplit=1)
                if parameters[0] not in command:
                    print("Invalid command!")
                    continue
                elif parameters[0] == "move":
                    if len(parameters) == 1:
                        set_of_commands["move"](1)
                    else:
                        set_of_commands["move"](int(parameters[1]))
                elif parameters[0] == "up":
                    set_of_commands["change"]([-1, 0])
                elif parameters[0] == "right":
                    set_of_commands["change"]([0, 1])
                elif parameters[0] == "down":
                    set_of_commands["change"]([1, 0])
                elif parameters[0] == "left":
                    set_of_commands["change"]([0, -1])
            except ValueError as ve:
                print(ve)
            except TypeError as te:
                print(te)
        print("Congratulations!! You obtained " + str(len(self.game.body_of_snake)) + " points")
