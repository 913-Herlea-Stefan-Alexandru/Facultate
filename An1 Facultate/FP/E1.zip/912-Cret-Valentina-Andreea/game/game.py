from board.board import Board


class Game():
    def __init__(self, board: Board):
        self.__board = board

    def ret_board(self):
        return self.__board

    def eat_apple(self):
        pass

    def where_head(self):
        matrix = self.__board.ret_board()
        x,y = self.__board.ret_dim_apples()
        for i in range(x):
            for j in range(x):
                if matrix[i][j] == 0:
                    return i, j

    def len_snake(self):
        nr = 0
        matrix = self.__board.ret_board()
        x,y = self.__board.ret_dim_apples()
        for i in range(x):
            for j in range(x):
                if matrix[i][j] == 1:
                    nr +=1
        return nr

    def eaten_apples(self, eaten_apples):
        eaten_apples += 1
        return eaten_apples