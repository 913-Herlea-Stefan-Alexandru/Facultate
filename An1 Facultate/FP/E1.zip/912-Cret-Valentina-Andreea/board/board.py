import random

from texttable import Texttable


class Board():
    def __init__(self, dim, apples):
        self.__rows = dim
        self.__columns = dim
        self.__matrix = [[None for j in range(self.__columns)] for i in range(self.__rows)]
        self.__apples = apples

    def __str__(self):
        t = Texttable()
        for row in range(self.__rows):
            row_data = []
            for i in self.__matrix[row]:
                if i is None:
                    row_data.append(' ')
                elif i == -1:
                    row_data.append('.')
                elif i == 0:
                    row_data.append('*')
                elif i == 1:
                    row_data.append('+')
            t.add_row(row_data)
        return t.draw()

    def ret_dim_apples(self):
        return self.__rows, self.__apples

    def ret_board(self):
        return self.__matrix

    def place_snake(self):
        middle = self.__rows // 2
        self.__matrix[middle][middle] = 1
        self.__matrix[middle + 1][middle] = 1
        self.__matrix[middle - 1][middle] = 0  # the head

    def place_apples(self):
        for i in range(self.__apples):
            good_place = False
            while not good_place:
                x = random.randrange(0, self.__rows)
                y = random.randrange(0, self.__columns)
                if self.__matrix[x][y] is None:
                    if x - 1 >= 0 and self.__matrix[x - 1][y] != -1 or x - 1 == 0:
                        if x + 1 < self.__rows and self.__matrix[x + 1][y] != -1 or x + 1 == self.__rows:
                            if y - 1 >= 0 and self.__matrix[x][y - 1] != -1 or y - 1 == 0:
                                if y + 1 < self.__columns and self.__matrix[x][y + 1] != -1 or y + 1 == self.__columns:
                                    self.__matrix[x][y] = -1  # i place the apples
                                    good_place = True

    def add_one_apple(self):
        good_place = False
        while not good_place:
            x = random.randrange(0, self.__rows)
            y = random.randrange(0, self.__columns)
            if self.__matrix[x][y] is None:
                if x - 1 >= 0 and self.__matrix[x - 1][y] != -1 or x - 1 == 0:
                    if x + 1 < self.__rows and self.__matrix[x + 1][y] != -1 or x + 1 == self.__rows:
                        if y - 1 >= 0 and self.__matrix[x][y - 1] != -1 or y - 1 == 0:
                            if y + 1 < self.__columns and self.__matrix[x][y + 1] != -1 or y + 1 == self.__columns:
                                self.__matrix[x][y] = -1  # i place the apples
                                good_place = True

    def set_value(self, x, y, value):
        self.__matrix[x][y] = value

    def get_value(self,x,y):
        x = self.__matrix[x][y]
        return x
