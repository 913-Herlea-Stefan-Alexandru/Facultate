from board.board import Board
from game.game import Game


class UI():
    def __init__(self, game: Game, board: Board):
        self.__game = game
        self.__board = board

    def run(self):
        command_dict = {'move': self.move, 'up': self.up, 'right': self.right, 'down': self.down, 'left': self.left}
        self.__board.place_snake()
        self.__board.place_apples()
        print(self.__board)
        print(' ')
        try:
            while True:
                command = input(">>")
                tokens = command.split(" ")
                if tokens[0] in command_dict:
                    if tokens[0] == 'move':
                        if len(tokens) == 2:
                            if command_dict[tokens[0]](tokens[1]) == False:
                                print("Game over")
                                return
                        else:
                            if command_dict[tokens[0]](0) == False:
                                print("Game over")
                                return
                    else:
                        if command_dict[tokens[0]]() == False:
                            print("Game over")
                            return
                else:
                    raise Exception("Bad command!")
        except Exception:
            print("Not an integer")

    def is_digit(self, x):
        if x != int(x):
            return False
        else:
            return True

    def move(self, how_many):
        if how_many != 0:
            if self.is_digit(how_many) == True:
                x = 1


    def up(self):
        eaten_apples = 0
        len_snake = self.__game.len_snake()
        x, y = self.__game.where_head()
        if x == 0:
            return False
        if self.__board.get_value(x-1, y) == 1:
            return False
        if self.__board.get_value(x-1, y) == -1:
            self.__board.set_value(x - 1, y, 0)
            eaten_apples += 1
            self.__board.add_one_apple()

        else:
            self.__board.set_value(x - 1, y, 0)
        for i in range(len_snake):
            self.__board.set_value(x, y, 1)
            x += 1
        if eaten_apples == 0:
            self.__board.set_value(x, y, None)
        print(self.__board)
        return True

    def right(self):
        eaten_apples = 0
        len_snake = self.__game.len_snake()
        x, y = self.__game.where_head()
        if y == 6:
            return False
        if self.__board.get_value(x,y+1) == 1:
            return False
        if self.__board.get_value(x,y+1) == -1:
            self.__board.set_value(x, y+1, 0)
            eaten_apples +=1
            self.__board.add_one_apple()
        else:
            self.__board.set_value(x, y + 1, 0)
        for i in range(len_snake):
            self.__board.set_value(x, y, 1)
            x += 1
        if eaten_apples == 0:
            self.__board.set_value(x, y, None)
        print(self.__board)
        return True

    def down(self):
        eaten_apples = 0
        len_snake = self.__game.len_snake()
        x, y = self.__game.where_head()
        if x == 6:
            return False
        if self.__board.get_value(x+1, y) == 1:
            return False
        if self.__board.get_value(x+1, y) == -1:
            self.__board.set_value(x + 1, y, 0)
            eaten_apples +=1
            self.__board.add_one_apple()
        else:
            self.__board.set_value(x + 1, y, 0)
        for i in range(len_snake):
            self.__board.set_value(x, y, 1)
            x += 1
        if eaten_apples == 0:
            self.__board.set_value(x, y, None)
        print(self.__board)
        return True

    def left(self):
        eaten_apples = 0
        len_snake = self.__game.len_snake()
        x, y = self.__game.where_head()
        if y==0:
            return False
        if self.__board.get_value(x, y-1) == 1:
            return False
        if self.__board.get_value(x, y-1) == -1:
            self.__board.set_value(x, y-1, 0)
            eaten_apples +=1
            self.__board.add_one_apple()
        else:
            self.__board.set_value(x , y-1, 0)
        for i in range(len_snake):
            self.__board.set_value(x, y, 1)
            x += 1
        if eaten_apples == 0:
            self.__board.set_value(x, y, None)
        print(self.__board)
        return True