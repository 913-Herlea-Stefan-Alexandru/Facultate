class SettingsProperties:
    # def __init__(self, txt):
    #     self.__txt = txt

    def read(self):
        with open("settings.properties", "r") as f:
            line = f.readlines()
            line[0] = line[0].strip()
            part1 = line[0]
            line[1] = line[1].strip()
            part2 = line[1]
            return int(part1), int(part2)