from board.board import Board
from console.UI import UI
from game.game import Game
from settings.filesettings import SettingsProperties

settings = SettingsProperties()
dim, apples = settings.read()

board = Board(dim, apples)
game = Game(board)
ui = UI(game, board)
ui.run()
