import random

from texttable import Texttable


class Board:

    def __init__(self, dimension, apple_count):
        self._rows = int(dimension)
        self._columns = int(dimension)
        self._apples = int(apple_count)
        self._data = [[0 for j in range(self._columns)] for i in range(self._rows)]
        self._free_spaces = self._rows * self._columns
        self._snake = []
        self._dimension = int(dimension)
        self._free_spaces = int(dimension) * int(dimension)
        self._direction = 'up'

    @property
    def row_count(self):
        return self._rows

    @property
    def column_count(self):
        return self._columns

    def get(self, x, y):
        return self._data[x][y]

    @property
    def direction(self):
        return self._direction

    @direction.setter
    def direction(self, value):
        self._direction = value

    def check_free(self, x, y):
        """
        Checks if the position [x][y] is free or not.
        Returns True if the position is free and False if not.
        """
        return self.get(x, y) == 0

    def add_apple(self, row, col):
        if self._data[row][col] != "." and self._data[row][col] != "+" and self._data[row][col] != "*":
            if self._data[row + 1][col] != "." and self._data[row - 1][col] != "." and self._data[row][col + 1] != "."\
                    and self._data[row][col - 1] != ".":
                self._data[row][col] = "."

    def set_up(self):
        head = 1
        for i in range(self._rows):
            for j in range(self._columns):
                if j == self._dimension // 2:
                    if self._dimension // 2 - 1 <= i <= self._dimension // 2 + 1:
                        if head != 0:
                            self._data[i][j] = '*'
                            self._snake.append([i, j, 'up'])
                            head -= 1
                        else:
                            self._data[i][j] = '+'
                            self._snake.append([i, j, 'up'])

        available_moves = []
        for k in range(self._apples):
            for col in range(self._columns):
                for row in range(self._rows):
                    if self.check_free(row, col):
                        available_moves.append((row, col))
            # Pick one of the available moves
            place = random.choice(available_moves)
            # self.add_apple(place[1], place[0])
            self._data[place[1]][place[0]] = '.'

    def __len__(self):
        return len(self._snake)

    def move(self, n):
        if n is None:
            head = 1
            i = 0
            for position in self._snake:
                if head != 0:
                    if position[2] == 'up':
                        if self._data[position[0] + 1][position[1]] != '+':
                            self._data[position[0]][position[1]] = 0
                            position[0] += 1
                            self._snake[i] = [position[0], position[1], position[2]]
                            self._data[position[0]][position[1]] = '*'
                            head = 1
                            i += 1
                        else:
                            raise Exception('Cannot move snake in that direction!')
                    elif position[2] == 'right':
                        if self._data[position[0]][position[1] + 1] != '+':
                            self._data[position[0]][position[1]] = 0
                            position[1] += 1
                            self._snake[i] = [position[0], position[1], position[2]]
                            self._data[position[0]][position[1]] = '*'
                            head = 1
                            i += 1
                        else:
                            raise Exception('Cannot move snake in that direction!')
                    elif position[2] == 'left':
                        if self._data[position[0]][position[1] - 1] != '+':
                            self._data[position[0]][position[1]] = 0
                            position[1] -= 1
                            self._snake[i] = [position[0], position[1], position[2]]
                            self._data[position[0]][position[1]] = '*'
                            head = 1
                            i += 1
                        else:
                            raise Exception('Cannot move snake in that direction!')
                    elif position[2] == 'down':
                        if self._data[position[0] - 1][position[1]] != '+':
                            self._data[position[0]][position[1]] = 0
                            position[0] -= 1
                            self._snake[i] = [position[0], position[1], position[2]]
                            self._data[position[0]][position[1]] = '*'
                            head = 1
                            i += 1
                        else:
                            raise Exception('Cannot move snake in that direction!')
                else:
                    if position[2] == 'up':
                        if self._data[position[0] + 1][position[1]] != '+':
                            self._data[position[0]][position[1]] = 0
                            position[0] += 1
                            self._snake[i] = [position[0], position[1], position[2]]
                            self._data[position[0]][position[1]] = '+'
                            i += 1
                        else:
                            raise Exception('Cannot move snake in that direction!')
                    elif position[2] == 'right':
                        if self._data[position[0]][position[1] + 1] != '+':
                            self._data[position[0]][position[1]] = 0
                            position[1] += 1
                            self._snake[i] = [position[0], position[1], position[2]]
                            self._data[position[0]][position[1]] = '+'
                            i += 1
                        else:
                            raise Exception('Cannot move snake in that direction!')
                    elif position[2] == 'left':
                        if self._data[position[0]][position[1] - 1] != '+':
                            self._data[position[0]][position[1]] = 0
                            position[1] -= 1
                            self._snake[i] = [position[0], position[1], position[2]]
                            self._data[position[0]][position[1]] = '+'
                            i += 1
                        else:
                            raise Exception('Cannot move snake in that direction!')
                    elif position[2] == 'down':
                        if self._data[position[0] - 1][position[1]] != '+':
                            self._data[position[0]][position[1]] = 0
                            position[0] -= 1
                            self._snake[i] = [position[0], position[1], position[2]]
                            self._data[position[0]][position[1]] = '+'
                            i += 1
                        else:
                            raise Exception('Cannot move snake in that direction!')
        else:
            i = 0
            for position2 in self._snake:
                if position2[2] == 'up':
                    # if self._data[position2[0] + 1][position2[1]] != '+':
                    self._data[position2[0]][position2[1]] = 0
                    position2[0] += n
                    self._snake[i] = [position2[0], position2[1], position2[2]]
                    if i == 0:
                        self._data[position2[0]][position2[1]] = "*"
                    else:
                        self._data[position2[0]][position2[1]] = "+"
                    i += 1
                # else:
                #     raise Exception('Cannot move snake in that direction!')
                elif position2[2] == 'right':
                    if self._data[position2[0]][position2[1] + 1] != '+':
                        self._data[position2[0]][position2[1]] = 0
                        position2[1] += n
                        self._snake[i] = [position2[0], position2[1], position2[2]]
                        if i == 0:
                            self._data[position2[0]][position2[1]] = "*"
                        else:
                            self._data[position2[0]][position2[1]] = "+"
                        i += 1
                    else:
                        raise Exception('Cannot move snake in that direction!')
                elif position2[2] == 'left':
                    if self._data[position2[0]][position2[1] - 1] != '+':
                        self._data[position2[0]][position2[1]] = 0
                        position2[1] -= n
                        self._snake[i] = [position2[0], position2[1], position2[2]]
                        if i == 0:
                            self._data[position2[0]][position2[1]] = "*"
                        else:
                            self._data[position2[0]][position2[1]] = "+"
                        i += 1
                    else:
                        raise Exception('Cannot move snake in that direction!')
                elif position2[2] == 'down':
                    if self._data[position2[0] - 1][position2[1]] != '+':
                        self._data[position2[0]][position2[1]] = 0
                        position2[0] -= n
                        self._snake[i] = [position2[0], position2[1], position2[2]]
                        if i == 0:
                            self._data[position2[0]][position2[1]] = "*"
                        else:
                            self._data[position2[0]][position2[1]] = "+"
                        i += 1
                    else:
                        raise Exception('Cannot move snake in that direction!')

    def move_direction(self, where):
        if where == 'up':
            for position in self._snake:
                if where == 'up':
                    self._snake[position[2]] = 'up'
                    self._data[position[0]][position[1]] = 0
                    position[0] += 1
                    self._snake[0] = [position[0], position[1], position[2]]
                    self._data[position[0]][position[1]] = '*'
                elif where == 'right':
                    self._snake[position[2]] = 'right'
                    self._data[position[0]][position[1]] = 0
                    position[1] += 1
                    self._snake[0] = [position[0], position[1], position[2]]
                    self._data[position[0]][position[1]] = '*'
                elif where == 'left':
                    self._snake[position[2]] = 'left'
                    self._data[position[0]][position[1]] = 0
                    position[1] -= 1
                    self._snake[0] = [position[0], position[1], position[2]]
                    self._data[position[0]][position[1]] = '*'
                elif where == 'down':
                    self._snake[position[2]] = 'down'
                    self._data[position[0]][position[1]] = 0
                    position[0] -= 1
                    self._snake[0] = [position[0], position[1], position[2]]
                    self._data[position[0]][position[1]] = '*'
                break

    def __str__(self):
        table = Texttable()
        for row in range(self._rows):
            row_data = []
            for index in self._data[row]:
                if index == 0:
                    row_data.append(' ')
                else:
                    row_data.append(index)
            table.add_row(row_data)
        return table.draw()


board = Board(7, 10)
board.set_up()
board.move_direction('left')
print(board.__str__())
