from BOARD.board import Board


class Game:

    def __init__(self):
        self._board = Board()

    def snake_move(self, n):
        self._board.move(n)

    def snake_direction(self, direction):
        pass

    def snake_ate(self):
        pass
