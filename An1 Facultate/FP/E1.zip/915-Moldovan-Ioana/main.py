from BOARD.board import Board
from GAME.game import Game
from UI.ui import Console


import configparser

if __name__ == '__main__':

    cfg = configparser.ConfigParser()

    cfg.read('settings.properties')
    m_dict = dict(cfg.items('DEFAULT'))
    dimension = m_dict['dimension'].strip()
    apple_count = m_dict['apples'].strip()

    board = Board(dimension, apple_count)
    game = Game

    console = Console(board, game)
    console.start()
