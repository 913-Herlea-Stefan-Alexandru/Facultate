from BOARD.board import Board
from GAME.game import Game


class Console:
    def __init__(self, board, game):
        self._board = board
        self._game = game


    @staticmethod
    def read_human_move():
        coord = input('your move>')
        coord = coord.split()
        if len(coord) == 1:
            return coord[0]
        else:
            return coord[0], coord[1]

    def start(self):
        finished = False
        while finished:
            coordinates = self.read_human_move()
            if len(coordinates) == 1:
                if coordinates[0] == 'move':
                    self._game.snake_move(None)
                else:
                    self._game.snake_direction(coordinates[0])
            else:
                self._game.snake_move(coordinates[1])
