class Snake:
    def __init__(self, positions):
        self.pos = positions
        self.direction = 'up'
