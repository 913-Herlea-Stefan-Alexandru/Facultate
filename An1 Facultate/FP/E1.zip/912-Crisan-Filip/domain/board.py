from texttable import Texttable


class Board:
    def __init__(self, dim, apple_count):
        self.dim = dim
        self.apple_count = apple_count
        self.grid = [['' for i in range(dim)] for j in range(dim)]

    def get_square(self, row, col):
        return self.grid[row][col]

    def set_square(self, row, col, value):
        self.grid[row][col] = value

    def is_square_empty(self, row, col):
        return self.grid[row][col] == ''

    def __str__(self):
        t = Texttable()
        for i in range(self.dim):
            t.add_row(self.grid[i])
        return t.draw()
