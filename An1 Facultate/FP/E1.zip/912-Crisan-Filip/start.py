from domain.board import Board
from services.board_service import BoardService
from settings.settings_handler import Settings
from ui.console import UI

settings = Settings()
board = Board(settings.dim, settings.apple_count)
board_service = BoardService(board)
ui = UI(board_service)
ui.run()
