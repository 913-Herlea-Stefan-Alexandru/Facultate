from copy import deepcopy

from domain.snake import Snake
import random


class BoardService:
    def __init__(self, board):
        self.board = board
        self.snake = self.get_snake()
        self.dir_row = {'up': -1, 'right': 0, 'down': 1, 'left': 0}
        self.dir_col = {'up': 0, 'right': 1, 'down': 0, 'left': -1}
        self.is_game_over = False

    def get_snake(self):
        positions = [[self.board.dim // 2 - 1, self.board.dim // 2],
                     [self.board.dim // 2, self.board.dim // 2],
                     [self.board.dim // 2 + 1, self.board.dim // 2]]
        return Snake(positions)

    def check_apple_position(self, row, col):
        if not self.board.is_square_empty(row, col):
            return False
        if row + 1 < self.board.dim and self.board.get_square(row + 1, col) == '.':
            return False
        if col + 1 < self.board.dim and self.board.get_square(row, col + 1) == '.':
            return False
        if row - 1 >= 0 and self.board.get_square(row - 1, col) == '.':
            return False
        if col - 1 >= 0 and self.board.get_square(row, col - 1) == '.':
            return False
        return True

    def cannot_place_apple(self):
        counter = 0
        for i in range(self.board.dim):
            for j in range(self.board.dim):
                if self.check_apple_position(i, j):
                    counter += 1
        return counter == 0

    def place_apples(self, apple_count):
        """
        Tries to place randomly apple_count apples on the board, such that they are not neighbors on row or on column.
        :param apple_count: The number of apples
        :return: -
        Raises ValueError if it cannot place all the apples
        """
        counter = 0
        while counter < apple_count:
            row = random.randint(0, self.board.dim - 1)
            col = random.randint(0, self.board.dim - 1)
            if self.cannot_place_apple():
                raise ValueError('Cannot place all apples!')
            if self.check_apple_position(row, col):
                self.board.set_square(row, col, '.')
                counter += 1

    def place_snake(self):
        # place the head
        self.board.set_square(self.snake.pos[0][0], self.snake.pos[0][1], '*')

        # place the remaining body
        for i in range(1, len(self.snake.pos)):
            self.board.set_square(self.snake.pos[i][0], self.snake.pos[i][1], '+')

    def initial_state(self):
        # place the snake
        self.place_snake()

        # place the apple_count apples
        self.place_apples(self.board.apple_count)

    def is_square_valid(self, row, col):
        return 0 <= row < self.board.dim and 0 <= col < self.board.dim

    def eats_itself(self, row, col, end_row, end_col):
        return self.board.get_square(row, col) == '+' and (row != end_row or col != end_col)

    def update_snake(self):
        """
        This actually updates the board with the given state of the snake.

        :return: -
        """
        for i in range(self.board.dim):
            for j in range(self.board.dim):
                if self.board.get_square(i, j) == '*' or self.board.get_square(i, j) == '+':
                    self.board.set_square(i, j, '')
        self.place_snake()

    def game_over(self):
        return self.is_game_over

    def move(self, n):
        """
        This is the main function that moves the snake on the board.

        :param n: The number of steps
        :return: -
        """
        for i in range(n):
            # check if we can move the head
            row_head = self.snake.pos[0][0]
            col_head = self.snake.pos[0][1]
            new_row = row_head + self.dir_row[self.snake.direction]
            new_col = col_head + self.dir_col[self.snake.direction]
            if not self.is_square_valid(new_row, new_col):
                self.is_game_over = True
                break
            last_pos = deepcopy(self.snake.pos[len(self.snake.pos) - 1])
            if self.eats_itself(new_row, new_col, last_pos[0], last_pos[1]):
                self.is_game_over = True
                break
            self.snake.pos.pop()
            self.snake.pos.insert(0, [new_row, new_col])
            if self.board.get_square(new_row, new_col) == '.':
                self.board.set_square(new_row, new_col, '')
                try:
                    self.place_apples(1)
                except ValueError as ve:
                    print(str(ve))
                self.snake.pos.append(last_pos)
            self.update_snake()

    def up(self):
        if self.snake.direction == 'up':
            return
        if self.snake.direction == 'down':
            raise ValueError('Cannot move that way!')
        self.snake.direction = 'up'
        self.move(1)

    def right(self):
        if self.snake.direction == 'right':
            return
        if self.snake.direction == 'left':
            raise ValueError('Cannot move that way!')
        self.snake.direction = 'right'
        self.move(1)

    def down(self):
        if self.snake.direction == 'down':
            return
        if self.snake.direction == 'up':
            raise ValueError('Cannot move that way!')
        self.snake.direction = 'down'
        self.move(1)

    def left(self):
        if self.snake.direction == 'left':
            return
        if self.snake.direction == 'right':
            raise ValueError('Cannot move that way!')
        self.snake.direction = 'left'
        self.move(1)
