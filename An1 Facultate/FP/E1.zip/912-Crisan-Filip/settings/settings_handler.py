"""
    This handles the settings of the repos.
"""


class Settings:
    def __init__(self, file_name='settings.properties'):
        self.dim = 0
        self.apple_count = 0
        self.load_file(file_name)

    def load_file(self, file_name):
        f = open(file_name, 'r')
        lines = f.readlines()
        f.close()

        for line in lines:
            line = line.strip('\n').split('=')
            element = line[0].strip()
            value = line[1].strip()
            if element == 'DIM':
                self.dim = int(value)
            elif element == 'apple_count':
                self.apple_count = int(value)
