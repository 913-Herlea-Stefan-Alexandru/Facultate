class UI:
    def __init__(self, board_service):
        self.board_service = board_service
        self._commands_list = {
            'move': self.move_ui,
            'up': self.up_ui,
            'right': self.right_ui,
            'down': self.down_ui,
            'left': self.left_ui
        }

    def move_ui(self, param):
        if param is None:
            n = 1
        else:
            n = int(param)
        self.board_service.move(n)

    def up_ui(self, param):
        self.board_service.up()

    def right_ui(self, param):
        self.board_service.right()

    def down_ui(self, param):
        self.board_service.down()

    def left_ui(self, param):
        self.board_service.left()

    @staticmethod
    def get_command():
        tokens = (input('> ').strip()).split()
        # validate the number of params
        if len(tokens) == 1:
            if tokens[0] not in ['up', 'down', 'right', 'left', 'move', 'exit']:
                raise ValueError('Invalid command!')
            return tokens[0].strip(), None
        elif len(tokens) == 2:
            if tokens[0] != 'move':
                raise ValueError('Invalid command!')
            return tokens[0].strip(), tokens[1].strip()
        else:
            raise ValueError('Invalid command!')

    def run(self):
        try:
            self.board_service.initial_state()
        except ValueError as ve:
            print(str(ve))
        done = False
        game_over = False
        while not done and not game_over:
            try:
                print(self.board_service.board)
                command, param = UI.get_command()
                if command in self._commands_list:
                    self._commands_list[command](param)
                elif command == 'exit':
                    done = True
                else:
                    print(command)
                if self.board_service.game_over():
                    print('Game over!')
                    game_over = True
            except Exception as e:
                print(str(e))
