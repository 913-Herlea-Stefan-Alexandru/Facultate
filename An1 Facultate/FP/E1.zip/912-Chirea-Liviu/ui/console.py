import texttable

from service.boardservice import BoardService


class Console:
    def __init__(self, dim, apple_count):
        self._dim = dim
        self._bservice = BoardService(dim, apple_count)
        self.printb()
        self.start()


    def start(self):
        done = False
        while not done:
            command = input("\n>>> ").lower().split(' ')
            try:
                if command[0].strip() == 'move':
                    if len(command) == 1:
                        a = self.move_ui(1)
                        if a is False:
                            done = True
                    else:
                        try:
                            command[1] = int(command[1])
                        except ValueError:
                            raise ValueError("Invalid parameter")

                        a = self.move_ui(command[1])
                        if a is False:
                            done = True
                elif command[0].strip() == 'right':
                    self.dir_ui("right")
                elif command[0].strip() == 'left':
                    self.dir_ui("left")
                elif command[0].strip() == 'down':
                    self.dir_ui("down")
                elif command[0].strip() == 'up':
                    self.dir_ui("up")
                else:
                    raise ValueError("Invalid command")
                self.printb()
            except ValueError as ve:
                print(ve)
        print("GAME OVER")

    def dir_ui(self, d):
        self._bservice.dir(d)

    def move_ui(self, count):
        a = True
        for i in range(0, count):
            a = self._bservice.move()
            if a is False:
                break
        return a


    def printb(self):
        print("\n\n\n ############################################\n\n\n")
        table = texttable.Texttable()
        board = self._bservice.getboard()
        for i in range(0, self._dim):
            row = []
            for j in range(0, self._dim):
                row.append(board[i][j])
            table.add_row(row)
        print(table.draw())

