from repo.boardrepo import BoardRepo


class BoardService:
    def __init__(self, dim, apple_count):
        self._dim = dim
        self._repo = BoardRepo(dim, apple_count)
        self._direction = "up"
        self._head, self._tail = self._repo.get()

    def dir(self, d):
        if d == self._direction:
            raise ValueError("Already going in that direction, jimbo!")
        if (d == "left" and self._direction == "right") or (d == "right" and self._direction == "left") or (d == "up" and self._direction == "down") or (d == "down" and self._direction == "up"):
            raise ValueError("WHIPLASH! Try again!")
        self._direction = d
        self.move()

    def getboard(self):
        return self._repo.getboard()

    def move(self):
        if self._direction == 'up':
            if self._head[0]-1 < 0:
                return False
            else:
                self._head, self._tail, hit = self._repo.move(self._head, self._tail, 'up')
        if self._direction == 'down':
            if self._head[0]+1 >= self._dim:
                return False
            else:
                self._head, self._tail, hit = self._repo.move(self._head, self._tail, 'down')
        if self._direction == 'left':
            if self._head[1]-1 < 0:
                return False
            else:
                self._head, self._tail, hit= self._repo.move(self._head, self._tail, 'left')
        if self._direction == 'right':
            if self._head[1]+1 >= self._dim:
                return False
            else:
                self._head, self._tail, hit= self._repo.move(self._head, self._tail, 'right')
        if hit == "snake":
            return False
        if hit == "apple":
            self._repo.place_apples(1)



