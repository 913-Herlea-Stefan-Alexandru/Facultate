import random

from domain.board import Board

class BoardRepo:
    def __init__(self, dim, apple_count):
        self._dim = dim
        self._board = Board(dim)
        self._apple_count = apple_count
        self.place_snake()
        self.place_apples(apple_count)

    def place_apples(self, value):
        for i in range(1, value+1):
            x = False
            while x is False:
                i = random.randint(0, self._dim - 1)
                j = random.randint(0, self._dim - 1)
                if self._board.check(i, j) == "empty" and self._board.check_adjacency(i+1,j) and self._board.check_adjacency(i,j-1) and self._board.check_adjacency(i,j+1) and self._board.check_adjacency(i-1,j):
                    self._board.place_apple(i, j)
                    x = True

    def place_snake(self):
        self._board.board[self._dim//2-1][self._dim//2] = '*'
        self._board.board[self._dim // 2][self._dim // 2] = '+'
        self._board.board[self._dim // 2+1][self._dim // 2] = '+'

    def getboard(self):
        return self._board.board

    def get(self):
        return [self._dim//2-1, self._dim//2], [self._dim // 2+1, self._dim // 2]

    def move(self, head, tail, d):
        self._board.board[tail[0]][tail[1]] = ' '
        self._board.board[head[0]][head[1]] = '+'
        if d == 'up':
            hit = self._board.check(head[0] - 1, head[1])
            self._board.board[head[0]-1][head[1]] = '*'
            return [head[0]-1, head[1]], [tail[0], tail[1]], hit
        if d == "down":
            hit = self._board.check(head[0] + 1, head[1])
            self._board.board[head[0]+1][head[1]] = '*'
            return [head[0]+1, head[1]], [tail[0], tail[1]], hit
        if d == "right":
            hit = self._board.check(head[0], head[1]+1)
            self._board.board[head[0]][head[1]+1] = '*'
            return [head[0], head[1]+1], [tail[0], tail[1]], hit
        if d == "left":
            hit = self._board.check(head[0], head[1]-1)
            self._board.board[head[0]][head[1] - 1] = '*'
            return [head[0], head[1]-1], [tail[0], tail[1]], hit