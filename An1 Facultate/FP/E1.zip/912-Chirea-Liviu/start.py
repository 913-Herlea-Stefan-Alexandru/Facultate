from ui.console import Console

f = open("settings.ini", "r")
line = f.readline().strip().split(' ')

start = Console(int(line[0]), int(line[1]))