class Board:
    def __init__(self, dim):
        self._dim = dim
        self._board = []
        for i in range(0, dim):
            self._board.append([])
            for j in range(0, dim):
                self._board[i].append(' ')


    @property
    def board(self):
        return self._board

    @board.setter
    def board(self, value):
        self._board = value

    def check(self, i, j):
        if self._board[i][j] == ' ':
            return "empty"
        elif self._board[i][j] == '*' or self._board[i][j] == '+':
            return "snake"
        elif self._board[i][j] == '.':
            return "apple"

    def check_adjacency(self, i, j):
        if i < 0 or i >= self._dim or j < 0 or j>= self._dim:
            return True
        if self._board[i][j] in ['*', '+', ' ']:
            return True
        else:
            return False

    def tail_check(self, i , j):
        if i < 0 or i >= self._dim or j < 0 or j>= self._dim:
            return [None, None]
        if self._board[i][j] == "+":
            return [i, j]

    def place_apple(self, i, j):
        self._board[i][j] = '.'

a = Board(3)