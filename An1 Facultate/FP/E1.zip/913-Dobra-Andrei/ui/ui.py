from services.BoardService import BoardService, BoardServiceException

class UI:
    def __init__(self, board_service:BoardService):
        self._board_service = board_service
        self._command_dict = {'move': self.move_ui, 'left':self.left_ui, 'right':self.right_ui, 'up':self.up_ui, 'down':self.down_ui}


    def move_ui(self, params = ""):
        self._board_service.move(params)

    def up_ui(self, params=""):
        if params != "":
            print("Invalid input!")
            return
        d = self._board_service.change_direction(1)
        if d == 1:
            self.move_ui()

    def right_ui(self, params=""):
        if params != "":
            print("Invalid input!")
            return
        d = self._board_service.change_direction(2)
        if d == 1:
            self.move_ui()

    def down_ui(self, params=""):
        if params != "":
            print("Invalid input!")
            return
        d = self._board_service.change_direction(3)
        if d == 1:
            self.move_ui()

    def left_ui(self, params=""):
        if params != "":
            print("Invalid input!")
            return
        d = self._board_service.change_direction(4)
        if d == 1:
            self.move_ui()

    def split_command(self,command):
        if command == '':
            return '', ''

        tokens = command.strip().split(' ', 1)
        command_word = tokens[0].lower().strip()
        if len(tokens) == 2:
            command_params = tokens[1].strip()
        else:
            command_params = ''

        return command_word, command_params

    def menu(self):
        self._board_service.place_apples()
        print(self._board_service._board)
        can_play = True
        while can_play:
            command = input('>')
            command_word, command_params = self.split_command(command)
            if command_word not in self._command_dict:
                print("Invalid command")
            else:
                try:
                    self._command_dict[command_word](command_params)
                except BoardServiceException as bse:
                    print(bse)
            can_play = self._board_service._can_play
            if can_play:
                print(self._board_service._board)
            else:
                print("\nGAME OVER! :(")

            if self._board_service._game_won:
                print(("\nYOU WON!"))
                can_play = False
