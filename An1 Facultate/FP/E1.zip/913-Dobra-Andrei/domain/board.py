from texttable import Texttable

class Board:
    def __init__(self,dim,apples):
        self._rows = dim
        self._cols = dim
        self._apple_count = apples
        self._apples_placed = 0
        self._data = [[0 for col in range(self._cols + 2)] for row in range(self._rows + 2)]
        # 0 - empty space
        # 1 - snake part
        # 10 - snake head
        # 20 - apple
        self._snake = [[dim//2+2,dim//2+1],[dim//2+1,dim//2+1],[dim//2,dim//2+1]]
        for p in self._snake:
            self._data[p[0]][p[1]] = 1
        self._data[self._snake[2][0]][self._snake[2][1]] = 10
        self._direction = 1
        # 1 - up
        # 2 - right
        # 3 - down
        # 4 - left

    def place_apple(self,i,j):
        self._data[i][j] = 20
        self._apples_placed += 1


    def check(self,i,j):
        return self._data[i][j]

    def __str__(self):
        t = Texttable()

        for row in range(1, self._rows + 1):
            data = []

            for val in self._data[row][1:-1]:
                if val == 0:
                    data.append(' ')
                elif val == 10:
                    data.append('*')
                elif val == 1:
                    data.append('+')
                elif val == 20:
                    data.append('.')

            t.add_row(data)
        return t.draw()
