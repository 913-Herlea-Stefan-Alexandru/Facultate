from domain.board import Board
from random import randint
from copy import deepcopy

class BoardServiceException(Exception):
    def __init__(self, msg = None):
        self._msg = msg

    def __str__(self):
        return self._msg

class BoardService:
    def __init__(self, board:Board):
        self._board = board
        self._can_play = True
        self._game_won = False

    def place_apples(self):
        apples_to_be_placed = self._board._apple_count
        board_spaces = self._board._rows * self._board._cols
        board_spaces -= len(self._board._snake)

        if board_spaces == 0:
            self._game_won = True

        available = []
        for i in range (1,self._board._rows+1):
            for j in range (1,self._board._cols+1):
                if self._board._data[i][j] == 0:
                    available.append([i,j])

        while self._board._apples_placed < apples_to_be_placed:
            ok = False
            while not ok:
                if len(available) == 0:
                    return
                nr = randint(0,len(available)-1)
                row = available[nr][0]
                col = available[nr][1]
                if self._board.check(row,col)==0 and self._board.check(row+1,col)!=20 and self._board.check(row-1,col)!=20 and self._board.check(row,col-1)!=20 and self._board.check(row,col+1)!=20:
                    ok = True

                available.pop(nr)


            self._board.place_apple(row,col)

    def change_direction(self,val):
        dir = self._board._direction
        if dir == val:
            return 0
        if dir != val and dir+val == 4 or dir+val == 6:
            raise BoardServiceException("Can't go 180!")
        self._board._direction = val
        return 1

    def move(self,num = ""):

        if num != "":
            try:
                num = int(num)
            except: raise BoardServiceException("Invalid input!")
        else:
            num = 1
        snake = self._board._snake
        dir = self._board._direction

        while num > 0 and self._can_play:
            h = len(snake) - 1
            delete = True
            self._board._data[snake[h][0]][snake[h][1]] = 1
            ss = deepcopy(snake[h])
            if dir == 1:
                ss[0] -= 1
            elif dir == 2:
                ss[1] += 1
            elif dir == 3:
                ss[0] += 1
            elif dir == 4:
                ss[1] -= 1

            if ss[0] < 1 or ss[0] > self._board._rows or ss[1] < 1 or ss[1] > self._board._cols:
                self._can_play = False



            snake.append(ss)
            if self._board._data[ss[0]][ss[1]] == 20:
                delete = False
                self._board._data[ss[0]][ss[1]] = 10
                self._board._apples_placed -= 1


            if delete:
                self._board._data[snake[0][0]][snake[0][1]] = 0
                snake.pop(0)

            if self._board._data[ss[0]][ss[1]] == 1:
                self._can_play = False

            self._board._data[ss[0]][ss[1]] = 10

            if not delete:
                self.place_apples()

            num -= 1

