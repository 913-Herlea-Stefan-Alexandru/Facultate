from domain.board import Board
from services.BoardService import BoardService
from ui.ui import UI
from settings import Settings

sett = Settings()

dim,apple_count = sett.decide_values()

board = Board(int(dim),int(apple_count))
bs = BoardService(board)
ui = UI(bs)
ui.menu()
