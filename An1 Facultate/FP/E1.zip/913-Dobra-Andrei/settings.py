import  configparser

class Settings:
    def __init__(self):
        self._config = configparser.ConfigParser()

    def decide_values(self):
        self._config.read("settings.properties")
        return self._config["Settings"]["DIM"], self._config["Settings"]["apple_count"]
