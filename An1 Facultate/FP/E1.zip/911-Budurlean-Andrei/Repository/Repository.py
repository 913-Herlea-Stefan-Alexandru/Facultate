from Domain.Board import GameBoard
from random import randint


class Repository:
    def __init__(self):
        self._snake = []
        self._game_board = None
        self._dim = None  # The dimension of the board
        self._settings_file_path = "../settings.txt"

        try:
            open(self._settings_file_path, "x")
        except Exception:
            pass

    def board(self):
        return self._game_board.board

    def head_position(self):
        """
        Returns the position of the head of the snake
        :return: the position of the head of the snake
        """
        return self._snake[0]

    @property
    def dim(self):
        return self._dim

    def move_snake(self, row, col):
        """
        Move the snake towards the square at the coordinates row and col
        :param row: the row of the square
        :param col: the column of the square
        :return: True if the snake exited the map of ate itself, False otherwise
        """
        cell = self._game_board.clear(row, col)
        if cell == "+" and (self._snake[-1][0] != row or self._snake[-1][1] != col):
            return True
        self._game_board.clear(self._snake[0][0], self._snake[0][1])
        self._game_board.place(self._snake[0][0], self._snake[0][1], "+")
        if cell == ".":
            self._snake.append([0, 0])
        else:
            self._game_board.clear(self._snake[-1][0], self._snake[-1][1])

        for i in range(len(self._snake) - 1, 0, -1):
            self._snake[i] = self._snake[i - 1]
        self._snake[0] = [row, col]

        self._game_board.place(row, col, "*")

        if cell == ".":
            self.place_apple()

        return False

    def read_settings(self):
        """
        Read from the settings, initialize the board and place the apples
        :return: nothing
        """
        file = open(self._settings_file_path, "r")

        line = file.readline()
        dim, apple_count = line.split(" ")
        self._dim = int(dim)
        apple_count = int(apple_count)
        self._game_board = GameBoard(self._dim)

        self.place_snake()

        while apple_count:
            self.place_apple()
            apple_count -= 1

    def place_snake(self):
        """
        Place the snake at the start of the game
        :return: nothing
        """
        self._snake.append([self._dim // 2 - 1, self._dim // 2])
        self._game_board.place(self._dim // 2 - 1, self._dim // 2, "*")

        self._snake.append([self._dim // 2, self._dim // 2])
        self._game_board.place(self._dim // 2, self._dim // 2, "+")

        self._snake.append([self._dim // 2 + 1, self._dim // 2])
        self._game_board.place(self._dim // 2 + 1, self._dim // 2, "+")

    def place_apple(self):
        """
        Place an apple randomly. The function stops if it tries 1000 times to place an apple
        This will most likely occur when we cannot insert an apple.
        :return: nothing
        """
        placed = False
        iteration = 0
        while not placed:
            iteration += 1
            if iteration == 1000:
                return
            i = randint(0, self._dim - 1)
            j = randint(0, self._dim - 1)

            if i != 0:
                if self._game_board.board[i - 1][j] == ".":
                    continue
            if i != self._dim - 1:
                if self._game_board.board[i + 1][j] == ".":
                    continue
            if j != 0:
                if self._game_board.board[i][j - 1] == ".":
                    continue
            if j != self._dim - 1:
                if self._game_board.board[i][j + 1] == ".":
                    continue

            placed = self._game_board.place(i, j, ".")
