from Repository.Repository import Repository
from texttable import Texttable


class Service:
    def __init__(self):
        self._repository = Repository()
        self._repository.read_settings()
        self._direction = "U"

    @property
    def direction(self):
        return self._direction

    @direction.setter
    def direction(self, direction):
        self._direction = direction

    def move_snake(self):
        """
        Move the snake in the direction indicated by "self._direction"
        :return: True if the game ends, False otherwise
        """
        head = self._repository.head_position()
        row = head[0]
        col = head[1]
        if self._direction == "U":
            row -= 1
        elif self._direction == "D":
            row += 1
        elif self._direction == "L":
            col -= 1
        else:
            col += 1

        if row == -1 or col == -1 or row == self._repository.dim or col == self._repository.dim:
            return True

        return self._repository.move_snake(row, col)

    def board_to_texttable(self):
        """
        Convert the board to a texttable
        :return: the string corresponding to the texttable
        """
        table = Texttable()

        for row in self._repository.board():
            table.add_row(row)

        return table.draw()
