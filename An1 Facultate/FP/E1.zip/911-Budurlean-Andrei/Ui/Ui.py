from Service.Service import Service


class Ui:
    def __init__(self):
        self._service = Service()

    def make_move(self, command):
        """
        Make a move based on the parameter "command"
        U - Up
        D - Down
        L - Left
        R - Right
        Depending on the command, we can change the direction the snake goes
        :param command: a list containing the split command
        :return: True if the game ends, False otherwise
        """
        if len(command) == 1:
            if command[0] == "move":
                return self._service.move_snake()
            elif command[0] == "up":
                if self._service.direction == "D":  # Cannot do 180 moves
                    raise ValueError("Invalid direction!")
                if self._service.direction == "U":
                    return False
                self._service.direction = "U"
                return self._service.move_snake()
            elif command[0] == "down":
                if self._service.direction == "U":  # Cannot do 180 moves
                    raise ValueError("Invalid direction!")
                if self._service.direction == "D":
                    return False
                self._service.direction = "D"
                return self._service.move_snake()
            elif command[0] == "right":
                if self._service.direction == "L":  # Cannot do 180 moves
                    raise ValueError("Invalid direction!")
                if self._service.direction == "R":
                    return False
                self._service.direction = "R"
                return self._service.move_snake()
            elif command[0] == "left":
                if self._service.direction == "R":  # Cannot do 180 moves
                    raise ValueError("Invalid direction!")
                if self._service.direction == "L":
                    return False
                self._service.direction = "L"
                return self._service.move_snake()
            else:
                raise ValueError("Invalid command!")

        elif len(command) == 2:
            if command[0] == "move":
                dist = 0
                try:
                    dist = int(command[1])
                except ValueError:
                    print("Invalid command!")
                while dist:
                    game_over = self._service.move_snake()
                    dist -= 1
                    if game_over:
                        return game_over
            else:
                raise ValueError("Invalid command!")
        else:
            raise ValueError("Invalid command!")

    def start(self):
        game_over = False

        print(self._service.board_to_texttable())
        while not game_over:
            try:
                command = input()
                command = command.split(" ")
                game_over = self.make_move(command)
                print(self._service.board_to_texttable())
            except ValueError as ve:
                print(str(ve))

        print("Game Over!")


ui = Ui()
ui.start()
