

class GameBoard:
    def __init__(self, dim):
        self._board = []
        for i in range(dim):
            self._board.append([])
            for j in range(dim):
                self._board[i].append(" ")

    @property
    def board(self):
        return self._board

    def place(self, i, j, val):
        """
        Place val in the square corresponding to the coordinates i and j
        :param i: row
        :param j: column
        :param val: the value to be placed
        :return: True if the action completed successfully, False otherwise
        """
        if self._board[i][j] != " ":
            return False

        self._board[i][j] = str(val)
        return True

    def clear(self, i, j):
        """
        Clear and return the value from the square corresponding to the coordinates i and j
        :param i: row
        :param j: column
        :return: the value of the cell
        """
        cell = self._board[i][j]
        self._board[i][j] = " "
        return cell
