from Snake.Domain.Entities import *

import copy
class Reposiroty:

    def __init__(self,dim, apple_count):
        self.dim = dim
        self.apple_count = apple_count
        self.map = [[0,0,0,0,0,0,0,0,0,0],
                      [0,0,0,0,0,0,0,0,0,0],
                      [0,0,0,0,0,0,0,0,0,0],
                      [0,0,0,0,0,0,0,0,0,0],
                      [0,0,0,0,0,0,0,0,0,0],
                      [0,0,0,0,0,0,0,0,0,0],
                      [0,0,0,0,0,0,0,0,0,0],
                      [0,0,0,0,0,0,0,0,0,0],
                      [0,0,0,0,0,0,0,0,0,0],
                      [0,0,0,0,0,0,0,0,0,0]]

    def change_cell(self, i, j, new_status):
        self.map[i][j] = new_status

    def get_cell(self,i,j):
        return self.map[i][j]

    @staticmethod
    def read_text_file(file_name):
        result = []
        try:
            f = open(file_name, "r")
            line = f.readline().strip()
            line = line.split(";")
            result.append( int(line[0]))
            result.append(int(line[1]))
            f.close()
        except IOError as e:
            """
                Here we 'log' the error, and throw it to the outer layers 
            """
            print("An error occured - " + str(e))
            raise e
        return result

    def get_map(self):
        return self.map

    def get_dim(self):
        return self.dim

    def get_apples(self):
        return self.apple_count




