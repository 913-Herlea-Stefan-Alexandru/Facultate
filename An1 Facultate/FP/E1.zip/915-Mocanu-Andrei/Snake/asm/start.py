from Snake.Ui.Console import *

l = Reposiroty.read_text_file("settings.txt")
snake_repo = Reposiroty(l[0], l[1])
snake_service = Service(snake_repo)
snake_service.place_snake()
map = snake_repo.get_map()
snake_service.place_apples()
console =Console(snake_service,snake_repo)
console.run_console()


