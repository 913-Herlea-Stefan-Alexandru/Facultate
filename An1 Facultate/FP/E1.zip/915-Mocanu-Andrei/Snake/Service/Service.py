from Snake.Repository.Repository import *

from random import randint


class Service:
    def __init__(self, snake_repo):
        self.__snake_repo = snake_repo
        self.game_over = 0
        self.head = (self.__snake_repo.get_dim() // 2, self.__snake_repo.get_dim() // 2)
        self.last_cell = []
        self.the_snake =[]

    def place_snake(self):
        self.__snake_repo.change_cell(self.__snake_repo.get_dim() // 2, self.__snake_repo.get_dim() // 2, '*')
        self.__snake_repo.change_cell(self.__snake_repo.get_dim() // 2 + 1, self.__snake_repo.get_dim() // 2, '+')
        self.__snake_repo.change_cell(self.__snake_repo.get_dim() // 2 + 2, self.__snake_repo.get_dim() // 2, '+')
        self.the_snake.append([self.__snake_repo.get_dim() // 2+2, self.__snake_repo.get_dim() // 2])
        self.the_snake.append([self.__snake_repo.get_dim() // 2 + 1, self.__snake_repo.get_dim() // 2])
        self.the_snake.append([self.__snake_repo.get_dim() // 2, self.__snake_repo.get_dim() // 2])
        self.last_cell = self.the_snake.pop(0)

    def place_apples(self):
        for o in range(self.__snake_repo.get_apples()):
            i = randint(0, self.__snake_repo.get_dim())
            j = randint(0, self.__snake_repo.get_dim())
            status = self.__snake_repo.get_cell(i, j)
            if status != '*' and status != '+':
                self.__snake_repo.change_cell(i, j, '.')
            else:
                i = randint(0, self.__snake_repo.get_dim())
                j = randint(0, self.__snake_repo.get_dim())
                self.__snake_repo.change_cell(i, j, '.')

    def move_up(self):
        if (self.__snake_repo.get_cell(self.head[0] - 1, self.head[1]) != '.'):
            self.__snake_repo.change_cell(self.last_cell[0], self.last_cell[1], 0)
        self.__snake_repo.change_cell(self.head[0], self.head[1], '+')
        self.head = [self.head[0] - 1, self.head[1]]
        if self.head [0]>self.__snake_repo.get_dim() or self.head[0]<0 or self.head [1]>self.__snake_repo.get_dim() or self.head[1]<0:
            pass
        self.__snake_repo.change_cell(self.head[0] , self.head[1], '*')
        self.__snake_repo.change_cell(self.last_cell[0], self.last_cell[1], 0)
        self.last_cell = self.the_snake.pop(0)
        self.the_snake.append(self.head)

    def move_down(self):
        if self.__snake_repo.get_cell(self.head[0] + 1, self.head[1]) != '.':
            self.__snake_repo.change_cell(self.last_cell[0], self.last_cell[1], 0)
        self.__snake_repo.change_cell(self.head[0], self.head[1], '+')
        self.head = [self.head[0] + 1, self.head[1]]
        if self.head [0]>self.__snake_repo.get_dim() or self.head[0]<0 or self.head [1]>self.__snake_repo.get_dim() or self.head[1]<0:
            pass
        self.__snake_repo.change_cell(self.head[0] , self.head[1], '*')
        self.__snake_repo.change_cell(self.last_cell[0], self.last_cell[1], 0)
        self.last_cell = self.the_snake.pop(0)
        self.the_snake.append(self.head)

    def move_left(self):
        if self.__snake_repo.get_cell(self.head[0], self.head[1] - 1) != '.':
            self.__snake_repo.change_cell(self.last_cell[0], self.last_cell[1], 0)
        self.__snake_repo.change_cell(self.head[0], self.head[1], '+')
        self.head = [self.head[0], self.head[1] - 1]
        if self.head [0]>self.__snake_repo.get_dim() or self.head[0]<0 or self.head [1]>self.__snake_repo.get_dim() or self.head[1]<0:
            pass
        self.__snake_repo.change_cell(self.head[0], self.head[1] , '*')
        self.__snake_repo.change_cell(self.last_cell[0], self.last_cell[1], 0)
        self.last_cell = self.the_snake.pop(0)
        self.the_snake.append(self.head)

    def move_right(self):
        if self.__snake_repo.get_cell(self.head[0], self.head[1] + 1) != '.':
            self.__snake_repo.change_cell(self.last_cell[0], self.last_cell[1], 0)
        self.__snake_repo.change_cell(self.head[0], self.head[1] , '+')
        self.head = [self.head[0], self.head[1] + 1]
        if self.head [0]>self.__snake_repo.get_dim() or self.head[0]<0 or self.head [1]>self.__snake_repo.get_dim() or self.head[1]<0:
            pass
        self.__snake_repo.change_cell(self.head[0], self.head[1], '*')
        self.__snake_repo.change_cell(self.last_cell[0],self.last_cell[1],0)
        self.last_cell = self.the_snake.pop(0)
        self.the_snake.append(self.head)

    def check_game_over(self):
        return self.game_over

    def advance(self):
        pass
