from Snake.Service.Service import *


class Console:
    def __init__(self, snake_service,repo):
        self.__snake_service = snake_service
        self.repo = repo

    def run_console(self):
        x=''
        while x!='0':
            x= str(input('command='))
            if x== 'up':
                self.move_up()
            if x== 'down':
                self.move_down()
            if x== 'right':
                self.move_right()
            if x== 'left':
                self.move_left()
            if x[0] == 'm':
                if len(x) == 4:
                    self.advance(0)
                else:
                    self.advance(int(x[5]))
            self.check_game_over()
            self.print_map()

    def move_up(self):
        self.__snake_service.move_up()

    def move_down(self):
        self.__snake_service.move_down()

    def move_left(self):
        self.__snake_service.move_left()

    def move_right(self):
        self.__snake_service.move_right()

    def advance(self,squares):
        self.__snake_service.advance()

    def check_game_over(self):
        if self.__snake_service.check_game_over() ==1:
            print("GAME OVER!")

    def print_map(self):
        map = self.repo.get_map()
        for i in map:
            print(i)