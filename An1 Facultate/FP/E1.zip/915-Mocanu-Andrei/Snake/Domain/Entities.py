from dataclasses import dataclass

@dataclass
class Snake:
    head: tuple
    body : list
    direction : chr

