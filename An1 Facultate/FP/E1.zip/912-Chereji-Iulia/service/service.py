from domain.board import Board
from domain.snake import Snake


class Service:
    def __init__(self, board:Board, snake:Snake):
        self._board = board
        self._snake=snake


    def eat_apple(self):
        snake_head_value= self._board.get_board_val(self._snake.get_head_of_snake()[0],self._snake.get_head_of_snake()[1])
        apple=self._board.get_board_val(self._snake.get_head_of_snake()[0]-1,self._snake.get_head_of_snake()[1])
        if apple == 3 and snake_head_value==1:
            last = self._snake.get_tail()[-1]
            self._board.set_board_val(last[0]+1,last[1],2)
            self._snake.increase_tail(int(self._snake.get_length())+1)

    def get_length(self):
        return self._snake.get_length()

    def move(self,params):
        if params==None:
            self._board.move(1)
        else:
            self._board.move(int(params))


    def hits_edge(self):
        head_line=self._snake.get_head_of_snake()[0]
        head_col = self._snake.get_head_of_snake()[1]
        if head_col < 0 or head_line < 0 or head_col>self._board.dim-1 or head_line>self._board.dim-1 :
            return True
        return False




