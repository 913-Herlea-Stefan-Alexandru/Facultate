import random

from domain.snake import Snake


class Board:
    def __init__(self, M, nr_of_apples, snake:Snake):
        self._board = []
        self._dim = M
        self._nr_of_apples = nr_of_apples
        self._snake = snake

    @property
    def get_board(self):
        return self._board

    @property
    def dim(self):
        return self._dim

    @property
    def nr_of_apples(self):
        return self._nr_of_apples

    def set_dim(self,val):
        self._dim=val

    def set_nr_of_apples(self, val):
        self._nr_of_apples=val

    def set_board_val(self,l,c,val):
        self._board[l][c]=val

    def get_board_val(self, l,c):
        return self._board[l][c]

    def create_board(self):
        """
        This function creates the board with the given dimensions.
        The board will be a list of lists, each list will represent a row, and each element of these lists will
        represent a column.
        """
        for r in range(self._dim):
            board = []
            for c in range(self._dim):
                board.append(0)
            self._board.append(board)

        self.place_snake_beginning()
        self.place_random_apples()

    def place_snake_beginning(self):
        """
        we place the snake in the middle of the board
        1 is for its head
        2 is for its body
        :return:
        """
        middle=self._dim//2

        self._board[middle][middle]= 1 #head of snake
        self._board[middle+1][middle] = 2 #body
        self._board[middle + 2][middle] = 2

    def are_adjacent(self,l,c):
        if c+1 < self._dim and self._board[l][c+1]==0 or c-1 >0 and self._board[l][c-1]==0 or \
        l-1 >0 and self._board[l-1][c]==0 or l+1>self._dim and self._board[l+1][c]==0:
            return False
        return True

    def move(self,nr_moves):
        while nr_moves !=0:
            list=self._snake.move()[0]
            l=list[0]
            c=list[1]
            self._board[l][c]=1
            for t in self._snake.get_tail():
                l=t[0]
                c=t[1]
                self._board[l][c]=2
            self._board[l+1][c]=0
            nr_moves = nr_moves-1

    def place_random_apples(self):
        apples=self.nr_of_apples
        while apples!=0:
            l=random.randint(0,self._dim-1)
            c=random.randint(0,self._dim-1)
            if self._board[l][c] == 0 and not self.are_adjacent(l,c):
                self._board[l][c]=3 # 3 for apple
                apples = apples-1

    def __str__(self):
        board = "\n   "
        for i in range(self._dim):
            board += "\n " + "-" * (4 * self._dim + 1) + "\n"  + '|'
            for j in range(self._dim):
                if self._board[i][j] == 1:
                    board+= ' * |'
                elif self._board[i][j] == 2:
                    board += ' + |'
                elif self._board[i][j] == 3:
                    board += ' . |'
                else:
                    board += '   |'
        board += "\n " + "-" * (4 * self._dim + 1) + "\n"
        return board

