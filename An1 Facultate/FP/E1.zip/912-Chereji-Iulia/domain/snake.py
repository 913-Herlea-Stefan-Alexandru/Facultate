from domain.coordinates import Coordinates


class Snake:
    def __init__(self, head:Coordinates, tail, orientation):
        self._head= head
        self._tail = tail #list of coordinates
        self._orientation=orientation
        self._nr_tail=2

    def increase_tail(self,val):
        self._nr_tail= val

    def get_length(self):
        return self._nr_tail

    def get_tail(self):
        tail=[]
        for t in self._tail:
            tail.append([t.line, t.col])
        return tail

    def get_head_of_snake(self):
        l= self._head.line
        c= self._head.col
        return [l, c]

    def set_head_of_snake(self,l_val,c_val):
        self._head.set_line(l_val)
        self._head.set_col(c_val)

    def move(self):
        if self._orientation == 'up':
            self.set_head_of_snake(self._head.line-1, self._head.col)
            l=self.get_head_of_snake()[0]
            c=self.get_head_of_snake()[1]
            for t in self._tail:
                t.set_line(t.line-1)
                t.set_col(t.col)
            return [l, c] , self._tail













