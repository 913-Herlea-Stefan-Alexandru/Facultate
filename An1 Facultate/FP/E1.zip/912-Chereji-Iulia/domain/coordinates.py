class Coordinates:
    def __init__(self, line, col):
        self._line = line
        self._col = col

    @property
    def line(self):
        return self._line

    @property
    def col(self):
        return self._col

    def set_line(self, val):
        self._line = val

    def set_col(self, val):
        self._col = val

