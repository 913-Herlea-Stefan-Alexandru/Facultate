class Settings:
    def __init__(self, file_name = 'snake.txt'):
        self._file_name = file_name


    def _load(self):
        f = open(self._file_name,'r')
        lines = f.readlines()
        f.close()
        dim=0
        nr_of_apples=0
        for line in lines:
            line = line.split(' ')
            dim=int(line[0])
            nr_of_apples=int(line[1])
        _list=[dim, nr_of_apples]
        return _list

    def dimension(self):
        return self._load()[0]

    def nr_of_apples(self):
        return self._load()[1]


