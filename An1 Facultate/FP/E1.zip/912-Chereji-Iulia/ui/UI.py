from domain.board import Board
from service.service import Service


class UI:
    def __init__(self, board:Board, service:Service):
        self._board= board
        self._service = service
        self._commands={"move":self.move_snake_ui,"up": self.change_up_ui,"down": self.change_down_ui,"left": self.change_left_ui,"right": self.change_right_ui }

    def print_first_board(self):
        self._board.create_board()
        print(self._board)


    def start(self):
        self.print_first_board()
        while True:
            cmd= input(">>>")
            key, params = self._parse_move(cmd)
            if key == 'move':
                self._commands[key](params)
            elif key in self._commands:
                self._commands[key]
            else:
                print("Invalid command!")
            if self.game_over():
                print("Game over")
                break

    def move_snake_ui(self,params):
        try:
            if params==None:
                self._service.eat_apple()
                print(self._service.get_length())
                self._service.move(None)

            else:
                self._service.move(params)

            print(self._board)
        except ValueError as ve:
            print(str(ve))


    def game_over(self):
        if self._service.hits_edge():
            return True


    def change_up_ui(self):
        pass

    def change_down_ui(self):
        pass

    def change_left_ui(self):
        pass

    def change_right_ui(self):
        pass

    def _parse_move(self, command):
        tokens = command.strip().split(' ', 1)
        if len(tokens) > 2:
            raise ValueError("Invalid nr of params")
        if len(tokens) == 1:
            return tokens[0].strip(), None
        else:
            return tokens[0].strip(), tokens[1].strip()
