from domain.board import Board
from domain.coordinates import Coordinates
from domain.snake import Snake
from service.service import Service
from settings import Settings
from ui.UI import UI

settings= Settings()
dim = settings.dimension()
middle=dim//2
nr_of_apples=settings.nr_of_apples()
snake= Snake(Coordinates(middle, middle), [Coordinates(middle+1, middle),Coordinates(middle+2, middle)],'up')
board = Board(dim, nr_of_apples,snake)


service= Service(board, snake)
ui=UI(board,service)
ui.start()
