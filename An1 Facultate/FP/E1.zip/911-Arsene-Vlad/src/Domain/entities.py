import random
from texttable import Texttable

class Board():
    def __init__(self, DIM, apple_count):
        self._dim = DIM
        self._apple_count = apple_count
        self._field = [[' ' for column in range(DIM)] for row in range(DIM)]
        self._head_row = None
        self._hed_col = None
        self._length = 3
        self._direction = 0
        self._tail = []
        self._apples = []
        self._last_row = None
        self._last_col = None
        self._over = False

        self.init_snake()
        self.init_apples()

    def isOver(self):
        return self._over

    def init_snake(self):
        middle = self._dim // 2
        self._field[middle-1][middle] = '*'
        self._head_row = middle - 1
        self._head_col = middle
        self._tail.append([self._head_row, self._head_col])
        self._field[middle][middle] = '+'
        self._tail.append([middle, middle])
        self._field[middle+1][middle] = '+'
        self._tail.append([middle+1, middle])

    def validate_coordinates(self, row, column, ignore_apples=False, ignore_snake=False):
        if ignore_apples:
            if row < 0 or row > self._dim - 1 or column < 0 or column > self._dim - 1 or self._field[row][column] == '+' or self._field[row][column] == '*':
                raise ValueError('Invalid coordinates!\n')
            return

        if ignore_snake:
            if row < 0 or row > self._dim - 1 or column < 0 or column > self._dim - 1 or self._field[row][column] == '.':
                raise ValueError('Invalid coordinates!')
            return

        if row < 0 or row > self._dim - 1 or column < 0 or column > self._dim - 1 or self._field[row][column] != ' ':
                raise ValueError('Invalid coordinates!\n')

    def init_apples(self):
        apples = self._apple_count
        while apples:
            row = random.randint(0, self._dim-1)
            col = random.randint(0, self._dim-1)

            try:
                self.validate_coordinates(row, col)

                row_direction = [-1, 0, 1, 0]
                col_direction = [0, 1, 0, -1]
                for i in range(4):
                    self.validate_coordinates(row + row_direction[i], col + col_direction[i], ignore_snake=True)

                self._field[row][col] = '.'
                apples -= 1
            except:
                pass


    def replace_head(self):
        self._tail[0][0] = self._head_row
        self._tail[0][1] = self._head_col
        self._field[self._head_row][self._head_col] = '*'

    def move_tail(self):
        self._field[self._head_row][self._head_col] = '+'
        self._field[self._tail[-1][0]][self._tail[-1][1]] = ' '

        self._last_row = self._tail[-1][0]
        self._last_col = self._tail[-1][1]

        for i in range(len(self._tail)-2, -1, -1):
            self._tail[i+1][0] = self._tail[i][0]
            self._tail[i+1][1] = self._tail[i][1]
            self._field[self._tail[i][0]][self._tail[i][1]] = '+'
        self.replace_head()

    def append_tail(self):
        self._field[self._last_row][self._last_col] = '+'
        self._tail.append([self._last_row, self._last_col])

    def add_apple(self):
        i = 1500
        while True:
            row = random.randint(0, self._dim-1)
            col = random.randint(0, self._dim-1)

            try:
                self.validate_coordinates(row, col)

                row_direction = [-1, 0, 1, 0]
                col_direction = [0, 1, 0, -1]
                for i in range(4):
                    self.validate_coordinates(row + row_direction[i], col + col_direction[i], ignore_snake=True)

                self._field[row][col] = '.'
                return
            except:
                pass

            i -= 1


    def step_up(self):
        try:
            self.validate_coordinates(self._head_row-1, self._head_col, ignore_apples=True)
        except:
            self._over = True
            return -1

        ok = False
        if self._field[self._head_row-1][self._head_col] == '.':
            ok = True

        self._head_row -= 1
        self.move_tail()

        if ok:
            self.append_tail()
            self.add_apple()


    def step_right(self):
        try:
            self.validate_coordinates(self._head_row, self._head_col+1, ignore_apples=True)
        except:
            self._over = True
            return -1

        ok = False
        if self._field[self._head_row][self._head_col+1] == '.':
            ok = True

        self._head_col += 1
        self.move_tail()

        if ok:
            self.append_tail()
            self.add_apple()

    def step_down(self):
        try:
            self.validate_coordinates(self._head_row+1, self._head_col, ignore_apples=True)
        except:
            return -1

        ok = False
        if self._field[self._head_row+1][self._head_col] == '.':
            ok = True

        self._head_row += 1
        self.move_tail()

        if ok:
            self.append_tail()
            self.add_apple()

    def step_left(self):
        try:
            self.validate_coordinates(self._head_row, self._head_col-1, ignore_apples=True)
        except:
            self._over = True
            return -1

        ok = False
        if self._field[self._head_row][self._head_col-1] == '.':
            ok = True

        self._head_col -= 1
        self.move_tail()

        if ok:
            self.append_tail()
            self.add_apple()


    def move(self, steps):
        if self._direction == 0:
            for i in range(steps):
                moved = self.step_up()
                if moved == -1:
                    self._over = True

        elif self._direction == 1:
            for i in range(steps):
                moved = self.step_right()
                if moved == -1:
                    self._over = True

        elif self._direction == 2:
            for i in range(steps):
                moved = self.step_down()
                if moved == -1:
                    self._over = True

        elif self._direction == 3:
            for i in range(steps):
                moved = self.step_left()
                if moved == -1:
                    self._over = True

    def up(self):
        if self._direction == 2 or self._direction == 0:
            raise ValueError('Invalid direction!')

        if self._field[self._head_row-1][self._head_col] == '+':
            self._over = True
            return

        self._field[self._tail[0][0]][self._tail[0][1]] = ' '
        self._field[self._tail[-1][0]][self._tail[-1][1]] = ' '

        ok = False
        if self._field[self._head_row-1][self._head_col] == '.':
            ok = True

        self._head_row -= 1
        self.move_tail() 
        if ok:
            self.append_tail()
            self.add_apple()
        self._direction = 0       

    def right(self):
        if self._direction == 1 or self._direction == 3:
            raise ValueError('Invalid direction!')

        if self._field[self._head_row][self._head_col+1] == '+':
            self._over = True
            return

        self._field[self._tail[0][0]][self._tail[0][1]] = ' '
        self._field[self._tail[-1][0]][self._tail[-1][1]] = ' '

        ok = False
        if self._field[self._head_row][self._head_col+1] == '.':
            ok = True

        self._head_col += 1
        self.move_tail()
        if ok:
            self.append_tail()
            self.add_apple()

        self._direction = 1

    def down(self):
        if self._direction == 2 or self._direction == 0:
            raise ValueError('Invalid direction!')

        if self._field[self._head_row+1][self._head_col] == '+':
            self._over = True
            return

        self._field[self._tail[0][0]][self._tail[0][1]] = ' '
        self._field[self._tail[-1][0]][self._tail[-1][1]] = ' '

        ok = False
        if self._field[self._head_row+1][self._head_col] == '.':
            ok = True

        self._head_row += 1
        self.move_tail()
        if ok:
            self.append_tail()
            self.add_apple()
        self._direction = 2

    def left(self):
        if self._direction == 1 or self._direction == 3:
            raise ValueError('Invalid direction!')

        if self._field[self._head_row][self._head_col-1] == '+':
            self._over = True
            return
        
        self._field[self._tail[0][0]][self._tail[0][1]] = ' '
        self._field[self._tail[-1][0]][self._tail[-1][1]] = ' '

        ok = False
        if self._field[self._head_row][self._head_col-1] == '.':
            ok = True

        self._head_col -= 1
        self.move_tail()
        if ok:
            self.append_tail()
            self.add_apple()
        self._direction = 3


    def __str__(self):  
        table = Texttable()
        for row in self._field:
            table.add_row(row)

        return table.draw()