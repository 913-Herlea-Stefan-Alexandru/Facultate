import os

class Repository():
    def __init__(self, file_name):
        self._file_name = file_name
        self.dim = 0
        self.apple_count = 0

        self.load_file()

    def load_file(self):
        if os.path.isfile(self._file_name):
            with open(self._file_name, 'r') as file:
                lines = file.readlines()

            self.dim = int(lines[0])
            self.apple_count = int(lines[1])