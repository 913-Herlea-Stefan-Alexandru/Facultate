from Domain.entities import Board
from Repository.repository import Repository


class UI():
    def __init__(self, repository):
        self.repository = repository
        self.board = Board(self.repository.dim, self.repository.apple_count)

    @staticmethod
    def split_command(command):
        arguments = command.split(' ')

        if arguments[0] not in ['move', 'up', 'right', 'down', 'left'] or len(arguments) > 2 or len(arguments) == 0:
            raise ValueError('Invalid command!')

        return arguments

    def ui_move(self, arguments):
        if arguments[0] == 'move':
            if len(arguments) == 1:
                self.board.move(1)
            else:
                self.board.move(int(arguments[1]))

        elif arguments[0] == 'up':
            self.board.up()

        elif arguments[0] == 'right':
            self.board.right()

        elif arguments[0] == 'down':
            self.board.down()

        elif arguments[0] == 'left':
            self.board.left()

        else:
            raise ValueError('Invalid command!')

        

    def start(self):
        while self.board.isOver() == False:
            print(self.board)
            try:
                arguments = UI.split_command(input('\nEnter command: '))
                self.ui_move(arguments)

            except ValueError as ve:
                print(str(ve))

        print('\n\nGame over!')



if __name__ == '__main__':
    repo = Repository('data.txt')

    ui = UI(repo)
    ui.start()