from jproperties import Properties
from src.service.game_service import Game
from src.console.ui import UI
p = Properties()
with open("settings.properties", "rb") as f:
    p.load(f, "utf-8")
dim = int(p['dim'].data)
apple_count = int(p['apple_count'].data)

game = Game(dim, apple_count)
ui = UI(dim, game)
ui.run()