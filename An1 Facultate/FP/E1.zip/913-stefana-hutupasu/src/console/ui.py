

class UI:
    def __init__(self, dim, game):
        self._size = dim
        self._game = game
        self.display_initial()

    def display_initial(self):
        print(self._game.board)

    def split_command(self, command):
        tokens = command.strip().split(' ', 1)
        command_word = tokens[0].lower().strip()
        command_params = tokens[1].strip() if len(tokens) == 2 else ''
        return command_word, command_params

    def run(self):
        self.print_commands()
        command_dict = {'move': self.move_snake_ui, 'up': self.change_up_ui, 'right': self.change_right_ui, 'down': self.change_down_ui, 'left': self.change_left_ui}
        done = False
        while not done:
            if self._game.is_over:
                done = True
                print('GAME OVER')
                break
            command = input('Enter a command: ')
            command_word, command_param = self.split_command(command)
            if command_word in command_dict and command_word != 'move':
                command_dict[command_word]()
            elif command_word == 'move':
                command_dict[command_word](command_param)
            elif command_word == 'exit':
                done = True
                print('Quitters are never winners.')
            else:
                print('Bad command! The snake might bite you.')

    def print_commands(self):
        print('Availale commands: ')
        print('move [n] - move the snake n squares in the current direction')
        print('move - move the snake by 1 square')
        print('up \ right \ down \ left - change the current direction')
        print('exit')

    def move_snake_ui(self, param):
        #param = int(param)
        if param == '':
            sq = 1
        else:
            sq = int(param)
        self._game.move_snake(sq)
        print(self._game.board)


    def change_up_ui(self):
        if self._game._s._direction % 2 == 0:
            self._game._s._direction = 1
            print('Current direction: up')
            self._game.one_up()
            print(self._game.board)
        elif self._game._s._direction == 3:
            print('A snake going down cannot immediately go up!')

    def change_right_ui(self):
        if self._game._s._direction % 2:
            self._game._s._direction = 2
            print('Current direction: right')
            self._game.one_right()
            print(self._game.board)
        elif self._game._s._direction == 4:
            print('A snake going left cannot immediately go right!')

    def change_down_ui(self):
        if self._game._s._direction % 2 == 0:
            self._game._s._direction = 3
            print('Current direction: down')
            self._game.one_down()
            print(self._game.board)
        elif self._game._s._direction == 1:
            print('A snake going up cannot immediately go down!')


    def change_left_ui(self):
        if self._game._s._direction % 2:
            self._game._s._direction = 4
            print('Current direction: left')
            self._game.one_left()
            print(self._game.board)
        elif self._game._s._direction == 2:
            print('A snake going right cannot immediately go left!')


