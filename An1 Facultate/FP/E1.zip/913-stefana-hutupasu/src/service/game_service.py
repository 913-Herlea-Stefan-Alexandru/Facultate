from src.repository.board import Board
from src.domain.entity import Snake


class Game:
    def __init__(self, dim, apples):
        self._s = Snake()
        self._board = Board(dim, self._s, apples)
        self.is_over = False

    @property
    def board(self):
        return self._board


    def one_up(self):
        coord = self._s._head
        self._s._head = [coord[0] - 1, coord[1]]
        if self.there_is_wall(self._s._head) or self.there_is_tail(self._s._head):
            self.game_over()
        if self.there_is_apple(self._s._head):
            self._board.more_apple()

        self._s._body_units.insert(0, coord)
        old_coord = self._s._body_units[self._s._body_count]

        if not self.there_is_apple(self._s._head):
            self._board._matrix[old_coord[0]][old_coord[1]] = 0
            self._s._body_units.pop()
        else:
            self._s._body_count += 1
        self._board.update_snake()

    def one_right(self):
        coord = self._s._head
        self._s._head = [coord[0], coord[1] + 1]
        if self.there_is_wall(self._s._head) or self.there_is_tail(self._s._head):
            self.game_over()
        if self.there_is_apple(self._s._head):
            self._board.more_apple()

        self._s._body_units.insert(0, coord)
        old_coord = self._s._body_units[self._s._body_count]

        if not self.there_is_apple(self._s._head):
            self._board._matrix[old_coord[0]][old_coord[1]] = 0
            self._s._body_units.pop()
        else:
            self._s._body_count += 1
        self._board.update_snake()

    def one_down(self):
        coord = self._s._head
        self._s._head = [coord[0] + 1, coord[1]]
        if self.there_is_wall(self._s._head) or self.there_is_tail(self._s._head):
            self.game_over()
        if self.there_is_apple(self._s._head):
            self._board.more_apple()


        self._s._body_units.insert(0, coord)
        old_coord = self._s._body_units[self._s._body_count]

        if not self.there_is_apple(self._s._head):
            self._board._matrix[old_coord[0]][old_coord[1]] = 0
            self._s._body_units.pop()
        else:
            self._s._body_count += 1

            self._board.update_snake()

    def one_left(self):
        coord = self._s._head
        self._s._head = [coord[0], coord[1] - 1]
        if self.there_is_wall(self._s._head) or self.there_is_tail(self._s._head):
            self.game_over()
        if self.there_is_apple(self._s._head):
            self._board.more_apple()

        self._s._body_units.insert(0, coord)
        old_coord = self._s._body_units[self._s._body_count]

        if not self.there_is_apple(self._s._head):
            self._board._matrix[old_coord[0]][old_coord[1]] = 0
            self._s._body_units.pop()
        else:
            self._s._body_count += 1

        self._board.update_snake()

    def move_snake(self, n):
        dir = self._s._direction
        if dir == 1:
            for i in range(n):
                self.one_up()
        elif dir == 2:
            for i in range(n):
                self.one_right()
        elif dir == 3:
            for i in range(n):
                self.one_down()
        elif dir == 4:
            for i in range(n):
                self.one_left()

    def there_is_apple(self, coord):
        if self._board._matrix[coord[0]][coord[1]] == '.':
            return True
        return False

    def there_is_wall(self, coord):
        if coord[0] < 0 or coord[0] >= self._board._rows:
            return True

        if coord[1] < 0 or coord[1] >= self._board._rows:
            return True

        return False

    def there_is_tail(self, coord):
        if self._board._matrix[coord[0]][coord[1]] == '+':
            return True
        return False

    def game_over(self):
        self.is_over = True




