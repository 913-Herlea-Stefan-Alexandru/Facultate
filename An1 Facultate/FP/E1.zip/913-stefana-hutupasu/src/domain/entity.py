class Snake:
    def __init__(self):
        self._body_count = 0
        self._body_units = []
        self._head = []
        self._direction = 1
        # 1 is up, 2 is right, 3 is down, 4 is left

    def poz_head(self, r, c):
        self._head = [r, c]

    def poz_body(self, r, c):
        self._body_count += 1
        self._body_units.append([r, c])
