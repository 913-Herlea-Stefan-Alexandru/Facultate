# game area is dim x dim texttable
# at first - snake in centre
# x apples, randomly placed - no adjacent apples
# for apple - empty cross
from texttable import Texttable
import random
from src.domain.entity import Snake

class Board:
    def __init__(self, dim, snake, apples):
        self._rows = dim
        self._columns = dim
        self._row_index_list = []
        for row in range(self._rows):
            self._row_index_list.append(row)
        self._column_index_list = []
        for column in range(self._columns):
            self._column_index_list.append(column)

        self._snake = snake
        self._matrix = [[0 for column in range(0, self._columns)] for row in range(0, self._rows)]
        self._apples = apples

        self.place_snake_in_center()
        self.place_apples_at_start()


    def place_snake_in_center(self):
        #snake has 3 units at first
        column = self._columns // 2
        difference = (self._rows - 3) // 2
        head_row = difference
        first_body_unit = head_row + 1
        second_body_unit = head_row + 2
        self._snake.poz_head(head_row, column)
        self._snake.poz_body(first_body_unit, column)
        self._snake.poz_body(second_body_unit, column)
        self.update_snake()


    def update_snake(self):
        for i in range(self._rows):
            for j in range(self._columns):
                if self._matrix[i][j] == '*' or self._matrix[i][j] == '+':
                    self._matrix[i][j] == 0

        self._matrix[self._snake._head[0]][self._snake._head[1]] = '*'
        for segment in self._snake._body_units:
            self._matrix[segment[0]][segment[1]] = '+'


    def __str__(self):
        self.update_snake()
        table = Texttable()
        line = []
        line.append(' ')
        line = line + self._column_index_list
        table.add_row(line)
        symbols = {'+': '+', '.': '.', 0: ' ', '*': '*'}
        for row_number in self._row_index_list:
            moves = self._matrix[row_number][:]
            for column_number in self._column_index_list:
                moves[column_number] = symbols[moves[column_number]]
            line = []
            line.append(row_number)
            line = line + moves
            table.add_row(line)

        return table.draw()


    def place_apples_at_start(self):
        row_dir = [-1, 0, 1, 0]
        column_dir = [0, 1, 0, -1]
        apples_placed = 0
        while apples_placed != self._apples:
            rand_c = random.randint(0, self._rows - 1)
            rand_r = random.randint(0, self._rows - 1)
            ok = True
            if self._matrix[rand_r][rand_c] != 0:
                ok = False
            for k in range(0, 4):
                new_row = rand_r + row_dir[k]
                new_column = rand_c + column_dir[k]
                if 0 <= new_row < self._rows and 0 <= new_column < self._columns:
                    if self._matrix[new_row][new_column] != 0:
                        ok = False
                        break
            if ok:
                self._matrix[rand_r][rand_c] = '.'
                apples_placed += 1


    def more_apple(self):
        row_dir = [-1, 0, 1, 0]
        column_dir = [0, 1, 0, -1]
        apples_placed = 0
        while apples_placed != 1:
            rand_c = random.randint(0, self._rows - 1)
            rand_r = random.randint(0, self._rows - 1)
            ok = True
            if self._matrix[rand_r][rand_c] != 0:
                ok = False
            for k in range(0, 4):
                new_row = rand_r + row_dir[k]
                new_column = rand_c + column_dir[k]
                if 0 <= new_row < self._rows and 0 <= new_column < self._columns:
                    if self._matrix[new_row][new_column] != 0:
                        ok = False
                        break
            if ok:
                self._matrix[rand_r][rand_c] = '.'
                apples_placed += 1

